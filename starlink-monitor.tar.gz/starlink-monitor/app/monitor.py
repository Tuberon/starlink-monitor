"""
Фоновий watchdog: опитує dish (POLL_INTERVAL_SEC) і router (~60с),
пише в БД, авто-reboot Mini при 3 умовах (watchdog failures,
update-ready dish, update-ready router) - див. docs/architecture.md.
Логує зміни стану/попереджень в events, дублює ключові події в
Telegram (не блокує цикл при помилках відправки).
"""
import json
import logging
import threading
import time
from typing import Callable, Optional

import psutil

from app import config, db, telegram_notify
from app.labels import ALERT_LABELS, ROUTER_ALERT_LABELS, ROUTER_UPDATE_STATE_LABELS, UPDATE_STATE_LABELS
from app.starlink_client import DishStatus, RouterInfo, StarlinkClient
from app.system_metrics import get_system_metrics

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("monitor")


def version_in_target_list(current_version: Optional[str], target_raw: Optional[str]) -> bool:
    """Чи current_version входить у target_raw - список версій через
    кому (db.parse_version_list). Module-level (не метод класу) - щоб
    бути доступною і з Watchdog (фоновий цикл опитування), і напряму
    з webapp.py (ручна кнопка "Перевірити оновлення" - окремий процес,
    не має доступу до інстансу Watchdog з іншого сервісу)."""
    if not current_version:
        return False
    return current_version in db.parse_version_list(target_raw)


def check_target_version_reached(
    component_label: str, current_version: Optional[str], target_key: str,
    notified_key: str, dish_id: Optional[str], notify_fn: Callable[[str], None],
) -> None:
    """Порівнює встановлену версію (current_version) з очікуваними
    (target - введені користувачем на /settings через кому, той самий
    формат, що telegram_chat_ids - корисно, коли SpaceX випускає
    РІЗНІ номери версій для різних апаратних ревізій під однією
    умовною версією, і користувач не певен, який саме рядок реально
    прийде). Матч спрацьовує на БУДЬ-ЯКУ з перелічених версій.
    notified_key зберігає ТРІЙКУ (dish_id + яка саме версія збіглась +
    повний список target) - природно "скидається" і при зміні списку,
    і якщо ТА САМА версія випадково повториться на іншому опитуванні
    ТОГО САМОГО пристрою, АЛЕ КРИТИЧНО - dish_id у ключі означає, що
    ІНШИЙ фізичний Starlink (інший dish_id, напр. після заміни
    обладнання) з тим самим збігом версія+target ЗАВЖДИ отримає своє
    власне, свіже сповіщення, не заблоковане дедублікацією попереднього
    пристрою. notify_fn - інʼєкція функції сповіщення (Watchdog передає
    self._notify, webapp.py передає telegram_notify.send_message напряму
    - module-level функція сама не залежить від того, ЯК саме сповіщати)."""
    target_raw = db.get_setting(target_key)
    if not version_in_target_list(current_version, target_raw):
        return
    notified_value = f"{dish_id}|{current_version}|{target_raw}"
    if db.get_setting(notified_key) == notified_value:
        return
    notify_fn(f"✅ Останнє оновлення {component_label} встановлено: версія {current_version}")
    db.set_setting(notified_key, notified_value)


def check_both_targets_reached(last_known_dish_id: Optional[str], notify_fn: Callable[[str], None]) -> None:
    """Окремо від per-component сповіщень вище (ті корисні самі по собі
    - dish оновився, вже цікаво знати, навіть якщо router ще ні) - це
    додаткове, комбіноване підтвердження: коли ОБИДВІ (тарілка й
    роутер) очікувані версії одночасно збігаються зі встановленими,
    надсилає одне повідомлення про завершення ВСІЄЇ процедури
    оновлення. Викликається з обох poll_once() (dish) і poll_router()
    (router) - або один, або інший цикл опитування може стати тим,
    що робить умову істинною одночасно для обох (компоненти
    опитуються незалежно, різними циклами), а також з api_check_updates()
    (webapp.py) - ручна кнопка теж має отримувати повний спектр
    перевірок, не лише читання статусу.

    Дедублікація - той самий принцип, що в check_target_version_reached():
    notified-ключ включає dish_id (різні фізичні Starlink НЕ ділять
    дедублікаційний стан), САМЕ ЗНАЧЕННЯ поточних версій обох
    компонентів і повні target-списки одночасно - природно
    "скидається", щойно користувач змінить БУДЬ-ЯКИЙ з двох
    target-списків (напр. додасть версію для іншої апаратної
    ревізії), без потреби окремо очищати стан."""
    dish_target = db.get_setting("dish_target_version")
    router_target = db.get_setting("router_target_version")
    if not dish_target or not router_target:
        return

    latest = db.get_latest_metric()
    router_status = db.get_router_status()
    dish_current = latest.get("software_version") if latest else None
    router_current = router_status.get("software_version") if router_status else None

    if not version_in_target_list(dish_current, dish_target) or \
            not version_in_target_list(router_current, router_target):
        return

    combo_key = f"{last_known_dish_id}|{dish_current}|{dish_target}|{router_current}|{router_target}"
    if db.get_setting("both_targets_notified") == combo_key:
        return

    notify_fn(f"🎉 Процедуру оновлення завершено: тарілка {dish_current}, роутер {router_current}")
    db.set_setting("both_targets_notified", combo_key)


def _format_firmware_change_message(component_label: str, old_version: str, new_version: str) -> str:
    """Формує повідомлення про зміну прошивки з ПРАВИЛЬНИМ дієсловом
    залежно від напрямку - без цього "🔄 оновлена" вводило б в оману,
    коли реальна зміна versions - це ВІДКАТ (SpaceX інколи відкочує
    проблемні білди глобально; ручний reboot, як з'ясувалось на
    реальному запиті користувача, може "спіймати" момент, коли
    команда відкату вже чекала). db.is_older_version() (толерантний
    компаратор, вже перевірений на реалістичних версіях) визначає
    напрямок - слово й emoji підбираються відповідно, дані (X → Y)
    завжди ті самі, чесно показують РЕАЛЬНИЙ факт, лише словесне
    формулювання змінюється."""
    if db.is_older_version(new_version, old_version):
        return f"⏪ Прошивка {component_label} відкочена (можливо, SpaceX-side): {old_version} → {new_version}"
    return f"🔄 Прошивка {component_label} оновлена: {old_version} → {new_version}"


def upsert_dish_and_notify(status: DishStatus, notify_fn: Callable[[str], None]) -> None:
    """Записує/оновлює відому версію dish у known_devices, сповіщає
    при РЕАЛЬНІЙ зміні версії ("🔄 оновлена" чи "⏪ відкочена" - залежно
    від напрямку, див. _format_firmware_change_message), і перевіряє
    target-версію. Module-level - той самий принцип, що решта функцій
    вище: спільна логіка для watchdog-циклу (poll_once) і ручної
    кнопки "Перевірити оновлення" (webapp.py api_check_updates) - без
    цього ручна перевірка мовчки НЕ надсилала жодного сповіщення,
    навіть коли версія якраз збігалась із target (знайдено на
    реальному запиті користувача - "перевір процедуру перевірки
    оновлень на помилки")."""
    if not status.online:
        return
    real_change, old_version = db.upsert_known_device_dish(status.dish_id, status.hardware_version, status.software_version)
    if real_change and old_version:
        notify_fn(_format_firmware_change_message("тарілки", old_version, status.software_version))
    check_target_version_reached(
        "тарілки", status.software_version, "dish_target_version", "dish_target_notified", status.dish_id, notify_fn
    )
    check_both_targets_reached(status.dish_id, notify_fn)


def upsert_router_and_notify(info: RouterInfo, dish_id: Optional[str], notify_fn: Callable[[str], None]) -> None:
    """Аналогічно до upsert_dish_and_notify(), для router. dish_id -
    router прив'язується до dish_id того самого фізичного Mini
    (router не має власного окремого ідентифікатора)."""
    if not info.online:
        return
    if dish_id:
        real_change, old_version = db.upsert_known_device_router(dish_id, info.hardware_version, info.software_version)
        if real_change and old_version:
            notify_fn(_format_firmware_change_message("роутера", old_version, info.software_version))
    check_target_version_reached(
        "роутера", info.software_version, "router_target_version", "router_target_notified", dish_id, notify_fn
    )
    check_both_targets_reached(dish_id, notify_fn)


class Watchdog:
    def __init__(self) -> None:
        self.client = StarlinkClient()
        self.consecutive_failures = 0
        self.last_reboot_ts = 0.0
        # Час першої невдалої спроби в поточному безперервному ланцюжку
        # відмов - None, поки dish online. Використовується, щоб приглушити
        # Telegram-сповіщення про auto-reboot при тривалій (>15 хв, за
        # замовчуванням) відсутності WiFi Starlink - події й далі пишуться
        # в журнал дашборду, лише Telegram-звіти призупиняються.
        self.first_failure_ts: Optional[float] = None
        # Попередні значення для детекції змін стану оновлення/попереджень.
        # None означає "ще не бачили жодного online-статусу" - перший
        # реальний статус теж логуємо, якщо він не порожній/не IDLE-без-алертів.
        self.prev_update_state: Optional[str] = None
        self.prev_alerts: Optional[set[str]] = None
        self.prev_router_update_state: Optional[str] = None
        self.prev_router_alerts: Optional[set[str]] = None
        # Останній відомий dish_id - потрібен, щоб прив'язати опитування
        # роутера (окремий цикл, без власного dish_id у RouterInfo) до
        # того самого фізичного Mini в таблиці known_devices.
        self.last_known_dish_id: Optional[str] = None
        # Групування спаму reboot-сповіщень: якщо стається кілька
        # ребутів поспіль за короткий час (флап), кожен окремий
        # "🔁 перезавантажено" - спам. reboot_notify_ts - timestamps
        # уже надісланих reboot-сповіщень (не всіх спроб reboot, лише
        # тих, що дійшли до Telegram) за ковзне вікно.
        self.reboot_notify_ts: list[float] = []
        self.reboot_spam_muted = False
        self.muted_reboot_count = 0

    def _notify(self, text: str) -> None:
        """Безпечна відправка Telegram-сповіщення - ніколи не кидає виняток
        назовні і не блокує основний цикл моніторингу."""
        try:
            ok, msg = telegram_notify.send_message(text)
            if not ok and msg not in ("Telegram сповіщення вимкнені", "Не вказано bot token", "Не вказано жодного chat_id"):
                logger.warning("Telegram сповіщення не надіслано: %s", msg)
        except Exception as e:
            logger.warning("Помилка відправки Telegram-сповіщення: %s", e)

    def _notifications_muted(self) -> bool:
        """True, якщо dish недоступний безперервно довше
        config.NOTIFICATIONS_MUTE_AFTER_SEC - Telegram-сповіщення про
        auto-reboot тимчасово призупиняються (журнал подій не зачіпається)."""
        if self.first_failure_ts is None:
            return False
        return (time.time() - self.first_failure_ts) >= config.NOTIFICATIONS_MUTE_AFTER_SEC

    def _notify_reboot(self, text: str) -> None:
        """Групування спаму reboot-сповіщень - на відміну від
        _notifications_muted() (приглушує при ОДНІЙ тривалій відмові),
        це про ЧАСТОТУ: кілька окремих коротких reboot-циклів поспіль
        (флап), кожен з яких проходить MIN_REBOOT_INTERVAL_SEC і тому
        не приглушується тим механізмом. Коли за REBOOT_SPAM_WINDOW_SEC
        назбирались REBOOT_SPAM_THRESHOLD+ такі сповіщення - один раз
        попереджаємо про групування і замовкаємо до затишшя, коли
        надсилаємо підсумок (див. _check_reboot_spam_recovery)."""
        now = time.time()
        self.reboot_notify_ts = [t for t in self.reboot_notify_ts if now - t < config.REBOOT_SPAM_WINDOW_SEC]
        self.reboot_notify_ts.append(now)

        if len(self.reboot_notify_ts) < config.REBOOT_SPAM_THRESHOLD:
            self._notify(text)
            return

        if not self.reboot_spam_muted:
            self.reboot_spam_muted = True
            self.muted_reboot_count = 1
            window_min = config.REBOOT_SPAM_WINDOW_SEC // 60
            self._notify(
                f"⚠️ Часті авто-reboot ({len(self.reboot_notify_ts)} за останні {window_min} хв) — "
                f"подальші повідомлення про reboot тимчасово згруповано, щоб не спамити"
            )
        else:
            self.muted_reboot_count += 1

    def _check_reboot_spam_recovery(self) -> None:
        """Викликається щоцикл опитування - якщо reboot-флап (див.
        _notify_reboot) припинився (минуло REBOOT_SPAM_WINDOW_SEC без
        нового reboot-сповіщення), надсилає підсумок і скидає стан
        групування, повертаючись до звичайного індивідуального режиму."""
        if not self.reboot_spam_muted:
            return
        if not self.reboot_notify_ts:
            return
        if time.time() - self.reboot_notify_ts[-1] < config.REBOOT_SPAM_WINDOW_SEC:
            return
        total = self.muted_reboot_count
        self._notify(f"✅ Часті авто-reboot припинились (усього {total} згруповано)")
        self.reboot_spam_muted = False
        self.muted_reboot_count = 0
        self.reboot_notify_ts = []

    def poll_once(self) -> DishStatus:
        self._check_reboot_spam_recovery()
        status = self.client.get_status()
        db.insert_metric(status.to_dict())

        if status.online:
            if self.consecutive_failures > 0:
                downtime_sec = time.time() - self.first_failure_ts if self.first_failure_ts else 0
                logger.info("Dish знову online після %d невдалих спроб", self.consecutive_failures)
                if downtime_sec >= config.NOTIFICATIONS_MUTE_AFTER_SEC:
                    downtime_min = round(downtime_sec / 60)
                    self._notify(f"✅ Dish знову online (WiFi Starlink була відсутня ~{downtime_min} хв, сповіщення відновлено)")
                else:
                    self._notify(f"✅ Dish знову online (після {self.consecutive_failures} невдалих спроб)")
            self.consecutive_failures = 0
            self.first_failure_ts = None
            self._notify_first_dish_connection(status)
            if status.dish_id:
                self.last_known_dish_id = status.dish_id
            upsert_dish_and_notify(status, self._notify)
            self._log_update_state_change(status)
            self._log_alerts_change(status)
            self._maybe_reboot_for_update(status)
        else:
            if self.first_failure_ts is None:
                self.first_failure_ts = time.time()
            self.consecutive_failures += 1
            logger.warning(
                "Dish недоступний (%d/%d): %s",
                self.consecutive_failures,
                config.MAX_CONSECUTIVE_FAILURES,
                status.error,
            )
            self._maybe_reboot()

        if status.online and status.obstruction_fraction > config.OBSTRUCTION_WARN_FRACTION:
            db.insert_event(
                "obstruction_warning",
                f"Фракція обструкції {status.obstruction_fraction:.2%} перевищує поріг "
                f"{config.OBSTRUCTION_WARN_FRACTION:.2%}",
                success=True,
            )

        return status

    # Стани безпосереднього завантаження/встановлення оновлення (без
    # REBOOT_REQUIRED - той має власне окреме повідомлення "готове").
    # Перехід у ці стани з "не активного" (IDLE) - початок оновлення.
    DOWNLOADING_UPDATE_STATES = {"FETCHING", "PRE_CHECK", "WRITING", "POST_CHECK"}
    # Той самий набір + REBOOT_REQUIRED - для визначення "був у процесі
    # оновлення", коли перевіряємо повернення в IDLE (кінець циклу
    # після успішного перезавантаження з новою версією).
    ACTIVE_UPDATE_STATES = DOWNLOADING_UPDATE_STATES | {"REBOOT_REQUIRED"}

    def _log_update_state_change(self, status: DishStatus) -> None:
        """Пише подію в журнал кожного разу, коли змінюється стан оновлення ПЗ dish."""
        state = status.update_state or "SOFTWARE_UPDATE_STATE_UNKNOWN"
        if state == self.prev_update_state:
            return

        label = UPDATE_STATE_LABELS.get(state, state)
        detail = ""
        if state in self.DOWNLOADING_UPDATE_STATES and status.update_progress_pct:
            detail = f" ({status.update_progress_pct:.0f}%)"

        # Перший запис після старту сервісу (prev_update_state is None) логуємо
        # лише якщо стан не "нейтральний" (IDLE) - інакше журнал засмічується
        # одноразовим повідомленням "IDLE" при кожному рестарті сервісу.
        if self.prev_update_state is not None or state != "IDLE":
            db.insert_event(
                "update_state_change",
                f"Стан оновлення ПЗ: {label}{detail}",
                success=(state not in ("FAULTED",)),
            )
            was_active = self.prev_update_state in self.ACTIVE_UPDATE_STATES

            if state == "REBOOT_REQUIRED":
                self._notify(f"🔄 Оновлення ПЗ dish готове — очікує перезавантаження{detail}")
            elif state == "FAULTED":
                self._notify(f"⚠️ Помилка оновлення ПЗ dish: {label}")
            elif self.prev_update_state is not None and not was_active and state in self.DOWNLOADING_UPDATE_STATES:
                self._notify(f"🔽 Розпочато оновлення ПЗ dish: {label}{detail}")
            elif was_active and state == "IDLE":
                self._notify("✅ Оновлення ПЗ dish завершено (нова версія встановлена)")
        self.prev_update_state = state

    def _log_alerts_change(self, status: DishStatus) -> None:
        """Пише окрему подію для кожного попередження, яке з'явилось або зникло."""
        current = set(status.active_alerts or [])
        previous = self.prev_alerts

        # Перший виклик (previous is None): не генеруємо подій "з'явилось",
        # бо це вже поточний стан на момент старту сервісу, а не нова зміна.
        if previous is not None:
            appeared = current - previous
            resolved = previous - current
            for alert in sorted(appeared):
                label = ALERT_LABELS.get(alert, alert)
                db.insert_event(
                    "dish_alert",
                    f"Нове попередження dish: {label}",
                    success=False,
                )
                if alert not in self.MUTED_DISH_ALERTS:
                    self._notify(f"⚠️ Нове попередження dish: {label}")
            for alert in sorted(resolved):
                label = ALERT_LABELS.get(alert, alert)
                db.insert_event(
                    "dish_alert_resolved",
                    f"Попередження знято: {label}",
                    success=True,
                )

        self.prev_alerts = current

    def _notify_first_dish_connection(self, status: DishStatus) -> None:
        """Надсилає в Telegram ID тарілки один раз - лише при першому
        підключенні кожної конкретної тарілки (за dish_id) до Pi. Усі
        колись бачені ID зберігаються в settings (JSON-список), тож
        переживають рестарт сервісу; при підключенні НОВОЇ тарілки
        (ID, якого ще не було в списку) сповіщення прийде знову, навіть
        якщо до цього вже підключались дві чи більше різних тарілок."""
        if not status.dish_id:
            return

        raw = db.get_setting("known_dish_ids", "[]") or "[]"
        try:
            known_ids = json.loads(raw)
        except (TypeError, json.JSONDecodeError):
            known_ids = []

        if status.dish_id in known_ids:
            return

        known_ids.append(status.dish_id)
        db.set_setting("known_dish_ids", json.dumps(known_ids, ensure_ascii=False))
        db.insert_event("dish_connected", f"Підключено Starlink Mini, ID: {status.dish_id}", success=True)
        self._notify(f"📡 Підключено Starlink Mini (тарілка), ID: {status.dish_id}")

    @staticmethod
    def _version_in_target_list(current_version: Optional[str], target_raw: Optional[str]) -> bool:
        return version_in_target_list(current_version, target_raw)

    def _check_target_version_reached(
        self, component_label: str, current_version: Optional[str], target_key: str,
        notified_key: str, dish_id: Optional[str],
    ) -> None:
        check_target_version_reached(component_label, current_version, target_key, notified_key, dish_id, self._notify)

    def _check_both_targets_reached(self) -> None:
        check_both_targets_reached(self.last_known_dish_id, self._notify)

    def poll_system_metrics(self) -> None:
        try:
            metrics = get_system_metrics()
            db.insert_system_metric(metrics)
        except Exception as e:
            logger.warning("Не вдалося зібрати системні метрики: %s", e)

    # Попередження, які навмисно ігноруються (не пишуться в БД, журнал,
    # Telegram) - шумні для конкретної конфігурації мережі, без
    # практичної цінності.
    IGNORED_ROUTER_ALERTS = {"wired_mesh_not_using_wan_iface"}

    # Попередження/стани, які й далі пишуться в журнал подій (для
    # дашборду), але НЕ надсилаються в Telegram - шумні конкретно для
    # цього звіту, без потреби негайного сповіщення.
    MUTED_DISH_ALERTS = {"roaming"}
    MUTED_ROUTER_ALERTS = {"install_pending"}
    MUTED_ROUTER_UPDATE_STATES = {"GETTING_TARGET_VERSION_FAILED"}

    def poll_router(self) -> None:
        """Опитує окремий роутерний компонент Starlink Mini (інша адреса,
        ніж dish). Версія прошивки роутера змінюється рідко, тому зберігаємо
        лише останній відомий стан (без історії/графіків)."""
        try:
            info = self.client.get_router_info()
            info.active_alerts = [a for a in info.active_alerts if a not in self.IGNORED_ROUTER_ALERTS]
            db.set_router_status(info.to_dict())
            if not info.online:
                logger.debug("Роутер недоступний: %s", info.error)
                return
            upsert_router_and_notify(info, self.last_known_dish_id, self._notify)
            self._log_router_update_state_change(info)
            self._log_router_alerts_change(info)
            self._maybe_reboot_for_router_update(info)
        except Exception as e:
            logger.warning("Не вдалося опитати роутер: %s", e)

    def _log_router_update_state_change(self, info: RouterInfo) -> None:
        """Пише подію в журнал кожного разу, коли змінюється стан оновлення ПЗ роутера."""
        state = info.update_state or "NOT_RUN"
        if state == self.prev_router_update_state:
            return

        label = ROUTER_UPDATE_STATE_LABELS.get(state, state)
        detail = ""
        if state in ("DOWNLOADING_UPDATE_IMAGE", "FLASHING") and info.update_progress_pct:
            detail = f" ({info.update_progress_pct:.0f}%)"

        if self.prev_router_update_state is not None or state != "NOT_RUN":
            is_failure = "FAILED" in state or "ILLEGAL" in state
            db.insert_event(
                "router_update_state_change",
                f"Стан оновлення ПЗ роутера: {label}{detail}",
                success=(not is_failure),
            )
            if state == "REBOOT_PENDING":
                self._notify(f"🔄 Оновлення ПЗ роутера готове — очікує перезавантаження{detail}")
            elif is_failure and state not in self.MUTED_ROUTER_UPDATE_STATES:
                self._notify(f"⚠️ Помилка оновлення ПЗ роутера: {label}")
        self.prev_router_update_state = state

    def _log_router_alerts_change(self, info: RouterInfo) -> None:
        """Пише окрему подію для кожного попередження роутера, яке з'явилось або зникло.
        info.active_alerts тут уже профільтровано від IGNORED_ROUTER_ALERTS (poll_router)."""
        current = set(info.active_alerts or [])
        previous = self.prev_router_alerts

        if previous is not None:
            appeared = current - previous
            resolved = previous - current
            for alert in sorted(appeared):
                label = ROUTER_ALERT_LABELS.get(alert, alert)
                db.insert_event(
                    "router_alert",
                    f"Нове попередження роутера: {label}",
                    success=False,
                )
                if alert not in self.MUTED_ROUTER_ALERTS:
                    self._notify(f"⚠️ Нове попередження роутера: {label}")
            for alert in sorted(resolved):
                label = ROUTER_ALERT_LABELS.get(alert, alert)
                db.insert_event(
                    "router_alert_resolved",
                    f"Попередження роутера знято: {label}",
                    success=True,
                )

        self.prev_router_alerts = current

    def _reboot_for_update_ready(self, component_label: str, reason: str) -> None:
        """Спільна логіка для _maybe_reboot_for_update/_maybe_reboot_for_router_update:
        обидва мають ідентичну послідовність дій (лише текст сповіщень
        відрізняється), винесено сюди, щоб не дублювати - зокрема захист
        MIN_REBOOT_INTERVAL_SEC/last_reboot_ts, який критично мати
        однаковим в обох місцях (див. reboot-loop баг у _maybe_reboot)."""
        now = time.time()
        if now - self.last_reboot_ts < config.MIN_REBOOT_INTERVAL_SEC:
            logger.info(
                "Оновлення ПЗ %s готове до встановлення, але пропускаю авто-reboot: "
                "останній reboot був %.0f с тому (мін. інтервал %d с)",
                component_label,
                now - self.last_reboot_ts,
                config.MIN_REBOOT_INTERVAL_SEC,
            )
            return

        logger.warning("Оновлення ПЗ %s готове до встановлення (%s) — ініціюю reboot Starlink Mini", component_label, reason)
        db.insert_event(
            "watchdog_trigger",
            f"Оновлення ПЗ {component_label} готове до встановлення ({reason}) — ініціюю reboot",
            success=True,
        )
        ok, msg = self.client.reboot_dish()
        db.insert_event("dish_reboot", msg, success=ok)
        # last_reboot_ts оновлюється завжди, навіть при невдачі - той самий
        # захист від reboot-loop, що й у _maybe_reboot() (якщо dish саме в
        # цю мить недоступний, наступний цикл не повинен повторювати
        # спробу негайно, а почекати MIN_REBOOT_INTERVAL_SEC).
        self.last_reboot_ts = now
        if ok:
            self._notify_reboot(f"🔁 Starlink Mini автоматично перезавантажено (оновлення ПЗ {component_label} готове: {reason})")
        else:
            self._notify(f"❌ Не вдалося перезавантажити Starlink Mini (оновлення ПЗ {component_label} готове): {msg}")

    def _maybe_reboot_for_router_update(self, info: RouterInfo) -> None:
        """Автоматичний reboot усього Starlink Mini, коли роутерний компонент
        повідомляє про готове до встановлення оновлення (REBOOT_PENDING або
        install_pending). Reboot виконується через dish_addr - dish і router
        фізично один пристрій, тож це перезавантажує обидва компоненти."""
        if not db.get_auto_reboot_enabled():
            return
        update_ready = info.update_state == "REBOOT_PENDING" or info.update_install_pending
        if not update_ready:
            return
        reason = info.update_state if info.update_state == "REBOOT_PENDING" else "install_pending"
        self._reboot_for_update_ready("роутера", reason)

    def _maybe_reboot_for_update(self, status: DishStatus) -> None:
        if not db.get_auto_reboot_enabled():
            return
        update_ready = status.update_state == "REBOOT_REQUIRED" or status.update_install_pending
        if not update_ready:
            return
        reason = status.update_state if status.update_state == "REBOOT_REQUIRED" else "install_pending"
        self._reboot_for_update_ready("dish", reason)

    def _maybe_reboot(self) -> None:
        if self.consecutive_failures < config.MAX_CONSECUTIVE_FAILURES:
            return

        now = time.time()
        if now - self.last_reboot_ts < config.MIN_REBOOT_INTERVAL_SEC:
            logger.info(
                "Пропускаю авто-reboot: останній reboot був %.0f с тому (мін. інтервал %d с)",
                now - self.last_reboot_ts,
                config.MIN_REBOOT_INTERVAL_SEC,
            )
            return

        failures = self.consecutive_failures
        should_log = failures <= config.MAX_LOGGED_CONSECUTIVE_FAILURES
        is_final_marker = failures == config.MAX_LOGGED_CONSECUTIVE_FAILURES + 1

        logger.warning("Ініціюю автоматичний reboot dish після %d невдалих спроб", failures)
        if should_log:
            db.insert_event(
                "watchdog_trigger",
                f"{failures} послідовних невдалих опитувань — ініціюю reboot",
                success=True,
            )
        elif is_final_marker:
            db.insert_event(
                "watchdog_trigger",
                f"Понад {config.MAX_LOGGED_CONSECUTIVE_FAILURES} послідовних невдалих опитувань — "
                "подальші спроби reboot не записуються в журнал до відновлення зв'язку",
                success=False,
            )

        ok, msg = self.client.reboot_dish()
        if should_log or is_final_marker:
            db.insert_event("dish_reboot", msg, success=ok)
        # last_reboot_ts оновлюється завжди, навіть при невдачі: якщо dish
        # ще перезавантажується з попередньої спроби, команда reboot теж
        # провалиться (grpcurl: connection refused) - без цього watchdog
        # намагався б "перезавантажити" вже перезавантажуваний dish щоцикл,
        # ігноруючи MIN_REBOOT_INTERVAL_SEC (справжній reboot-loop).
        self.last_reboot_ts = now
        if ok:
            self.consecutive_failures = 0
            if not self._notifications_muted():
                self._notify_reboot(f"🔁 Starlink Mini автоматично перезавантажено (dish не відповідав {failures} спроб поспіль)")

    def run_forever(self) -> None:
        db.init_db()
        logger.info("Starlink watchdog запущено. Опитування кожні %d с.", config.POLL_INTERVAL_SEC)

        from app.telegram_bot import TelegramBot
        telegram_bot = TelegramBot()
        telegram_bot.start()

        from app import speedtest_runner
        speedtest_stop = threading.Event()
        speedtest_thread = threading.Thread(
            target=speedtest_runner.run_forever, args=(speedtest_stop,), daemon=True
        )
        speedtest_thread.start()

        # "Прогрів" psutil.cpu_percent: перший виклик без базового заміру
        # завжди повертає 0.0, тому робимо його тут і відкидаємо результат.
        psutil.cpu_percent(interval=None)
        last_prune = 0.0
        last_vacuum = 0.0
        last_router_poll = 0.0  # 0 гарантує негайне перше опитування роутера
        while True:
            try:
                self.poll_once()
            except Exception as e:
                logger.exception("Неочікувана помилка в циклі опитування: %s", e)

            self.poll_system_metrics()

            # Роутерний компонент опитуємо рідше (раз на ~60с), бо його
            # версія прошивки змінюється нечасто, і зайве навантаження
            # на WiFi-канал непотрібне при опитуванні dish кожні 10с.
            if time.time() - last_router_poll > 60:
                self.poll_router()
                last_router_poll = time.time()

            if time.time() - last_prune > 3600:
                try:
                    db.prune_old()
                    buckets = db.downsample_old_metrics()
                    if buckets:
                        logger.info("Downsampling: агреговано %d bucket-ів старих метрик", buckets)
                except Exception:
                    logger.exception("Помилка очищення старих записів")
                last_prune = time.time()

            if time.time() - last_vacuum > 86400:
                try:
                    logger.info("Періодична оптимізація БД (VACUUM + ANALYZE)")
                    db.vacuum_and_analyze()
                except Exception:
                    logger.exception("Помилка VACUUM/ANALYZE")
                last_vacuum = time.time()

            time.sleep(config.POLL_INTERVAL_SEC)


def main() -> None:
    Watchdog().run_forever()


if __name__ == "__main__":
    main()
