"""SQLite шар для історії метрик Starlink та журналу подій (reboot, оновлення)."""
import json
import os
import re
import sqlite3
import time
from contextlib import contextmanager
from typing import Any, Callable, Iterator, Optional

from app import config

# Формат backup-файлу (ручний через веб-кнопку і автоматичний
# періодичний, обидва в monitor.build_backup_dict()) - тут, не в
# webapp.py, щоб бути доступною з monitor.py без циклічного імпорту
# (webapp.py вже імпортує monitor, тому monitor не може імпортувати
# щось із webapp.py).
BACKUP_FORMAT_VERSION = 3

# Опційний callback для LED активності SD-картки (app/activity_led.py),
# викликається get_conn() після кожного успішного commit. None за
# замовчуванням - жодних накладних витрат, якщо LED вимкнено чи не
# зареєстрований (webapp.py-процес свідомо цього не робить, лише
# watchdog-процес monitor.py, де відбувається основний обсяг записів).
_activity_callback: Optional[Callable[[], None]] = None


def set_activity_callback(callback: Optional[Callable[[], None]]) -> None:
    global _activity_callback
    _activity_callback = callback

SCHEMA = """
CREATE TABLE IF NOT EXISTS metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    online INTEGER NOT NULL,
    state TEXT,
    uptime_s INTEGER,
    downlink_mbps REAL,
    uplink_mbps REAL,
    ping_latency_ms REAL,
    ping_drop_ratio REAL,
    obstruction_fraction REAL,
    currently_obstructed INTEGER,
    software_version TEXT,
    hardware_version TEXT,
    dish_id TEXT,
    error TEXT,
    update_state TEXT,
    update_progress_pct REAL,
    update_requires_reboot INTEGER,
    update_install_pending INTEGER,
    active_alerts TEXT
);
CREATE INDEX IF NOT EXISTS idx_metrics_ts ON metrics(ts);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    kind TEXT NOT NULL,       -- 'dish_reboot', 'watchdog_trigger', 'update_state_change', ...
    message TEXT,
    success INTEGER,
    count INTEGER NOT NULL DEFAULT 1,
    last_ts REAL
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);

CREATE TABLE IF NOT EXISTS system_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    uptime_s INTEGER,
    cpu_percent REAL,
    mem_total_mb REAL,
    mem_used_mb REAL,
    mem_free_mb REAL,
    disk_total_gb REAL,
    disk_used_gb REAL,
    disk_free_gb REAL,
    temp_c REAL
);
CREATE INDEX IF NOT EXISTS idx_system_metrics_ts ON system_metrics(ts);

CREATE TABLE IF NOT EXISTS router_status (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    ts REAL NOT NULL,
    online INTEGER NOT NULL,
    software_version TEXT,
    hardware_version TEXT,
    bootcount INTEGER,
    error TEXT,
    update_state TEXT,
    update_progress_pct REAL,
    update_install_pending INTEGER,
    active_alerts TEXT,
    clients TEXT
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS known_devices (
    dish_id TEXT PRIMARY KEY,
    first_seen_ts REAL NOT NULL,
    last_seen_ts REAL NOT NULL,
    dish_hardware_version TEXT,
    dish_software_version TEXT,
    dish_software_updated_ts REAL,
    router_hardware_version TEXT,
    router_software_version TEXT,
    router_software_updated_ts REAL
);
"""


def _ensure_dir() -> None:
    d = os.path.dirname(config.DB_PATH)
    if d:
        os.makedirs(d, exist_ok=True)


@contextmanager
def get_conn() -> Iterator[sqlite3.Connection]:
    _ensure_dir()
    conn = sqlite3.connect(config.DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    # WAL: monitor.service (пише кожні ~10с) і webui.service (читає щосекунди)
    # - окремі процеси, що звертаються до одного файлу одночасно. У режимі
    # за замовчуванням (rollback journal) запис блокує читання на час
    # транзакції; WAL дозволяє паралельне читання під час запису.
    conn.execute("PRAGMA journal_mode=WAL")
    # NORMAL (не дефолтний FULL) - офіційно рекомендований режим для
    # WAL (sqlite.org/pragma.html#pragma_synchronous): fsync лише при
    # checkpoint, не на кожному commit - значно менше фізичних записів
    # на SD-картку. БД лишається захищеною від пошкодження (WAL це
    # гарантує); ризик - втрата лише кількох останніх транзакцій при
    # раптовому вимкненні живлення, не критично для метрик моніторингу.
    conn.execute("PRAGMA synchronous=NORMAL")
    try:
        yield conn
        conn.commit()
        # Лише ПІСЛЯ успішного commit (не при винятку/rollback) -
        # опційний хук для LED активності SD-картки (app/activity_led.py).
        # Реєструється watchdog-процесом через set_activity_callback();
        # без реєстрації (LED вимкнено чи це webapp.py-процес, який не
        # ініціалізує LED) - _activity_callback лишається None, немає
        # накладних витрат.
        if _activity_callback is not None:
            try:
                _activity_callback()
            except Exception:
                pass
    finally:
        conn.close()


def init_db() -> None:
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        _migrate_table_columns(conn, "metrics", {
            "update_state": "TEXT",
            "update_progress_pct": "REAL",
            "update_requires_reboot": "INTEGER",
            "update_install_pending": "INTEGER",
            "active_alerts": "TEXT",
            "hardware_version": "TEXT",
            "dish_id": "TEXT",
        })
        _migrate_table_columns(conn, "router_status", {
            "update_state": "TEXT",
            "update_progress_pct": "REAL",
            "update_install_pending": "INTEGER",
            "active_alerts": "TEXT",
            "clients": "TEXT",
        })
        _migrate_table_columns(conn, "events", {
            "count": "INTEGER NOT NULL DEFAULT 1",
            "last_ts": "REAL",
        })


def _migrate_table_columns(conn: sqlite3.Connection, table: str, new_columns: dict[str, str]) -> None:
    """Додає нові колонки в уже існуючу таблицю (для баз, створених до
    появи цих полів). CREATE TABLE IF NOT EXISTS не чіпає існуючу
    таблицю, тому колонки додаємо окремо через ALTER TABLE."""
    existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
    for col, col_type in new_columns.items():
        if col not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {col_type}")


def _metric_row_params(status_dict: dict[str, Any]) -> tuple[Any, ...]:
    """Формує tuple параметрів для INSERT у metrics - спільний helper
    для insert_metric() (один рядок) і insert_metrics_batch() (кілька
    рядків через executemany), щоб не дублювати той самий список
    status_dict.get(...) двічі."""
    return (
        status_dict["timestamp"],
        int(status_dict["online"]),
        status_dict.get("state", ""),
        status_dict.get("uptime_s", 0),
        status_dict.get("downlink_mbps", 0),
        status_dict.get("uplink_mbps", 0),
        status_dict.get("ping_latency_ms", 0),
        status_dict.get("ping_drop_ratio", 0),
        status_dict.get("obstruction_fraction", 0),
        status_dict.get("software_version", ""),
        status_dict.get("hardware_version", ""),
        status_dict.get("dish_id", ""),
        status_dict.get("error", ""),
        status_dict.get("update_state", ""),
        status_dict.get("update_progress_pct", 0),
        int(status_dict.get("update_requires_reboot", False)),
        int(status_dict.get("update_install_pending", False)),
        status_dict.get("active_alerts", "[]"),
    )


# currently_obstructed НАВМИСНО не заповнюється (лишається NULL для
# нових рядків) - аудит показав, що ця колонка ніколи не читається
# ніде (дашборд показує лише obstruction_fraction, реальний відсоток
# обструкції); write-only колонка без користі. Схема лишається як є
# (без DROP COLUMN) - менший ризик для вже існуючих БД на реальних
# пристроях, ніж зміна схеми.
_INSERT_METRIC_SQL = """INSERT INTO metrics
   (ts, online, state, uptime_s, downlink_mbps, uplink_mbps,
    ping_latency_ms, ping_drop_ratio, obstruction_fraction,
    software_version, hardware_version, dish_id, error,
    update_state, update_progress_pct, update_requires_reboot,
    update_install_pending, active_alerts)
   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"""


def insert_metric(status_dict: dict[str, Any]) -> None:
    with get_conn() as conn:
        conn.execute(_INSERT_METRIC_SQL, _metric_row_params(status_dict))


def insert_metrics_batch(status_dicts: list[dict[str, Any]]) -> None:
    """Записує КІЛЬКА dish-зчитувань ОДНІЄЮ транзакцією (SD-card-wear
    reduction - замість окремого write-транзакції на кожні 10с,
    накопичені в пам'яті зчитування пишуться разом раз на
    DISH_METRICS_BATCH_INTERVAL_SEC). Порожній список - тихо нічого
    не робить (не відкриває з'єднання даремно)."""
    if not status_dicts:
        return
    with get_conn() as conn:
        conn.executemany(_INSERT_METRIC_SQL, [_metric_row_params(d) for d in status_dicts])


def _json_field(raw: Any) -> list[Any]:
    """Парсить JSON-серіалізоване поле (active_alerts, clients) назад у
    список, з безпечним fallback на порожній список при відсутності чи
    пошкодженні даних. Спільний хелпер для трьох місць, де раніше було
    дубльовано той самий try/except json.loads блок."""
    if not raw:
        return []
    try:
        return json.loads(raw)
    except (TypeError, json.JSONDecodeError):
        return []


def insert_event(kind: str, message: str, success: bool = True) -> None:
    """Записує подію в журнал. Якщо остання подія має той самий
    kind і message (типово - серія однакових попереджень підряд),
    замість нового рядка інкрементує count і оновлює ts існуючого
    запису - журнал не засмічується повторами. last_ts НАВМИСНО не
    оновлюється (лишається NULL) - аудит показав, що ця колонка
    ніколи не читалась ніде, і навіть якби читалась, дублювала б ts
    (обидві завжди отримували те саме значення now в одному UPDATE)."""
    now = time.time()
    with get_conn() as conn:
        last = conn.execute(
            "SELECT id, kind, message FROM events ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if last is not None and last["kind"] == kind and last["message"] == message:
            conn.execute(
                "UPDATE events SET ts = ?, count = count + 1, success = ? WHERE id = ?",
                (now, int(success), last["id"]),
            )
        else:
            conn.execute(
                "INSERT INTO events (ts, kind, message, success, count) VALUES (?,?,?,?,1)",
                (now, kind, message, int(success)),
            )


def insert_system_metric(m: dict[str, Any]) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO system_metrics
               (ts, uptime_s, cpu_percent, mem_total_mb, mem_used_mb, mem_free_mb,
                disk_total_gb, disk_used_gb, disk_free_gb, temp_c)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (
                m["timestamp"],
                m.get("uptime_s", 0),
                m.get("cpu_percent", 0),
                m.get("mem_total_mb", 0),
                m.get("mem_used_mb", 0),
                m.get("mem_free_mb", 0),
                m.get("disk_total_gb", 0),
                m.get("disk_used_gb", 0),
                m.get("disk_free_gb", 0),
                m.get("temp_c"),
            ),
        )


def set_router_status(r: dict[str, Any]) -> None:
    """Записує останній відомий стан роутера. Таблиця завжди містить
    рівно один рядок (id=1) - історія не потрібна, лише поточний стан.
    bootcount НАВМИСНО не заповнюється (лишається NULL) - аудит показав,
    що ця колонка ніколи не читається ніде (не відображається на
    дашборді); write-only колонка без користі. Схема лишається як є
    (без DROP COLUMN) - менший ризик для вже існуючих БД на реальних
    пристроях, ніж зміна схеми."""
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO router_status
               (id, ts, online, software_version, hardware_version, error,
                update_state, update_progress_pct, update_install_pending, active_alerts, clients)
               VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                 ts=excluded.ts, online=excluded.online,
                 software_version=excluded.software_version,
                 hardware_version=excluded.hardware_version,
                 error=excluded.error,
                 update_state=excluded.update_state,
                 update_progress_pct=excluded.update_progress_pct,
                 update_install_pending=excluded.update_install_pending,
                 active_alerts=excluded.active_alerts,
                 clients=excluded.clients""",
            (
                r["timestamp"],
                int(r["online"]),
                r.get("software_version", ""),
                r.get("hardware_version", ""),
                r.get("error", ""),
                r.get("update_state", ""),
                r.get("update_progress_pct", 0),
                int(r.get("update_install_pending", False)),
                r.get("active_alerts", "[]"),
                r.get("clients", "[]"),
            ),
        )


def get_router_status() -> Optional[dict[str, Any]]:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM router_status WHERE id = 1").fetchone()
        if not row:
            return None
        d = dict(row)
        d["active_alerts"] = _json_field(d.get("active_alerts"))
        d["clients"] = _json_field(d.get("clients"))
        return d


def get_latest_system_metric() -> Optional[dict[str, Any]]:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM system_metrics ORDER BY ts DESC LIMIT 1").fetchone()
        return dict(row) if row else None


def _parse_metric_row(row: dict[str, Any]) -> dict[str, Any]:
    """Розпарсити JSON-серіалізований active_alerts назад у список для API."""
    row["active_alerts"] = _json_field(row.get("active_alerts"))
    return row


def get_recent_events(limit: int = 50) -> list[dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM events ORDER BY ts DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def get_latest_metric() -> Optional[dict[str, Any]]:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM metrics ORDER BY ts DESC LIMIT 1").fetchone()
        return _parse_metric_row(dict(row)) if row else None


def prune_old(days: Optional[int] = None) -> None:
    # Явна перевірка на None, не `days or config.X` - 0 є легітимним
    # (хоч і нетиповим) значенням days, яке `or`-патерн мовчки
    # ігнорував би (0 falsy в Python), підміняючи дефолтом.
    if days is None:
        days = config.HISTORY_RETENTION_DAYS
    cutoff = time.time() - days * 86400
    with get_conn() as conn:
        conn.execute("DELETE FROM metrics WHERE ts < ?", (cutoff,))
        conn.execute("DELETE FROM events WHERE ts < ?", (cutoff,))
        conn.execute("DELETE FROM system_metrics WHERE ts < ?", (cutoff,))


def vacuum_and_analyze() -> None:
    """Періодична оптимізація БД: VACUUM звільняє місце після DELETE в
    prune_old() (SQLite не повертає диску вільні сторінки автоматично),
    ANALYZE оновлює статистику планувальника запитів. Викликається
    рідше за prune_old (раз на добу, не щогодини) - VACUUM вимагає
    ексклюзивного доступу й тимчасово до 2x розміру файлу на диску,
    непотрібно робити це часто на SD-картці. Окреме з'єднання (не
    get_conn(), який лишає WAL-режим) - VACUUM в WAL-режимі працює,
    але надійніше й простіше з чистим autocommit-з'єднанням."""
    conn = sqlite3.connect(config.DB_PATH, timeout=30)
    try:
        conn.execute("VACUUM")
        conn.execute("ANALYZE")
    finally:
        conn.close()


def check_integrity() -> tuple[bool, str]:
    """PRAGMA quick_check - швидша за повний integrity_check перевірка
    (не перевіряє UNIQUE-обмеження, для нашого use-case достатньо).
    Виявляє мовчазну деградацію БД (напр. після раптового вимкнення
    живлення в незручний момент WAL-checkpoint) ДО того, як вона
    стане критичною - без цього проєкт дізнався б про пошкодження
    лише постфактум, з незрозумілих помилок при читанні/записі.
    Повертає (ok, message) - "ok" при порожньому результаті (SQLite-
    конвенція: quick_check повертає рядок "ok", якщо все гаразд, і
    список конкретних проблем, якщо ні)."""
    conn = sqlite3.connect(config.DB_PATH, timeout=30)
    try:
        rows = conn.execute("PRAGMA quick_check").fetchall()
    except sqlite3.DatabaseError as e:
        # Файл ВЗАГАЛІ не є SQLite-базою (не просто пошкоджені дані
        # всередині) - PRAGMA quick_check сам кидає виняток замість
        # повернення результату в цьому крайньому випадку. Знайдено
        # живим тестом одразу після першої реалізації - без цього
        # DatabaseError поширювався б назовні, замість повернення
        # (False, message), яке викликаючий код очікує.
        return False, f"файл не є валідною SQLite-базою: {e}"
    finally:
        conn.close()
    messages = [str(r[0]) for r in rows]
    if messages == ["ok"]:
        return True, "ok"
    return False, "; ".join(messages)


def uptime_stats_24h() -> Optional[float]:
    """Частка часу online за останні 24 години (для дашборду)."""
    cutoff = time.time() - 86400
    with get_conn() as conn:
        row = conn.execute(
            "SELECT COUNT(*) as total, SUM(online) as up FROM metrics WHERE ts > ?",
            (cutoff,),
        ).fetchone()
        if not row or not row["total"]:
            return None
        return round(100.0 * (row["up"] or 0) / row["total"], 2)


def _upsert_known_device(dish_id: str, component: str, hardware_version: str, software_version: str) -> tuple[bool, Optional[str]]:
    """Спільна логіка для upsert_known_device_dish()/_router() -
    обидві були продубльовані майже ідентично, відрізняючись лише
    column-префіксом (dish_/router_). SQLite не дозволяє параметризувати
    НАЗВИ колонок через `?`-placeholder (лише значення), тому вони
    підставляються через f-string - `component` МАЄ бути internal
    literal ("dish"/"router"), НЕ user input; явний `assert` тут -
    останній захист навіть для internal-виклику."""
    assert component in ("dish", "router"), f"невідомий компонент: {component!r}"
    if not dish_id:
        return False, None
    now = time.time()
    hw_col = f"{component}_hardware_version"
    sw_col = f"{component}_software_version"
    ts_col = f"{component}_software_updated_ts"
    with get_conn() as conn:
        existing = conn.execute(
            f"SELECT {sw_col} FROM known_devices WHERE dish_id = ?", (dish_id,)
        ).fetchone()
        old_version = existing[sw_col] if existing else None
        version_changed = existing is None or old_version != software_version
        real_change = old_version is not None and old_version != software_version

        conn.execute(
            f"""INSERT INTO known_devices
               (dish_id, first_seen_ts, last_seen_ts, {hw_col}, {sw_col}, {ts_col})
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(dish_id) DO UPDATE SET
                 last_seen_ts = excluded.last_seen_ts,
                 {hw_col} = excluded.{hw_col},
                 {sw_col} = excluded.{sw_col},
                 {ts_col} = CASE WHEN ? THEN excluded.{ts_col}
                                  ELSE known_devices.{ts_col} END""",
            (dish_id, now, now, hardware_version, software_version, now if version_changed else None,
             int(version_changed)),
        )
    return real_change, old_version


def upsert_known_device_dish(dish_id: str, hardware_version: str, software_version: str) -> tuple[bool, Optional[str]]:
    """Записує/оновлює відому інформацію про dish для конкретного dish_id.
    dish_software_updated_ts оновлюється лише коли software_version реально
    змінилась відносно попереднього запису (не при кожному опитуванні) -
    так /id у Telegram-боті може показати, коли саме відбулось останнє
    встановлене оновлення, а не час останнього опитування.

    Повертає (real_change, old_version): real_change=True лише коли
    dish_id вже був відомий РАНІШЕ і версія відрізняється (перший
    запис для нового dish_id - НЕ "зміна", просто перше знайомство)."""
    return _upsert_known_device(dish_id, "dish", hardware_version, software_version)


def upsert_known_device_router(dish_id: str, hardware_version: str, software_version: str) -> tuple[bool, Optional[str]]:
    """Аналогічно до upsert_known_device_dish, але для роутерної частини
    того самого фізичного Mini. Прив'язується до того ж dish_id - dish і
    router опитуються в різних циклах, тому оновлюються окремо; якщо
    запису для dish_id ще немає (router опитався раніше за dish), рядок
    створюється з порожніми dish-полями.

    Повертає (real_change, old_version) - див. upsert_known_device_dish."""
    return _upsert_known_device(dish_id, "router", hardware_version, software_version)


def get_known_device(dish_id: str) -> Optional[dict[str, Any]]:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM known_devices WHERE dish_id = ?", (dish_id,)).fetchone()
        return dict(row) if row else None


def get_all_known_devices() -> list[dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM known_devices ORDER BY last_seen_ts DESC").fetchall()
        return [dict(r) for r in rows]


def merge_known_devices(devices: list[dict[str, Any]]) -> int:
    """Відновлення known_devices з backup - НЕ перезаписує dish_id,
    що вже є в цільовій БД (INSERT OR IGNORE), навіть якщо в backup
    дані виглядають "новішими" за датою файлу: локальна БД реально
    працюючого watchdog'а вважається авторитетнішою за статичний
    backup-знімок з невідомо якого моменту в минулому - той самий
    принцип обережності, що вже застосований до target-версій
    (не перезаписувати потенційно свіжіший стан старішими даними).
    Повертає кількість РЕАЛЬНО доданих (нових) dish_id."""
    added = 0
    with get_conn() as conn:
        for d in devices:
            if "dish_id" not in d:
                continue
            cursor = conn.execute(
                """INSERT OR IGNORE INTO known_devices
                   (dish_id, first_seen_ts, last_seen_ts, dish_hardware_version,
                    dish_software_version, dish_software_updated_ts,
                    router_hardware_version, router_software_version,
                    router_software_updated_ts)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    d["dish_id"], d.get("first_seen_ts"), d.get("last_seen_ts"),
                    d.get("dish_hardware_version"), d.get("dish_software_version"),
                    d.get("dish_software_updated_ts"), d.get("router_hardware_version"),
                    d.get("router_software_version"), d.get("router_software_updated_ts"),
                ),
            )
            if cursor.rowcount > 0:
                added += 1
    return added


def parse_version_list(raw: Optional[str]) -> list[str]:
    """Розбирає comma-separated список версій прошивки (той самий
    формат, що telegram_chat_ids) - корисно, коли SpaceX випускає
    РІЗНІ номери версій для різних апаратних ревізій під однією
    умовною версією. Спільний helper для monitor.py (перевірка
    досягнення) і webapp.py (валідація "лише новіші" для КОЖНОГО
    кандидата окремо) - уникає дублювання парсингу в обох місцях."""
    if not raw:
        return []
    return [v.strip() for v in raw.split(",") if v.strip()]


def version_channel(v: str) -> Optional[str]:
    """Витягує 'канал' білда з версії прошивки - буквений префікс
    перед цифрами в build-сегменті (напр. 'mr' з 'mr82648', 'cr' з
    'cr81950'). Різні апаратні ревізії Starlink можуть отримувати
    оновлення з РІЗНИХ, незалежних build-каналів - порівнювати дату
    напряму МІЖ каналами не має сенсу (знайдено на реальному запиті
    користувача: '2026.07.06.cr81950...' хибно відхилявся як
    "старіший" за '2026.07.19.mr82648' - обидва можуть бути
    легітимними, актуальними версіями для СВОЇХ окремих апаратних
    ревізій одночасно, просто з різних build-каналів). None якщо
    жоден сегмент не відповідає паттерну (нетиповий формат версії)."""
    for segment in v.split("."):
        m = re.match(r"^([a-zA-Z]+)\d+", segment)
        if m:
            return m.group(1).lower()
    return None


def version_key(v: str) -> tuple[tuple[int, int, int], tuple[Any, ...]]:
    """Толерантний ключ порівняння версій прошивки Starlink (формат
    зазвичай YYYY.MM.DD.mrXXXXX.N, не строгий semver). YYYY.MM.DD-
    префікс домінує (дата - найнадійніший індикатор "новіше"); якщо
    дата однакова чи відсутня в обох - посегментне порівняння
    ('.'-розділені частини: числові сегменти як int, нечислові як
    рядок, щоб не впасти на нетиповому форматі). Спільний, публічний
    (не webapp.py-приватний) - потрібен і для валідації target-версій
    (webapp.py), і для розрізнення "🔄 оновлено" vs "⏪ відкочено" у
    сповіщеннях про зміну прошивки (monitor.py)."""
    m = re.match(r"^(\d{4})\.(\d{2})\.(\d{2})", v)
    date_part = (int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else (0, 0, 0)
    segments = tuple((0, int(seg)) if seg.isdigit() else (1, seg) for seg in v.split("."))
    return date_part, segments


def is_older_version(candidate: str, baseline: str) -> bool:
    return version_key(candidate) < version_key(baseline)


def get_setting(key: str, default: Optional[str] = None) -> Optional[str]:
    with get_conn() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO settings (key, value) VALUES (?, ?)
               ON CONFLICT(key) DO UPDATE SET value=excluded.value""",
            (key, value),
        )


def get_auto_reboot_enabled() -> bool:
    """Runtime-перемикач автоматичного reboot dish/router при готовому
    оновленні. Якщо ще не встановлювався через веб-інтерфейс - бере
    значення за замовчуванням з config.AUTO_REBOOT_ON_UPDATE_READY
    (змінна середовища STARLINK_AUTO_REBOOT_ON_UPDATE)."""
    val = get_setting("auto_reboot_enabled")
    if val is None:
        return config.AUTO_REBOOT_ON_UPDATE_READY
    return val == "1"


def set_auto_reboot_enabled(enabled: bool) -> None:
    set_setting("auto_reboot_enabled", "1" if enabled else "0")
