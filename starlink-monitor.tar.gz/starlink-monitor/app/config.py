"""
Конфігурація Starlink Monitor. Перевизначається через змінні
середовища (systemd EnvironmentFile) або /etc/starlink-monitor/config.local.py.
Повний опис змінних - README.md, таблиця "Конфігурація".
"""
import os

DISH_ADDR = os.environ.get("STARLINK_DISH_ADDR", "192.168.100.1:9200")
DISH_HTTP_TIMEOUT = float(os.environ.get("STARLINK_DISH_TIMEOUT", "5"))
ROUTER_ADDR = os.environ.get("STARLINK_ROUTER_ADDR", "192.168.1.1:9000")

POLL_INTERVAL_SEC = int(os.environ.get("STARLINK_POLL_INTERVAL", "10"))
MAX_CONSECUTIVE_FAILURES = int(os.environ.get("STARLINK_MAX_FAILURES", "6"))  # 6*10s = 60s недоступності
MIN_REBOOT_INTERVAL_SEC = int(os.environ.get("STARLINK_MIN_REBOOT_INTERVAL", "120"))  # захист від reboot-loop
OBSTRUCTION_WARN_FRACTION = float(os.environ.get("STARLINK_OBSTRUCTION_WARN", "0.05"))

# Якщо dish недоступний (WiFi Starlink відсутня) довше цього часу -
# Telegram-сповіщення про спроби auto-reboot тимчасово припиняються
# (подія й далі пишеться в журнал дашборду). Відновлення зв'язку
# завжди повідомляється, незалежно від тривалості мовчання.
NOTIFICATIONS_MUTE_AFTER_SEC = int(os.environ.get("STARLINK_NOTIFICATIONS_MUTE_AFTER", "900"))

# При тривалій безперервній недоступності dish кожна watchdog-спроба
# reboot (кожні MIN_REBOOT_INTERVAL_SEC) і далі пишеться в журнал/БД
# з дедалі більшим лічильником невдалих опитувань - засмічує журнал
# без нової корисної інформації. Після цієї кількості послідовних
# спроб записи в журнал/БД припиняються (сама спроба reboot триває
# нормально); один фінальний запис позначає момент припинення.
MAX_LOGGED_CONSECUTIVE_FAILURES = int(os.environ.get("STARLINK_MAX_LOGGED_FAILURES", "30"))

# reboot при software_update_state==REBOOT_REQUIRED або alerts.install_pending
AUTO_REBOOT_ON_UPDATE_READY = os.environ.get("STARLINK_AUTO_REBOOT_ON_UPDATE", "1") == "1"

DB_PATH = os.environ.get("STARLINK_DB_PATH", "/var/lib/starlink-monitor/history.db")
HISTORY_RETENTION_DAYS = int(os.environ.get("STARLINK_HISTORY_DAYS", "30"))

WEBUI_HOST = os.environ.get("STARLINK_WEBUI_HOST", "0.0.0.0")
WEBUI_PORT = int(os.environ.get("STARLINK_WEBUI_PORT", "8080"))

# GPIO BCM pin для фізичної кнопки виключення; 0 = вимкнено (за замовчуванням)
SHUTDOWN_BUTTON_GPIO_PIN = int(os.environ.get("STARLINK_SHUTDOWN_BUTTON_PIN", "0"))
SHUTDOWN_BUTTON_HOLD_SEC = float(os.environ.get("STARLINK_SHUTDOWN_BUTTON_HOLD_SEC", "3"))

# Періодичний реальний speedtest (не лише пропускна здатність з телеметрії
# dish, яка показує "заявлений" канал, не реальну користувацьку швидкість
# крізь весь маршрут до інтернету). Вимкнено за замовчуванням - тест
# споживає реальний трафік (десятки-сотні МБ на прогін) і на кілька
# секунд навантажує WiFi-радіомодуль, який dish/router також
# використовують для локального опитування.
SPEEDTEST_ENABLED = os.environ.get("STARLINK_SPEEDTEST_ENABLED", "0") == "1"
SPEEDTEST_INTERVAL_SEC = int(os.environ.get("STARLINK_SPEEDTEST_INTERVAL", "1800"))  # двічі/год

_local_cfg = "/etc/starlink-monitor/config.local.py"
if os.path.exists(_local_cfg):
    with open(_local_cfg) as f:
        exec(f.read())
