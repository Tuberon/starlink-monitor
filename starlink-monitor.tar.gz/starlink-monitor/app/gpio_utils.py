"""
Спільна gpiod v1/v2 сумісна логіка читання цифрового GPIO-входу
(pull-up, LOW = натиснуто) - винесено з shutdown_button.py, бо той
самий патерн тепер потрібен і в display.py (та сама кнопка
виключення: коротке натискання перемикає підсвітку, довге вимикає Pi).
"""
import os
from typing import Any, Callable, Optional


def find_gpio_chip() -> str:
    """На різних версіях Raspberry Pi OS/ядра основний GPIO-чіп може
    бути gpiochip0 або інший номер (напр. після додавання HAT-плат,
    які теж реєструють свої chip'и). Перебираємо перші кілька."""
    for i in range(6):
        path = f"/dev/gpiochip{i}"
        if os.path.exists(path):
            return path
    return "/dev/gpiochip0"


def _init_line_v2(
    gpiod: Any, chip_path: str, pin: int, consumer: str
) -> tuple[Callable[[], int], Callable[[], None]]:
    """gpiod >= 2.0: gpiod.request_lines() з LineSettings, значення
    читається через request.get_value(pin) (повертає Value.ACTIVE/INACTIVE,
    не 0/1 як у v1)."""
    from gpiod.line import Direction, Bias

    request = gpiod.request_lines(
        chip_path,
        consumer=consumer,
        config={pin: gpiod.LineSettings(direction=Direction.INPUT, bias=Bias.PULL_UP)},
    )

    def get_value() -> int:
        from gpiod.line import Value
        return 0 if request.get_value(pin) == Value.INACTIVE else 1

    def release() -> None:
        request.release()

    return get_value, release


def _init_line_v1(
    gpiod: Any, chip_path: str, pin: int, consumer: str
) -> tuple[Callable[[], int], Callable[[], None]]:
    """gpiod < 2.0 (застарілий API): chip.get_line() + line.request()."""
    chip = gpiod.Chip(chip_path)
    line = chip.get_line(pin)
    line.request(consumer=consumer, type=gpiod.LINE_REQ_DIR_IN,
                 flags=gpiod.LINE_REQ_FLAG_BIAS_PULL_UP)

    def get_value() -> int:
        value: int = line.get_value()
        return value

    def release() -> None:
        line.release()

    return get_value, release


def _gpiod_is_v2(gpiod: Any) -> bool:
    """gpiod v2.x видалив Chip.get_line() (звідси hasattr-перевірка) на користь request_lines() - API повністю
    несумісний зі старим v1.x. Raspberry Pi OS Bookworm+ ставить v2 через apt python3-libgpiod."""
    return not hasattr(gpiod.Chip, "get_line")


def open_input_line(pin: int, consumer: str) -> tuple[Callable[[], int], Callable[[], None]]:
    """Відкриває GPIO-пін як цифровий вхід з pull-up (сумісно з gpiod
    v1 і v2). Повертає (get_value, release) або кидає виняток, якщо
    gpiod не встановлено чи ініціалізація провалилась - виклик має
    сам обробити except."""
    import gpiod

    chip_path = find_gpio_chip()
    if _gpiod_is_v2(gpiod):
        return _init_line_v2(gpiod, chip_path, pin, consumer)
    return _init_line_v1(gpiod, chip_path, pin, consumer)


def _init_output_line_v2(
    gpiod: Any, chip_path: str, pin: int, consumer: str
) -> tuple[Callable[[int], None], Callable[[], None]]:
    """gpiod >= 2.0: той самий request_lines(), але Direction.OUTPUT
    замість INPUT - без Bias (не потрібен для виходу)."""
    from gpiod.line import Direction, Value

    request = gpiod.request_lines(
        chip_path,
        consumer=consumer,
        config={pin: gpiod.LineSettings(direction=Direction.OUTPUT)},
    )

    def set_value(value: int) -> None:
        request.set_value(pin, Value.ACTIVE if value else Value.INACTIVE)

    def release() -> None:
        request.release()

    return set_value, release


def _init_output_line_v1(
    gpiod: Any, chip_path: str, pin: int, consumer: str
) -> tuple[Callable[[int], None], Callable[[], None]]:
    """gpiod < 2.0 (застарілий API): LINE_REQ_DIR_OUT замість _IN."""
    chip = gpiod.Chip(chip_path)
    line = chip.get_line(pin)
    line.request(consumer=consumer, type=gpiod.LINE_REQ_DIR_OUT)

    def set_value(value: int) -> None:
        line.set_value(1 if value else 0)

    def release() -> None:
        line.release()

    return set_value, release


def open_output_line(pin: int, consumer: str) -> tuple[Callable[[int], None], Callable[[], None]]:
    """Відкриває GPIO-пін як цифровий вихід (сумісно з gpiod v1 і v2) -
    симетрична до open_input_line(), для LED/реле/іншої периферії, яку
    МИ вмикаємо, а не читаємо. Повертає (set_value, release) або
    кидає виняток, якщо gpiod не встановлено чи ініціалізація
    провалилась - виклик має сам обробити except."""
    import gpiod

    chip_path = find_gpio_chip()
    if _gpiod_is_v2(gpiod):
        return _init_output_line_v2(gpiod, chip_path, pin, consumer)
    return _init_output_line_v1(gpiod, chip_path, pin, consumer)


class ButtonPressTracker:
    """Відстежує натискання/утримання кнопки (pull-up, LOW=натиснуто): чиста, стейтфул структура без
    залежності від GPIO, тестується довільною послідовністю значень через poll(). poll(value) повертає:
    "long_press" — утримано довше hold_sec (рівно один раз, у момент досягнення порогу); "short_press" —
    відпущено до порогу; None — нічого (ідле, утримання нижче порогу, або відпускання після вже
    спрацьованого long_press). Використовується в shutdown_button.py (long_press) і display.py
    (short_press → підсвітка, long_press → shutdown).
    """
    def __init__(self, hold_sec: float) -> None:
        self.hold_sec = hold_sec
        self._pressed_since: Optional[float] = None
        self._triggered = False

    def poll(self, value: int, now: Optional[float] = None) -> Optional[str]:
        import time as _time
        now = now if now is not None else _time.time()
        is_pressed = (value == 0)

        if is_pressed:
            if self._pressed_since is None:
                self._pressed_since = now
            elif not self._triggered and (now - self._pressed_since) >= self.hold_sec:
                self._triggered = True
                return "long_press"
        else:
            was_pressed = self._pressed_since is not None
            was_triggered = self._triggered
            self._pressed_since = None
            self._triggered = False
            if was_pressed and not was_triggered:
                return "short_press"
        return None
