"""gRPC-клієнт Starlink dish (192.168.100.1:9200) і router (192.168.1.1:9000) — два логічні пристрої в
одному корпусі Mini, кожен зі своєю прошивкою. get_status(): starlink_grpc.get_status()
(starlink-grpc-tools), сирий protobuf DishGetStatusResponse. get_router_info(): grpcurl subprocess,
payload {"get_status":{}} на адресу router (інша схема, WifiGetStatusResponse). reboot_dish(): grpcurl
на dish_addr — dish і router фізично один пристрій, тож перезавантажуються обидва.
"""
import json
import logging
import shutil
import socket
import subprocess
import threading
import time
import types
from dataclasses import dataclass, asdict, field
from typing import Any, List, Optional

from app import config

logger = logging.getLogger("starlink_client")


def _snake_to_camel(name: str) -> str:
    """grpcurl видає JSON-ключі в camelCase, а grpcurl describe - назви полів
    у snake_case. Конвертація потрібна, щоб мапити ROUTER_ALERT_FIELD_NAMES
    (snake_case, для збереження в БД/показу) на реальні ключі відповіді."""
    parts = name.split("_")
    return parts[0] + "".join(p.title() for p in parts[1:])

# Попередження dish, що відкидаються вже в джерелі: не пишуться в БД/журнал, не показуються на
# дашборді/дисплеї, не рахуються в Telegram /status. Фільтр тут, а не в monitor.py, бо /status і
# check_updates_now() читають стан напряму, повз poll_once() (той самий клас пропуску, що був з
# IGNORED_ROUTER_ALERTS). obstruction_map_reset — Starlink скидає карту перешкод сам; на станції
# оновлень (3-12 тарілок на день) це шум на кожному підключенні (рішення користувача).
IGNORED_DISH_ALERTS = frozenset({"obstruction_map_reset"})
# Те саме для роутера: wired_mesh_not_using_wan_iface — шум для цієї конфігурації мережі. Фільтр тут, а
# не в monitor.py: там він двічі пропускав шляхи (check_updates_now(); Telegram /status показував "⚠️
# Попереджень: 1" при порожньому списку на дашборді); у джерелі єдина точка для УСІХ читань стану
# роутера.
IGNORED_ROUTER_ALERTS = frozenset({"wired_mesh_not_using_wan_iface", "lan_eth_slow_link_100"})
# lan_eth_slow_link_100 (\"повільне LAN Ethernet з'єднання (100 Мбіт/с)\") - рішення користувача: не
# виводити, не надсилати в Telegram і не записувати (БД, журнал, дашборд, дисплей). Лише варіант на
# 100 Мбіт/с: lan_eth_slow_link_10 (10 Мбіт/с) НЕ ігнорується - це справжня деградація лінку.

# Точна відповідність до enum SpaceX.API.Device.SoftwareUpdateState
SOFTWARE_UPDATE_STATE_NAMES = {
    0: "SOFTWARE_UPDATE_STATE_UNKNOWN",
    1: "IDLE",
    2: "FETCHING",
    3: "PRE_CHECK",
    4: "WRITING",
    5: "POST_CHECK",
    6: "REBOOT_REQUIRED",
    7: "DISABLED",
    8: "FAULTED",
}

# Точна відповідність до полів message DishAlerts (номери полів з grpcurl describe)
ALERT_FIELD_NAMES = [
    "motors_stuck",
    "thermal_shutdown",
    "thermal_throttle",
    "unexpected_location",
    "mast_not_near_vertical",
    "slow_ethernet_speeds",
    "roaming",
    "install_pending",
    "is_heating",
    "power_supply_thermal_throttle",
    "is_power_save_idle",
    "dbf_telem_stale",
    "low_motor_current",
    "lower_signal_than_predicted",
    "slow_ethernet_speeds_100",
    "obstruction_map_reset",
    "dish_water_detected",
    "router_water_detected",
    "upsu_router_port_slow",
    "no_ethernet_link",
]

# Точна відповідність до enum SpaceX.API.Device.WifiSoftwareUpdateState (роутер)
ROUTER_UPDATE_STATE_NAMES = {
    0: "NOT_RUN",
    1: "GETTING_TARGET_VERSION",
    2: "DOWNLOADING_UPDATE_IMAGE",
    3: "FLASHING",
    4: "NO_UPDATE_REQUIRED",
    5: "REBOOT_PENDING",
    6: "GETTING_TARGET_VERSION_FAILED",
    7: "GETTING_TARGET_VERSION_EXHAUSTED",
    8: "NO_VALID_ARTIFACT",
    9: "ILLEGAL_ARTIFACT",
    10: "DOWNLOADING_UPDATE_IMAGE_FAILED",
    11: "DOWNLOADING_UPDATE_IMAGE_EXHAUSTED",
    12: "FLASHING_FAILED",
}

# Точна відповідність до полів message WifiAlerts (номери полів з grpcurl describe)
ROUTER_ALERT_FIELD_NAMES = [
    "thermal_throttle",
    "install_pending",
    "freshly_fused",
    "lan_eth_slow_link_10",
    "lan_eth_slow_link_100",
    "wan_eth_poor_connection",
    "mesh_topology_changing_often",
    "mesh_unreliable_backhaul",
    "radius_missing_process",
    "eth_switch_error",
    "poe_on_dish_unreachable",
    "poe_fuse_blown",
    "poe_router_overcurrent",
    "poe_off_current_nominal",
    "poe_vin_overvoltage",
    "poe_vin_undervoltage",
    "high_cable_ping_drop_rate",
    "sandbox_disabled",
    "only_overflight_blocked",
    "offline_networks_disabled",
    "wired_mesh_not_using_wan_iface",
]

# Vendored gRPC-модуль вантажиться ЛЕДАЧЕ — при першому зверненні до тарілки, не при імпорті: gRPC +
# protobuf + yagrc + vendored файл ≈ 21 МБ RSS і ~85 мс (x86; на Pi Zero 2 W більше), а веб-процес
# імпортує цей модуль лише заради двох кнопок (перевірка оновлень, перезавантаження тарілки), тоді як
# дашборд читає тільки БД. Значення: модуль / None (недоступний) / _UNLOADED (ще не завантажували).
# Тести підміняють starlink_grpc напряму (patch.object) — _grpc_module() це поважає.
_UNLOADED: Any = object()
starlink_grpc: Any = _UNLOADED
# Чому модуль недоступний (для повідомлення про локальну несправність)
_GRPC_UNAVAILABLE_REASON = ""
_grpc_load_lock = threading.Lock()


def _grpc_module() -> Optional[types.ModuleType]:
    """Vendored starlink_grpc (завантажується при першому виклику) або None, якщо
    недоступний - локальна несправність, див. DishStatus.local_fault."""
    global starlink_grpc, _GRPC_UNAVAILABLE_REASON
    if starlink_grpc is _UNLOADED:
        with _grpc_load_lock:              # get_status викликають потоки монітора, бота й веб-запитів
            if starlink_grpc is _UNLOADED:
                try:
                    from app.vendor import starlink_grpc as module
                except Exception as exc:
                    # Exception, не лише ImportError: обірваний/пошкоджений файл дає
                    # SyntaxError (раніше монітор не стартував узагалі), а відсутній yagrc -
                    # ModuleNotFoundError. Розрізняти причини не потрібно: усі вони ЛОКАЛЬНІ
                    # (див. DishStatus.local_fault) - тарілка тут ні до чого.
                    _GRPC_UNAVAILABLE_REASON = f"{type(exc).__name__}: {exc}"[:200]
                    logger.error(
                        "starlink_grpc недоступний (%s). Відновіть app/vendor/starlink_grpc.py: "
                        "scripts/install.sh або scripts/fetch_starlink_grpc.sh",
                        _GRPC_UNAVAILABLE_REASON,
                    )
                    starlink_grpc = None
                else:
                    # Таймаут запитів gRPC у vendored-модулі жорстко 10 с: без цього налаштування
                    # STARLINK_DISH_TIMEOUT діяло б лише на grpcurl (роутер, reboot), а не на опитування dish.
                    module.REQUEST_TIMEOUT = config.DISH_HTTP_TIMEOUT  # type: ignore[assignment]   # у vendored int, тут float
                    starlink_grpc = module
    return starlink_grpc  # type: ignore[no-any-return]


def _dish_identity(device_info: Any) -> tuple[str, str, str]:
    """(software_version, hardware_version, id) з message DeviceInfo; None -> порожні рядки."""
    if device_info is None:
        return "", "", ""
    return (
        str(getattr(device_info, "software_version", "") or ""),
        str(getattr(device_info, "hardware_version", "") or ""),
        str(getattr(device_info, "id", "") or ""),
    )


def _state_name(raw_state: Any, names: dict[int, str]) -> str:
    """protobuf enum може прийти як int - мапимо через точну таблицю з grpcurl describe;
    якщо вже рядок - лишаємо як є."""
    if isinstance(raw_state, int):
        return names.get(raw_state, str(raw_state))
    return str(raw_state) if raw_state else ""


def _dish_update_fields(sw_update_stats: Any) -> tuple[str, float, bool]:
    """message SoftwareUpdateStats { software_update_state, software_update_progress,
    update_requires_reboot, ... } -> (стан, прогрес %, потрібен reboot)."""
    if sw_update_stats is None:
        return "", 0.0, False
    progress_raw = getattr(sw_update_stats, "software_update_progress", 0.0) or 0.0
    return (
        _state_name(getattr(sw_update_stats, "software_update_state", None), SOFTWARE_UPDATE_STATE_NAMES),
        round(progress_raw * 100, 1),
        bool(getattr(sw_update_stats, "update_requires_reboot", False)),
    )


def _dish_alerts(alerts_obj: Any) -> tuple[List[str], bool]:
    """message DishAlerts - набір bool-прапорців (не список): назви лише активних (True)."""
    if alerts_obj is None:
        return [], False
    active = [
        name for name in ALERT_FIELD_NAMES
        if name not in IGNORED_DISH_ALERTS and bool(getattr(alerts_obj, name, False))
    ]
    return active, bool(getattr(alerts_obj, "install_pending", False))


def _router_update_fields(sw_stats: dict[str, Any]) -> tuple[str, float]:
    """WifiSoftwareUpdateStats { state, software_download_progress, ... } -> (стан, прогрес %)."""
    if not sw_stats:
        return "", 0.0
    raw_state = sw_stats.get("state")
    if isinstance(raw_state, str) and raw_state.isascii() and raw_state.isdigit():
        raw_state = int(raw_state)
    progress = float(sw_stats.get("softwareDownloadProgress", 0.0) or 0.0)
    return _state_name(raw_state, ROUTER_UPDATE_STATE_NAMES), round(progress * 100, 1)


def _router_alerts(alerts_obj: dict[str, Any]) -> tuple[List[str], bool]:
    """WifiAlerts - набір bool-прапорців (не список)."""
    if not alerts_obj:
        return [], False
    active = [
        name for name in ROUTER_ALERT_FIELD_NAMES
        if name not in IGNORED_ROUTER_ALERTS and bool(alerts_obj.get(_snake_to_camel(name), False))
    ]
    return active, bool(alerts_obj.get("installPending", False))


def _router_clients(wifi_status: dict[str, Any]) -> List[dict[str, Any]]:
    """WifiClient[] - лише поля для відображення, без детальної телеметрії (fqcodelInfo, rxStats/txStats)."""
    return [
        {
            "name": str(c.get("name", "") or c.get("macAddress", "невідомо")),
            "mac": str(c.get("macAddress", "")),
            "ip": str(c.get("ipAddress", "")),
            "iface": str(c.get("iface", "")),
            "signal": c.get("signalStrength"),
            "role": str(c.get("role", "")),
            "connected_s": c.get("associatedTimeS"),
        }
        for c in wifi_status.get("clients", []) or []
    ]


@dataclass
class DishStatus:
    timestamp: float
    online: bool
    state: str = ""
    uptime_s: int = 0
    downlink_mbps: float = 0.0
    uplink_mbps: float = 0.0
    ping_latency_ms: float = 0.0
    ping_drop_ratio: float = 0.0
    obstruction_fraction: float = 0.0
    software_version: str = ""
    hardware_version: str = ""
    dish_id: str = ""
    error: str = ""
    # Стан оновлення ПЗ dish
    update_state: str = ""
    update_progress_pct: float = 0.0
    update_requires_reboot: bool = False
    update_install_pending: bool = False
    # Попередження dish (активні alert-прапорці)
    active_alerts: List[str] = field(default_factory=list)
    # Несправність НАШОЇ сторони (модуль starlink_grpc не завантажився), а не
    # тарілки. Watchdog не має рахувати її збоєм dish і перезавантажувати
    # тарілку: без цієї позначки вона перезавантажувалась щоразу через
    # MIN_REBOOT_INTERVAL (симуляція: 22 рази за 67 хв) - тобто пошкоджений
    # локальний файл відключав би інтернет.
    local_fault: bool = False

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["active_alerts"] = json.dumps(d["active_alerts"], ensure_ascii=False)
        return d


@dataclass
class RouterInfo:
    timestamp: float
    online: bool
    software_version: str = ""
    hardware_version: str = ""
    error: str = ""
    # Стан оновлення ПЗ роутера (окрема схема WifiSoftwareUpdateStats)
    update_state: str = ""
    update_progress_pct: float = 0.0
    # Попередження роутера (активні WifiAlerts-прапорці)
    active_alerts: List[str] = field(default_factory=list)
    update_install_pending: bool = False
    # Список клієнтів, під'єднаних до WiFi роутера (WifiClient[])
    clients: List[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["active_alerts"] = json.dumps(d["active_alerts"], ensure_ascii=False)
        d["clients"] = json.dumps(d["clients"], ensure_ascii=False)
        return d


class StarlinkClient:
    def __init__(
        self,
        dish_addr: Optional[str] = None,
        router_addr: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> None:
        self.dish_addr = dish_addr or config.DISH_ADDR
        self.router_addr = router_addr or config.ROUTER_ADDR
        self.timeout = timeout or config.DISH_HTTP_TIMEOUT

    def get_status(self) -> DishStatus:
        """Опитати dish. Ніколи не кидає виняток назовні — помилка кладеться в поле error."""
        grpc_module = _grpc_module()
        if grpc_module is None:
            return DishStatus(
                timestamp=time.time(), online=False, local_fault=True,
                error=f"starlink_grpc module missing ({_GRPC_UNAVAILABLE_REASON or 'не встановлено'})",
            )

        context = None
        try:
            context = grpc_module.ChannelContext(target=self.dish_addr)
            resp = grpc_module.get_status(context)
            # resp - сирий protobuf DishGetStatusResponse. Поля читаємо напряму
            # (не через dict()/namedtuple - той API нестабільний між версіями).
            device_state = getattr(resp, "device_state", None)
            obstruction_stats = getattr(resp, "obstruction_stats", None)

            downlink_bps = getattr(resp, "downlink_throughput_bps", 0.0) or 0.0
            uplink_bps = getattr(resp, "uplink_throughput_bps", 0.0) or 0.0
            ping_latency = getattr(resp, "pop_ping_latency_ms", 0.0) or 0.0
            # pop_ping_drop_rate не завжди присутнє в цій версії протоколу;
            # якщо немає - лишаємо 0 (не є ознакою недоступності dish)
            ping_drop = getattr(resp, "pop_ping_drop_rate", 0.0) or 0.0

            obstruction_fraction = 0.0
            if obstruction_stats is not None:
                obstruction_fraction = getattr(obstruction_stats, "fraction_obstructed", 0.0) or 0.0

            uptime_s = 0
            if device_state is not None:
                uptime_s = int(getattr(device_state, "uptime_s", 0) or 0)

            software_version, hardware_version, dish_id = _dish_identity(getattr(resp, "device_info", None))

            # "стан" dish як єдиний рядок для дашборду: беремо disablement_code,
            # якщо доступний і не "OKAY" - інакше "OKAY"
            disablement = str(getattr(resp, "disablement_code", "") or "")
            state = disablement if disablement and disablement != "OKAY" else "OKAY"

            update_state, update_progress_pct, update_requires_reboot = _dish_update_fields(
                getattr(resp, "software_update_stats", None)
            )
            active_alerts, update_install_pending = _dish_alerts(getattr(resp, "alerts", None))

            result = DishStatus(
                timestamp=time.time(),
                online=True,
                state=state,
                uptime_s=uptime_s,
                downlink_mbps=round(downlink_bps / 1e6, 2),
                uplink_mbps=round(uplink_bps / 1e6, 2),
                ping_latency_ms=round(ping_latency, 1),
                ping_drop_ratio=round(ping_drop, 4),
                obstruction_fraction=round(obstruction_fraction, 4),
                software_version=software_version,
                hardware_version=hardware_version,
                dish_id=dish_id,
                update_state=update_state,
                update_progress_pct=update_progress_pct,
                update_requires_reboot=update_requires_reboot,
                update_install_pending=update_install_pending,
                active_alerts=active_alerts,
            )
            return result
        except Exception as e:
            logger.warning("Не вдалося отримати статус dish: %s", e)
            return DishStatus(timestamp=time.time(), online=False, error=str(e))
        finally:
            if context is not None and hasattr(context, "close"):
                try:
                    context.close()
                except Exception as e:
                    # Реальна причина невдачі (якщо була) уже залогована
                    # вище через logger.warning() - тут лише debug-слід
                    # для рідкісного edge-case закриття gRPC-каналу,
                    # без підняття рівня й без маскування головної помилки.
                    logger.debug("Не вдалося закрити gRPC-канал: %s", e)

    def router_reachable(self, timeout: float = 2.0) -> bool:
        """Чи відповідає gRPC-порт роутера Starlink на TCP. Розрізняє "Starlink вимкнено/без WiFi Starlink"
        (роутер теж недоступний) і "тарілка зависла" (роутер відповідає, dish ні): у першому випадку
        перезавантажувати тарілку безглуздо — команда піде тим самим недоступним шляхом. Без WiFi
        Starlink пакети до роутера йдуть дефолтним маршрутом через eth0 і зазвичай чекають повний
        timeout (2 с) — лише очікування, і лише коли dish уже не відповідає.
        """
        host, _, port = self.router_addr.rpartition(":")
        try:
            with socket.create_connection((host, int(port)), timeout=timeout):
                return True
        except (OSError, ValueError):
            return False

    def get_router_info(self) -> RouterInfo:
        """
        Опитує ОКРЕМИЙ роутерний компонент Starlink Mini (інша адреса,
        ніж dish - див. докстрінг модуля). Ніколи не кидає виняток назовні.
        """
        grpcurl_bin = shutil.which("grpcurl")
        if not grpcurl_bin:
            return RouterInfo(timestamp=time.time(), online=False, error="grpcurl не знайдено в PATH")

        try:
            result = subprocess.run(
                [
                    grpcurl_bin,
                    "-plaintext",
                    "-d", '{"get_status":{}}',
                    self.router_addr,
                    "SpaceX.API.Device.Device/Handle",
                ],
                capture_output=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout,
            )
            if result.returncode != 0:
                err = (result.stderr or result.stdout or "unknown error").strip()
                return RouterInfo(timestamp=time.time(), online=False, error=err[:500])

            payload = json.loads(result.stdout)
            wifi_status = payload.get("wifiGetStatus", {})
            device_info = wifi_status.get("deviceInfo", {})
            if not device_info:
                return RouterInfo(timestamp=time.time(), online=False, error="empty deviceInfo in response")

            update_state, update_progress_pct = _router_update_fields(wifi_status.get("softwareUpdateStats", {}))
            active_alerts, update_install_pending = _router_alerts(wifi_status.get("alerts", {}))
            clients = _router_clients(wifi_status)

            return RouterInfo(
                timestamp=time.time(),
                online=True,
                software_version=str(device_info.get("softwareVersion", "")),
                hardware_version=str(device_info.get("hardwareVersion", "")),
                update_state=update_state,
                update_progress_pct=update_progress_pct,
                active_alerts=active_alerts,
                update_install_pending=update_install_pending,
                clients=clients,
            )
        except subprocess.TimeoutExpired:
            return RouterInfo(timestamp=time.time(), online=False, error="timeout")
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning("Не вдалося розпарсити відповідь роутера: %s", e)
            return RouterInfo(timestamp=time.time(), online=False, error=f"parse error: {e}")
        except Exception as e:
            logger.warning("Не вдалося отримати статус роутера: %s", e)
            return RouterInfo(timestamp=time.time(), online=False, error=str(e))

    def reboot_dish(self) -> tuple[bool, str]:
        """
        Виконує reboot dish через SpaceX.API.Device.Device/Handle з payload {"reboot": {}}.
        Використовує grpcurl як subprocess - надійніше за нестабільний внутрішній
        API starlink_grpc, і не потребує окремо згенерованих protobuf-модулів.
        Повертає (успіх, повідомлення).
        """
        grpcurl_bin = shutil.which("grpcurl")
        if not grpcurl_bin:
            return False, "grpcurl не знайдено в PATH (встановіть його через install.sh)"

        try:
            result = subprocess.run(
                [
                    grpcurl_bin,
                    "-plaintext",
                    "-d", '{"reboot":{}}',
                    self.dish_addr,
                    "SpaceX.API.Device.Device/Handle",
                ],
                capture_output=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout + 5,
            )
            if result.returncode != 0:
                err = (result.stderr or result.stdout or "unknown error").strip()
                logger.error("Помилка reboot dish (grpcurl exit %d): %s", result.returncode, err)
                return False, err[:500]

            logger.info("Reboot dish виконано успішно (%s)", self.dish_addr)
            return True, "reboot command sent"
        except subprocess.TimeoutExpired:
            logger.error("Таймаут виконання reboot dish через grpcurl")
            return False, "timeout"
        except Exception as e:
            logger.error("Помилка reboot dish: %s", e)
            return False, str(e)
