"""
Вхідні команди Telegram-бота: long polling (без webhook), працює в
потоці starlink-monitor.service. Авторизація за chat_id зі списку
отримувачів сповіщень (app/telegram_notify).

Команди: /status, /checkupdates, /reboot (з підтвердженням),
/id [dish_id], /help.
"""
import html
import logging
import math
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Optional

import requests

from app import config, db, i18n, services, telegram_notify
from app import labels
from app.log_redact import redact
from app.starlink_client import StarlinkClient

logger = logging.getLogger("telegram_bot")

# Паузи циклу опитування бота, с
_DISABLED_RECHECK_SEC = 10     # бот вимкнений/не налаштований - як часто перевіряти налаштування
_LOOP_ERROR_PAUSE_SEC = 5      # після неочікуваної помилки в циклі
_POLL_ERROR_PAUSE_SEC = 3      # після невдалого getUpdates (мережа, відмова API)

API_BASE = "https://api.telegram.org/bot{token}/{method}"

# Скільки секунд діє запит підтвердження /reboot, перш ніж вважати його
# застарілим (захист від випадкового підтвердження старого запиту)
def _api_call(
    method: str, token: str, http_timeout: float, *, session: Optional[requests.Session] = None, **params: Any,
) -> Optional[dict[str, Any]]:
    """Викликає Telegram Bot API; повертає розпарсений JSON або None при мережевій помилці. Telegram
    повертає ВАЛІДНИЙ JSON і для відхилених запитів (`{"ok": false, "description": "message is too
    long"}` — понад 4096 символів чи невалідний HTML), тому `ok` перевіряється явно: інакше помилка
    мовчки ігнорується й виглядає як "команда не відповідає" (так /id без аргументів перевищував ліміт
    при багатьох тарілках).
    """
    try:
        resp = telegram_notify._request_with_eth0_fallback(
            "post",
            API_BASE.format(token=token, method=method),
            json=params,
            timeout=http_timeout,
            session=session,
        )
        data: dict[str, Any] = resp.json()
        if not data.get("ok"):
            logger.warning(
                "Telegram API %s відхилив запит: %s (chat_id=%s)",
                method, data.get("description", "невідома причина"), params.get("chat_id", "?"),
            )
        return data
    except requests.RequestException as e:
        logger.warning("Telegram API виклик %s провалився: %s", method, redact(str(e), token))
        return None


def _shown_router_state(state: str) -> str:
    """Тимчасові хмарні помилки показуються як "немає оновлень" - так
    само, як на дашборді й TFT-дисплеї (спільний список у labels.py)."""
    return "NOT_RUN" if state in labels.ROUTER_STATES_SHOWN_AS_NO_UPDATES else state


def _router_state_label(state: str) -> str:
    return labels.router_update_state_label(_shown_router_state(state))


def _progress_suffix(pct: Any) -> str:
    """" (42%)" - відсоток оновлення; нічого, якщо його немає, він нульовий чи не скінченний
    (раніше друкувалось "(nan%)", "(inf%)", "(-5%)", "(150%)"). Поза 0..100 обрізається - так
    само, як прогрес-бар на дисплеї."""
    if not isinstance(pct, (int, float)) or isinstance(pct, bool) or not math.isfinite(pct):
        return ""
    clamped = max(0.0, min(100.0, float(pct)))
    return f" ({clamped:.0f}%)" if clamped else ""


def _update_lines(
    status: Any, *, online_key: str, offline_key: str, state_label: Callable[[str], str], with_alerts: bool,
) -> list[str]:
    """Рядки про dish або роутер для /status і /checkupdates. Раніше цей блок був
    скопійований чотири рази (два компоненти x дві команди, 77% подібності);
    різниці між командами - лише ключ рядка "онлайн" і кількість попереджень."""
    if not status.online:
        return [i18n.t(offline_key, error=labels.short_error(status.error) or i18n.t("no_response"))]
    label = state_label(status.update_state) if status.update_state else i18n.t("not_available_short")
    lines = [
        i18n.t(online_key, sw=status.software_version or "?"),
        i18n.t("tg_update_line", label=label) + _progress_suffix(status.update_progress_pct),
    ]
    if with_alerts and status.active_alerts:
        lines.append(i18n.t("tg_alerts_count_line", n=len(status.active_alerts)))
    return lines


def _obj(value: Any) -> dict[str, Any]:
    """Словник або {}: `.get("chat", {})` не рятує, коли ключ є зі
    значенням None - тоді наступний .get() падав AttributeError."""
    return value if isinstance(value, dict) else {}


class TelegramBot:
    def __init__(self) -> None:
        self.client = StarlinkClient()
        self._last_update_id = 0
        self._stop_event = threading.Event()
        # Постійне HTTP-з'єднання ЛИШЕ для getUpdates у потоці _run_loop:
        # ~3500 довгих запитів на добу (таймаут 25 с) раніше щоразу робили
        # нове TLS-рукостискання. Відповіді на команди йдуть з пулу
        # потоків - без сесії (requests.Session не гарантує потокобезпеки).
        self._poll_session: Optional[requests.Session] = None
        self._thread: Optional[threading.Thread] = None
        # Очікуючі підтвердження /reboot: chat_id -> час запиту (для TTL)
        self._pending_reboot_confirm: dict[str, float] = {}
        # Обробка кожного update (зокрема /status, що робить блокуючі
        # gRPC-виклики до dish/router з таймаутом до ~15с) виконується
        # в окремому потоці з цього пулу - інакше повільна/недоступна
        # мережа Starlink затримує весь polling-цикл getUpdates, і нові
        # команди чекають, поки не завершиться поточна.
        self._executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="tg-cmd")

    def start(self) -> None:
        """Запускає polling у фоновому демон-потоці. Викликається один раз
        з monitor.run_forever()."""
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._run_loop, daemon=True, name="telegram-bot")
        self._thread.start()
        logger.info("Telegram-бот: потік опитування команд запущено")

    def stop(self) -> None:
        self._stop_event.set()
        self._executor.shutdown(wait=False)
        self._reset_poll_session()

    def _reset_poll_session(self) -> None:
        session, self._poll_session = self._poll_session, None
        if session is not None:
            try:
                session.close()
            except Exception:
                pass

    def _run_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                token, allowed_chat_ids, enabled = telegram_notify.get_telegram_config()
                if not enabled or not token:
                    # Бот вимкнений/не налаштований - не опитуємо API даремно,
                    # перевіряємо періодично, чи налаштування з'явились.
                    time.sleep(_DISABLED_RECHECK_SEC)
                    continue
                self._poll_once(token, set(allowed_chat_ids))
            except Exception:
                logger.exception("Неочікувана помилка в циклі Telegram-бота")
                time.sleep(_LOOP_ERROR_PAUSE_SEC)

    def _poll_once(self, token: str, allowed_chat_ids: set[str]) -> None:
        if self._poll_session is None:
            self._poll_session = requests.Session()
        data = _api_call(
            "getUpdates",
            token,
            (config.TELEGRAM_POLL_TIMEOUT_SEC + 5),
            session=self._poll_session,
            offset=self._last_update_id + 1,
            timeout=config.TELEGRAM_POLL_TIMEOUT_SEC,
        )
        if data is None:
            # мережева помилка - нове з'єднання наступного разу (напр. після
            # перемикання WAN-failover старе могло лишитись на мертвому маршруті)
            self._reset_poll_session()
        if not data or not data.get("ok"):
            time.sleep(_POLL_ERROR_PAUSE_SEC)
            return

        # Лише об'єкти: елемент result, що не є словником (чи result не список), раніше кидав виняток ДО просування
        # _last_update_id - той самий "отруєний" update перечитувався б нескінченно.
        result = data.get("result")
        updates = [u for u in result if isinstance(u, dict)] if isinstance(result, list) else []
        for update in updates:
            update_id = update.get("update_id", 0)
            if isinstance(update_id, int) and not isinstance(update_id, bool):
                self._last_update_id = max(self._last_update_id, update_id)

        # Групуємо за chat_id: updates одного чату обробляються послідовно в одному потоці (порядок,
        # напр., /reboot і клік підтвердження того самого користувача: без цього клік міг обробитись
        # РАНІШЕ за встановлення pending-стану). Різні чати — паралельно: повільна команда одного не
        # блокує інших.
        groups: dict[str, list[dict[str, Any]]] = {}
        for update in updates:
            chat_id = self._extract_chat_id(update)
            groups.setdefault(chat_id, []).append(update)

        for updates in groups.values():
            self._executor.submit(self._handle_updates_sequential, token, allowed_chat_ids, updates)

    @staticmethod
    def _extract_chat_id(update: dict[str, Any]) -> str:
        if "callback_query" in update:
            return str(_obj(_obj(_obj(update["callback_query"]).get("message")).get("chat")).get("id", ""))
        message = _obj(update.get("message") or update.get("edited_message"))
        return str(_obj(message.get("chat")).get("id", ""))

    def _handle_updates_sequential(self, token: str, allowed_chat_ids: set[str], updates: list[dict[str, Any]]) -> None:
        for update in updates:
            try:
                self._handle_update(token, allowed_chat_ids, update)
            except Exception:
                logger.exception("Помилка обробки Telegram update: %s", update)

    def _handle_update(self, token: str, allowed_chat_ids: set[str], update: dict[str, Any]) -> None:
        if "callback_query" in update:
            self._handle_callback(token, allowed_chat_ids, _obj(update["callback_query"]))
            return

        message = _obj(update.get("message") or update.get("edited_message"))
        if not message:
            return

        chat_id = str(_obj(message.get("chat")).get("id", ""))
        text = message.get("text")
        if not isinstance(text, str) or not text.strip():
            return
        text = text.strip()

        if chat_id not in allowed_chat_ids:
            logger.info("Ігноровано команду від неавторизованого chat_id=%s", chat_id)
            self._send(token, chat_id, i18n.t("tg_unauthorized_chat"))
            return

        command = text.split()[0].lower().split("@")[0]  # прибрати /cmd@botname
        if command == "/status":
            self._cmd_status(token, chat_id)
        elif command == "/checkupdates":
            self._cmd_check_updates(token, chat_id)
        elif command == "/reboot":
            self._cmd_reboot_request(token, chat_id)
        elif command == "/id":
            # Аргумент - усе після ПЕРШОГО слова, а не після len(command):
            # command уже без суфікса @botname, тож для "/id@Bot X" зріз за
            # довжиною давав аргумент "@Bot X" (групові чати).
            parts = text.split(maxsplit=1)
            arg = parts[1].strip() if len(parts) > 1 else ""
            self._cmd_id(token, chat_id, arg)
        elif command in ("/help", "/start"):
            self._cmd_help(token, chat_id)
        else:
            self._send(token, chat_id, i18n.t("tg_unknown_command"))

    def _handle_callback(self, token: str, allowed_chat_ids: set[str], callback: dict[str, Any]) -> None:
        chat_id = str(_obj(_obj(callback.get("message")).get("chat")).get("id", ""))
        data = callback.get("data", "")
        callback_id = callback.get("id")

        if chat_id not in allowed_chat_ids:
            _api_call("answerCallbackQuery", token, config.TELEGRAM_SEND_TIMEOUT_SEC, callback_query_id=callback_id,
                      text=i18n.t("tg_not_authorized"))
            return

        if data == "reboot_confirm":
            requested_at = self._pending_reboot_confirm.pop(chat_id, None)
            _api_call("answerCallbackQuery", token, config.TELEGRAM_SEND_TIMEOUT_SEC, callback_query_id=callback_id)
            if requested_at is None or (time.time() - requested_at) > config.TELEGRAM_CONFIRM_TTL_SEC:
                self._send(token, chat_id, i18n.t("tg_reboot_expired"))
                return
            self._send(token, chat_id, i18n.t("tg_executing_reboot"))
            ok, msg = self.client.reboot_dish()
            db.insert_event("dish_reboot", f"Ручний reboot через Telegram: {msg}", success=ok)
            if ok:
                self._send(token, chat_id, i18n.t("tg_reboot_success"))
            else:
                self._send(token, chat_id, i18n.t("tg_reboot_failed", msg=msg))
        elif data == "reboot_cancel":
            self._pending_reboot_confirm.pop(chat_id, None)
            _api_call("answerCallbackQuery", token, config.TELEGRAM_SEND_TIMEOUT_SEC, callback_query_id=callback_id)
            self._send(token, chat_id, i18n.t("tg_cancelled"))

    def _cmd_status(self, token: str, chat_id: str) -> None:
        dish = self.client.get_status()
        router = self.client.get_router_info()
        lines = [i18n.t("tg_status_title"), ""]
        lines += _update_lines(dish, online_key="tg_dish_online_line", offline_key="tg_dish_offline_line",
                               state_label=labels.update_state_label, with_alerts=True)
        lines.append("")
        lines += _update_lines(router, online_key="tg_router_online_line", offline_key="tg_router_offline_line",
                               state_label=_router_state_label, with_alerts=True)
        self._send(token, chat_id, "\n".join(lines))

    def _cmd_check_updates(self, token: str, chat_id: str) -> None:
        """Ручна перевірка стану оновлень - той самий monitor.check_
        updates_now(), що веб-кнопка "Перевірити оновлення" (webapp.py
        /api/check-updates) - не дублює логіку, лише інше форматування
        відповіді (HTML-текст у Telegram замість JSON)."""
        def notify(text: str) -> None:
            telegram_notify.send_message(text)

        dish, router = services.check_updates_now(self.client, notify)
        lines = [i18n.t("tg_check_updates_title"), ""]
        lines += _update_lines(dish, online_key="tg_dish_line_short", offline_key="tg_dish_offline_line",
                               state_label=labels.update_state_label, with_alerts=False)
        lines.append("")
        lines += _update_lines(router, online_key="tg_router_line_short", offline_key="tg_router_offline_line",
                               state_label=_router_state_label, with_alerts=False)
        self._send(token, chat_id, "\n".join(lines))

    def _cmd_reboot_request(self, token: str, chat_id: str) -> None:
        # Прибираємо застарілі (TTL минув) pending-записи з УСІХ chat_id: їх видаляє лише
        # _handle_callback() при натисканні кнопки, тож якщо користувач ігнорує повідомлення, запис
        # лишався б у пам'яті процесу назавжди (повільний витік у watchdog без рестарту місяцями).
        now = time.time()
        expired = [cid for cid, ts in self._pending_reboot_confirm.items()
                   if now - ts > config.TELEGRAM_CONFIRM_TTL_SEC]
        for cid in expired:
            del self._pending_reboot_confirm[cid]

        self._pending_reboot_confirm[chat_id] = time.time()
        text = i18n.t("tg_reboot_confirm_prompt")
        _api_call(
            "sendMessage",
            token,
            config.TELEGRAM_SEND_TIMEOUT_SEC,
            chat_id=chat_id,
            text=text,
            reply_markup={
                "inline_keyboard": [[
                    {"text": i18n.t("tg_yes_reboot"), "callback_data": "reboot_confirm"},
                    {"text": i18n.t("tg_cancel_btn"), "callback_data": "reboot_cancel"},
                ]]
            },
        )

    def _cmd_help(self, token: str, chat_id: str) -> None:
        self._send(token, chat_id, i18n.t("tg_help_text"))

    def _cmd_id(self, token: str, chat_id: str, arg: str) -> None:
        if not arg:
            self._reply_id_list(token, chat_id)
        else:
            self._reply_id_detail(token, chat_id, arg)

    def _reply_id_list(self, token: str, chat_id: str) -> None:
        """Список УСІХ відомих тарілок - викликається при /id без аргументу."""
        devices = db.get_all_known_devices()
        if not devices:
            self._send(token, chat_id, i18n.t("tg_no_dishes_yet"))
            return
        # Telegram обмежує повідомлення 4096 символами - без цього
        # захисту довгий список (десятки відомих тарілок за час
        # роботи) міг би бути ВІДХИЛЕНИЙ Telegram API цілком, і
        # відповідь мовчки не приходила б (реальний баг, знайдений
        # на запиті користувача - виправлено разом із явною
        # перевіркою "ok"-поля в _api_call() вище). get_all_known_
        # devices() уже сортує за last_seen_ts DESC - найновіші
        # (найактуальніші) показуються першими.
        shown = devices[:config.TELEGRAM_ID_LIST_MAX_ITEMS]
        lines = [i18n.t("tg_known_dishes_title", n=len(devices)), ""]
        for d in shown:
            last_seen = self._fmt_ago(d["last_seen_ts"])
            lines.append(i18n.t("tg_last_seen_line", id=d['dish_id'], ago=last_seen))
        if len(devices) > len(shown):
            lines.append("")
            lines.append(i18n.t("tg_and_more_hint", n=len(devices) - len(shown)))
        lines.append("")
        lines.append(i18n.t("tg_details_hint"))
        self._send(token, chat_id, "\n".join(lines))

    def _reply_id_detail(self, token: str, chat_id: str, arg: str) -> None:
        """Деталі КОНКРЕТНОЇ тарілки за точним ID чи частковим збігом -
        викликається при /id <arg>."""
        device = db.get_known_device(arg)
        if device is None:
            # Пошук за частковим збігом - зручно, щоб не вводити довгий ID повністю
            matches = [d for d in db.get_all_known_devices() if arg.lower() in d["dish_id"].lower()]
            if len(matches) == 1:
                device = matches[0]
            elif len(matches) > 1:
                # SafeHtml: розмітку <code> будуємо самі (ідентифікатор екранований),
                # i18n не має екранувати її вдруге
                ids = i18n.SafeHtml("\n".join(f"<code>{html.escape(d['dish_id'], quote=False)}</code>" for d in matches))
                self._send(token, chat_id, i18n.t("tg_multiple_matches", ids=ids))
                return

        if device is None:
            self._send(token, chat_id, i18n.t("tg_dish_not_found", arg=arg))
            return

        na = i18n.t("not_available_short")
        lines = [i18n.t("tg_dish_title", id=device['dish_id']), ""]

        lines.append(i18n.t("tg_dish_hw_line", hw=device['dish_hardware_version'] or na))
        lines.append(i18n.t("tg_sw_line", sw=device['dish_software_version'] or na))
        if device["dish_software_updated_ts"]:
            lines.append(i18n.t("tg_last_fw_update_line", ago=self._fmt_ago(device['dish_software_updated_ts'])))

        lines.append("")
        lines.append(i18n.t("tg_router_hw_line", hw=device['router_hardware_version'] or na))
        lines.append(i18n.t("tg_sw_line", sw=device['router_software_version'] or na))
        if device["router_software_updated_ts"]:
            lines.append(i18n.t("tg_last_fw_update_line", ago=self._fmt_ago(device['router_software_updated_ts'])))

        lines.append("")
        lines.append(i18n.t("tg_first_seen_line", ago=self._fmt_ago(device['first_seen_ts'])))
        lines.append(i18n.t("tg_last_seen_full_line", ago=self._fmt_ago(device['last_seen_ts'])))

        self._send(token, chat_id, "\n".join(lines))

    @staticmethod
    def _fmt_ago(ts: float) -> str:
        if not ts:
            return i18n.t("ago_unknown")
        delta = time.time() - ts
        if delta < 60:
            return i18n.t("ago_just_now")
        if delta < 3600:
            return f"{int(delta // 60)} {i18n.t('ago_min')}"
        if delta < 86400:
            return f"{int(delta // 3600)} {i18n.t('ago_hour')}"
        days = int(delta // 86400)
        return f"{days} {i18n.t('ago_day')}"

    def _send(self, token: str, chat_id: str, text: str) -> None:
        _api_call("sendMessage", token, config.TELEGRAM_SEND_TIMEOUT_SEC, chat_id=chat_id, text=text, parse_mode="HTML")
