# Індекс проєкту

Навігатор по файлах Starlink Monitor. Детальний технічний опис —
[`architecture.md`](architecture.md); історія рішень і виправлених
багів — [`decisions-log.md`](decisions-log.md); загальний
опис/встановлення — [`../README.md`](../README.md).

## Корінь

| Файл | Опис |
|---|---|
| `README.md` | Опис проєкту, встановлення, конфігурація, усі env-параметри |
| `README.en.md` | Той самий README англійською - синхронізувати вручну при зміні README.md |
| `requirements.txt` | Python-залежності (pip), встановлюються на Pi |
| `requirements-dev.txt` | Залежності розробки (mypy) - НЕ встановлюються на Pi |
| `mypy.ini` | Конфігурація статичної типізації (виключає `app/vendor/`) |
| `pytest.ini` | Мінімальна конфігурація pytest (`testpaths = tests`) |
| `.gitignore` | `__pycache__/`, `.mypy_cache/`, `.pytest_cache/`, `*.db` — не мають потрапляти в архів |
| `LICENSE` | Ліцензія |

## `app/` — Python-модулі

| Файл | Опис |
|---|---|
| `starlink_client.py` | gRPC-клієнт: статус dish/router, `reboot_dish()` |
| `monitor.py` | Watchdog: цикл опитування, авто-reboot, логування подій, запуск Telegram-бота |
| `webapp.py` | Flask, REST API, роздає `/`, `/settings`, `/stats`, `/healthz` |
| `db.py` | SQLite: metrics, events, system_metrics, router_status, known_devices, settings |
| `i18n.py` | Мультимовний інтерфейс (uk/en) - словник перекладів, `t()`, мова з settings |
| `telegram_notify.py` | Вихідні сповіщення |
| `telegram_bot.py` | Вхідні команди `/status`, `/checkupdates`, `/reboot`, `/id`, `/help` |
| `labels.py` | Спільні label-мапи (monitor.py + telegram_bot.py) |
| `system_metrics.py` | Метрики Pi (CPU/RAM/диск/температура) |
| `shutdown_button.py` | Фізична кнопка виключення через GPIO (окремий процес) |
| `pi_power.py` | Спільний reboot/poweroff, DB-сигнал для дисплея |
| `activity_led.py` | Опційний LED активності SD-картки, частина monitor.py (не окремий процес) |
| `display.py` | Фізичний TFT-дисплей статусу (ST7789, SPI, окремий процес) |
| `gpio_utils.py` | Спільна gpiod v1/v2-логіка читання GPIO (shutdown_button.py + display.py) і запису GPIO (activity_led.py) |
| `config.py` | Конфігурація, env-змінні |
| `config_editor.py` | Читання/валідація/запис `/etc/starlink-monitor/env` через `/settings` |
| `vendor/starlink_grpc.py` | Vendored (не наш код) — gRPC-хелпери з sparky8512/starlink-grpc-tools, окрема ліцензія |

## `static/` — фронтенд

| Файл | Опис |
|---|---|
| `common.js` | Спільні для dashboard.js/stats.js: `fmtTime`, `fmtAgo`, `fmtDateHeader` |
| `theme.js` | Темна/світла тема - toggle на /settings, підключено на всіх 3 сторінках |
| `dashboard.js` | Логіка головної сторінки (`/`) |
| `settings.js` | Логіка сторінки налаштувань (`/settings`) |
| `stats.js` | Логіка сторінки статистики (`/stats`) |
| `pwa.js`, `sw.js`, `manifest.json` | PWA (встановлення як застосунок, offline-кеш) |
| `style.css` | Стилі усіх сторінок |
| `favicon.ico`, `icon-192.png`, `icon-512.png`, `logo.png` | Іконки |

## `templates/` — HTML

| Файл | Опис |
|---|---|
| `index.html` | Головний дашборд |
| `settings.html` | Сторінка налаштувань |
| `stats.html` | Сторінка статистики (журнал подій) |

## `systemd/` — unit-файли

| Файл | Опис |
|---|---|
| `starlink-monitor.service` | Watchdog + Telegram-бот |
| `starlink-webui.service` | Flask dashboard |
| `starlink-shutdown-button.service` | Слухає GPIO-кнопку виключення |
| `starlink-display.service` | Фізичний TFT-дисплей |
| `starlink-grpc-fetch.service` | Опційне ручне оновлення vendored `starlink_grpc.py` (не автоматичне) |
| `starlink-wan-failover.service`/`.timer` | Періодична перевірка інтернету через wlan0 |
| `starlink-monitor-healthcheck.service`/`.timer` | Раз/хв опитує `/healthz`, force-restart при зависанні |

## `scripts/` — bash

| Файл | Опис |
|---|---|
| `install.sh` | Повне встановлення (системні пакети, venv, sudo-права, systemd) |
| `update.sh` | Оновлення вже встановленого проєкту |
| `uninstall.sh` | Повне видалення |
| `fetch_starlink_grpc.sh` | Опційне оновлення vendored `starlink_grpc.py` до найновішої upstream-версії |
| `wan_failover_check.sh` | Перевірка інтернету через wlan0, коригування route-metric |
| `watchdog_healthcheck.sh` | Перевірка `/healthz`, force-restart при не-200 |

## `tests/` — pytest

| Файл | Опис |
|---|---|
| `conftest.py` | Спільні fixtures: `db_path` (ізольована тимчасова БД), `watchdog` (з mock-ованим `_notify`) |
| `test_monitor.py` | Reboot-спам, дедублікація target-версій, update-state/alerts (dish+router), auto-reboot логіка |
| `test_monitor_run_forever.py` | Головний watchdog-цикл: periodичні prune/vacuum/integrity/backup, startup-сповіщення |
| `test_webapp.py` | Компаратор версій прошивки, `/api/target-versions`; основні status-endpoints, `/healthz` except-гілки, `/api/telegram-test` |
| `test_i18n.py` | Цілісність перекладів (паритет плейсхолдерів uk/en, наявність кожного ключа з коду), `get_language()` при зламаній БД, англійські Telegram-сповіщення реальними шляхами коду |
| `test_system_metrics.py` | Кожна метрика (uptime/cpu/memory/disk/temp) незалежно, ніколи не кидає виняток навіть при повному провалі psutil |
| `test_pi_power.py` | DB-сигнал записаний ДО затримки, очищений ДО systemctl-команди (успіх і провал однаково); lazy notify_fn default, edge cases (subprocess-виняток, DB-провал не блокує реальну дію) |
| `test_telegram_notify.py` | HTTP-запити, retry; eth0-fallback (усі 3 рівні: звичайний/eth0/manual DNS через eth0); send_document (backup-файл) |
| `test_telegram_bot.py` | /checkupdates диспетчеризація; _poll_once/групування за chat_id; _run_loop/start/stop (SystemExit-трюк) |
| `test_db.py` | Prune старих метрик, `check_integrity()`, callback-хук LED активності |
| `test_display.py` | update_state/auto-off/power-message + _redraw, _load_font, _truncate_to_width, _set_backlight |
| `test_activity_led.py` | Неблокуюче blink/close, послідовні виклики без блимання, callback-помилки не поширюються |
| `test_gpio_utils.py` | find_gpio_chip, ButtonPressTracker (short/long_press), open_input/output_line через fake gpiod v1/v2 |
| `test_shutdown_button.py` | Фізична кнопка вимкнення: пін 0/відсутній gpiod/збій GPIO — вихід без падіння; довге/коротке натискання; поступається дисплею при `DISPLAY_ENABLED`; зламана БД не блокує вимкнення |
| `test_display_run_forever.py` | Повна ініціалізація дисплея через fake CircuitPython-модулі, stop_event, pending-shutdown, кнопка, auto-off |
| `test_config_editor.py` | Запис env-файлу: валідація типів, атомарність, збереження коментарів, звірка з config.py |
| `test_starlink_client.py` | Парсинг gRPC-відповіді dish (enum-мапінг, getattr-fallback'и, конвертація одиниць) і router (subprocess+JSON шлях, snake→camelCase, clients) |

## `docs/` — документація

| Файл | Опис |
|---|---|
| `architecture.md` | Детальний технічний опис усіх компонентів |
| `decisions-log.md` | Історичний журнал рішень і виправлених багів |
| `plan.md` | Початковий план проєкту |
| `index.md` | Цей файл |
