# Журнал рішень

Хронологічний запис значущих технічних рішень і знайдених багів.

## Виявлення реальної схеми gRPC (не за здогадками)

На старті проекту помилково припускалось, що Starlink Mini — єдиний
пристрій. Живі виклики `grpcurl describe` на dish (`192.168.100.1:9200`)
і router (`192.168.1.1:9000`) підтвердили: це два окремі логічні
пристрої з різними `DeviceInfo`, різними enum станів оновлення
(`SoftwareUpdateState` vs `WifiSoftwareUpdateState`), різними наборами
alert-полів (`DishAlerts` 19 полів vs `WifiAlerts` 21 поле). Уся
подальша логіка (`starlink_client.py`, `labels.py`) побудована на
цих підтверджених схемах, не на припущеннях.

**Практика, що склалась**: для будь-яких технічних даних (розміри
плат, protobuf-схеми, назви enum) — підтверджувати через `grpcurl
describe`/web_search/фото, не вигадувати правдоподібні числа.

## Баг: конфлікт параметра `timeout` в Telegram API

**Симптом**: `TypeError: got multiple values for argument 'timeout'`,
бот не отримував жодних вхідних команд, помилка тихо гасилась у
`except Exception` кожні 5с.

**Причина**: `_api_call(method, token, timeout, **params)` мав
формальний параметр `timeout`, а виклик `getUpdates` одночасно
передавав HTTP-таймаут позиційно і Telegram API параметр
`timeout=POLL_TIMEOUT_SEC` (long polling) як іменований — колізія.

**Виправлення**: перейменовано внутрішній параметр на `http_timeout`.

## NoNewPrivileges вимкнено на webui та shutdown-button сервісах

`starlink-webui.service` і `starlink-shutdown-button.service`
навмисно **без** `NoNewPrivileges=true` — обидва викликають
`sudo systemctl reboot/poweroff` (ручний reboot/shutdown Pi через
веб-інтерфейс і через фізичну кнопку). `NoNewPrivileges` на рівні
ядра блокує будь-який `sudo` незалежно від `/etc/sudoers`, тож із
цим прапорцем ці виклики не спрацювали б.

`starlink-monitor.service` лишається з `NoNewPrivileges=true` —
той процес sudo не викликає.

## Баг: signature_phrases.txt read-only при веб-редагуванні

**Симптом**: `[Errno 30] Read-only file system` при спробі зберегти
фрази через веб-інтерфейс.

**Причина**: `ProtectSystem=strict` робить всю ФС read-only, крім
`ReadWritePaths`, куди спочатку входив лише `/var/lib/starlink-monitor`,
не `/opt/starlink-monitor/app/signature_phrases.txt`.

**Виправлення**: додано конкретний файл (не весь `/opt/starlink-monitor`)
у `ReadWritePaths` — мінімальне розширення дозволів.

## Фізична кнопка виключення: окремий процес, не інтеграція в існуючі

**Рішення**: `app/shutdown_button.py` — окремий Python-модуль і
окремий systemd-сервіс, не частина `monitor.py`/`webapp.py`.

**Чому окремо**:
- GPIO-доступ вимагає групу `gpio` і системний `python3-libgpiod`
  (apt, не pip — чистіше на Raspberry Pi OS) — зайва залежність для
  установок без фізичної кнопки
- Вимкнено за замовчуванням (`SHUTDOWN_BUTTON_GPIO_PIN=0`), сервіс
  одразу виходить — не критична помилка, якщо кнопки немає
- `Restart=on-failure` (не `always`) свідомо: чистий вихід при
  вимкненій кнопці не має спричиняти нескінченний рестарт-цикл systemd

**Побічний ефект**: venv тепер створюється з `--system-site-packages`
(щоб бачити системний `gpiod`) — це змінює поведінку venv для *всіх*
пакетів, не лише gpiod (венв тепер бачить будь-який системний Python-
пакет). Прийнятний компроміс, бо альтернатива (pip-встановлення
gpiod з компіляцією C-розширення) менш надійна на слабкому Pi Zero 2 W.

**Третя зміна NoNewPrivileges**: аналогічно до `starlink-webui.service`
(див. розділ вище), `starlink-shutdown-button.service` теж без
`NoNewPrivileges` — потребує sudo для `poweroff`.

## Баг: reboot-loop при невдалій auto-reboot команді

`last_reboot_ts` оновлювався лише при `reboot_dish() == True`. Якщо
dish ще перезавантажується з попередньої спроби (`connection
refused`), команда reboot теж провалюється — `MIN_REBOOT_INTERVAL_SEC`
ніколи не спрацьовував, watchdog повторював спробу reboot щоцикл
опитування (кожні ~10с) замість одного разу на 15 хв. Виправлено:
`last_reboot_ts` оновлюється при кожній *спробі*, незалежно від
результату.

## Налаштування статичних IP (eth0/wlan0) в install.sh — інтерактивне, не автоматичне

Мережева конфігурація (USB-Ethernet + WiFi Starlink) ризикована для
автоматичного застосування без підтвердження — неправильні дефолти
(наприклад, конфлікт підмереж з реальною домашньою мережею) можуть
обірвати SSH-з'єднання, яким адмінить сам Pi. `install.sh` тому
питає підтвердження (`[т/N]`) і дозволяє ввести власні IP/gateway
замість дефолтних, а не застосовує зміни мовчки. `dhcpcd` вимикається
лише в межах цього опційного кроку (не для всіх встановлень) — він
конфліктує з NetworkManager, перевидаючи власні DHCP-лізинги
незалежно від `ipv4.method=manual` у профілі nmcli.

## Баг: gpiod v2 несумісний зі старим API кнопки виключення

**Симптом**: `'Chip' object has no attribute 'get_line'`, сервіс
`starlink-shutdown-button` одразу завершувався з помилкою.

**Причина**: `python3-libgpiod` на Raspberry Pi OS Bookworm+ ставить
gpiod **2.x**, де Python API повністю переписано (`chip.get_line()` +
`line.request()` з v1.x видалені; замість них — `gpiod.request_lines()`
з `LineSettings`, значення через `Value.ACTIVE`/`Value.INACTIVE`
замість `0`/`1`). Код спирався лише на v1 API.

**Виправлення**: `_init_line_v1`/`_init_line_v2` — обидві реалізації,
вибір через `hasattr(gpiod.Chip, "get_line")` (є лише в v1). Значення
з v2 конвертується в 0/1 всередині обгортки `get_value()`, решта
логіки (`watch_button()`) не залежить від версії API.

## Мережевий запит install.sh — лише при першому встановленні, не при оновленні

Питання про статичні IP (eth0/wlan0) обгорнуто умовою `MODE == "install"`
— мережа налаштовується один раз і не потребує перезапиту при кожному
`update.sh`/повторному `install.sh`. `scripts/uninstall.sh` — окремий
файл (не прапорець у `install.sh`), щоб не ускладнювати основний потік
встановлення умовними гілками, які рідко використовуються.

## Придушені конкретні Telegram-сповіщення (журнал не зачіпається)

`MUTED_DISH_ALERTS={"roaming"}`, `MUTED_ROUTER_ALERTS={"install_pending"}`,
`MUTED_ROUTER_UPDATE_STATES={"GETTING_TARGET_VERSION_FAILED"}` — на
запит користувача ці три конкретні події не надсилаються в Telegram
(шумні/непрактичні для сповіщення в реальному часі), але й далі
пишуться в журнал подій дашборду. На відміну від `IGNORED_ROUTER_ALERTS`
(повне ігнорування, включно з БД/журналом) — тут приховується лише
Telegram-звіт.
