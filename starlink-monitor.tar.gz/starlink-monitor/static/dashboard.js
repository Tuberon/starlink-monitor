// 1.5с - dish реально опитується кожні POLL_INTERVAL_SEC (10с за
// замовчуванням), тому частіший polling лише додає HTTP/DB-
// навантаження без реальнішої "свіжості" даних, але 1.5с зберігає
// відчуття "живого" дашборду ближче до попереднього 1с.
const REFRESH_MS = 1500;

const el = (id) => document.getElementById(id);

function fmtUptime(seconds) {
  if (!seconds && seconds !== 0) return '—';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 24) {
    const d = Math.floor(h / 24);
    return `${d}${t('unit_days_short')} ${h % 24}${t('unit_hours_short')}`;
  }
  return `${h}${t('unit_hours_short')} ${m}${t('unit_minutes_short')}`;
}

function setValueClass(node, value, warnAt, critAt, higherIsBad = true) {
  node.classList.remove('warn', 'crit');
  if (value === null || value === undefined) return;
  if (higherIsBad) {
    if (value >= critAt) node.classList.add('crit');
    else if (value >= warnAt) node.classList.add('warn');
  } else {
    if (value <= critAt) node.classList.add('crit');
    else if (value <= warnAt) node.classList.add('warn');
  }
}

// Побудовані ЛІНИВО (функцією, не статичним object-літералом) - на
// момент завантаження цього файлу window.I18N може ще не бути
// готовим (порядок <script>-тегів), а мова інтерфейсу однаково не
// змінюється без перезавантаження сторінки, тому кешування після
// першого виклику безпечне й дешевше за виклик t() на кожен lookup.
let _UPDATE_STATE_LABELS = null;
function UPDATE_STATE_LABELS_get(code) {
  if (!_UPDATE_STATE_LABELS) _UPDATE_STATE_LABELS = {
    'SOFTWARE_UPDATE_STATE_UNKNOWN': t('us_unknown'),
    'IDLE': t('us_idle'),
    'FETCHING': t('us_fetching'),
    'PRE_CHECK': t('us_pre_check'),
    'WRITING': t('us_writing'),
    'POST_CHECK': t('us_post_check'),
    'REBOOT_REQUIRED': t('us_reboot_required'),
    'DISABLED': t('us_disabled'),
    'FAULTED': t('us_faulted'),
  };
  return _UPDATE_STATE_LABELS[code];
}

let _ALERT_LABELS = null;
function ALERT_LABELS_get(code) {
  if (!_ALERT_LABELS) _ALERT_LABELS = {
    'motors_stuck': t('alert_motors_stuck'),
    'thermal_shutdown': t('alert_thermal_shutdown'),
    'thermal_throttle': t('alert_thermal_throttle'),
    'unexpected_location': t('alert_unexpected_location'),
    'mast_not_near_vertical': t('alert_mast_not_near_vertical'),
    'slow_ethernet_speeds': t('alert_slow_ethernet_speeds'),
    'roaming': t('alert_roaming'),
    'install_pending': t('alert_install_pending'),
    'is_heating': t('alert_is_heating'),
    'power_supply_thermal_throttle': t('alert_power_supply_thermal_throttle'),
    'is_power_save_idle': t('alert_is_power_save_idle'),
    'dbf_telem_stale': t('alert_dbf_telem_stale'),
    'low_motor_current': t('alert_low_motor_current'),
    'lower_signal_than_predicted': t('alert_lower_signal_than_predicted'),
    'slow_ethernet_speeds_100': t('alert_slow_ethernet_speeds_100'),
    'obstruction_map_reset': t('alert_obstruction_map_reset'),
    'dish_water_detected': t('alert_dish_water_detected'),
    'router_water_detected': t('alert_router_water_detected'),
    'upsu_router_port_slow': t('alert_upsu_router_port_slow'),
    'no_ethernet_link': t('alert_no_ethernet_link'),
  };
  return _ALERT_LABELS[code];
}

let _ROUTER_UPDATE_STATE_LABELS = null;
function ROUTER_UPDATE_STATE_LABELS_get(code) {
  if (!_ROUTER_UPDATE_STATE_LABELS) _ROUTER_UPDATE_STATE_LABELS = {
    'NOT_RUN': t('rus_not_run'),
    'GETTING_TARGET_VERSION': t('rus_getting_target_version'),
    'DOWNLOADING_UPDATE_IMAGE': t('rus_downloading_update_image'),
    'FLASHING': t('rus_flashing'),
    'NO_UPDATE_REQUIRED': t('rus_no_update_required'),
    'REBOOT_PENDING': t('rus_reboot_pending'),
    // GETTING_TARGET_VERSION_FAILED і DOWNLOADING_UPDATE_IMAGE_FAILED
    // свідомо відсутні - обидва замінюються на 'NOT_RUN' перед цим
    // lookup'ом (HIDDEN_ROUTER_STATES нижче), тому запис тут ніколи б
    // не використовувався напряму.
    'GETTING_TARGET_VERSION_EXHAUSTED': t('rus_getting_target_version_exhausted'),
    'NO_VALID_ARTIFACT': t('rus_no_valid_artifact'),
    'ILLEGAL_ARTIFACT': t('rus_illegal_artifact'),
    'DOWNLOADING_UPDATE_IMAGE_EXHAUSTED': t('rus_downloading_update_image_exhausted'),
    'FLASHING_FAILED': t('rus_flashing_failed'),
  };
  return _ROUTER_UPDATE_STATE_LABELS[code];
}

// Стани, повністю приховані з дашборду (не лише текст мітки, а й сам
// стан замінюється на 'NOT_RUN') - "тимчасова хмарна помилка
// перевірки/завантаження оновлення на боці SpaceX", не проблема
// моніторингу. Той самий паттерн, що HIDDEN_ROUTER_STATES у
// app/display.py.
const HIDDEN_ROUTER_STATES = ['DOWNLOADING_UPDATE_IMAGE_FAILED', 'GETTING_TARGET_VERSION_FAILED'];

let _ROUTER_ALERT_LABELS = null;
function ROUTER_ALERT_LABELS_get(code) {
  if (!_ROUTER_ALERT_LABELS) _ROUTER_ALERT_LABELS = {
    'thermal_throttle': t('alert_thermal_throttle'),
    'install_pending': t('alert_install_pending'),
    'freshly_fused': t('ralert_freshly_fused'),
    'lan_eth_slow_link_10': t('ralert_lan_eth_slow_link_10'),
    'lan_eth_slow_link_100': t('ralert_lan_eth_slow_link_100'),
    'wan_eth_poor_connection': t('ralert_wan_eth_poor_connection'),
    'mesh_topology_changing_often': t('ralert_mesh_topology_changing_often'),
    'mesh_unreliable_backhaul': t('ralert_mesh_unreliable_backhaul'),
    'radius_missing_process': t('ralert_radius_missing_process'),
    'eth_switch_error': t('ralert_eth_switch_error'),
    'poe_on_dish_unreachable': t('ralert_poe_on_dish_unreachable'),
    'poe_fuse_blown': t('ralert_poe_fuse_blown'),
    'poe_router_overcurrent': t('ralert_poe_router_overcurrent'),
    'poe_off_current_nominal': t('ralert_poe_off_current_nominal'),
    'poe_vin_overvoltage': t('ralert_poe_vin_overvoltage'),
    'poe_vin_undervoltage': t('ralert_poe_vin_undervoltage'),
    'high_cable_ping_drop_rate': t('ralert_high_cable_ping_drop_rate'),
    'sandbox_disabled': t('ralert_sandbox_disabled'),
    'only_overflight_blocked': t('ralert_only_overflight_blocked'),
    'offline_networks_disabled': t('ralert_offline_networks_disabled'),
    'wired_mesh_not_using_wan_iface': t('ralert_wired_mesh_not_using_wan_iface'),
  };
  return _ROUTER_ALERT_LABELS[code];
}

const OFFLINE_CACHE_KEY = 'starlink_last_status_v1';

// Зберігаємо лише latest - невеликий JSON-об'єкт (кілька полів метрик),
// localStorage простіший і достатній тут (синхронний API, немає
// потреби у транзакціях/великому обсязі, які виправдовували б IndexedDB).
function _cacheLastStatus(latest) {
  try {
    localStorage.setItem(OFFLINE_CACHE_KEY, JSON.stringify({ latest, cachedAt: Date.now() / 1000 }));
  } catch (e) {
    // Приватний режим браузера/переповнення квоти - offline-fallback
    // просто не спрацює цього разу, не критично для основної функції.
    console.warn('Не вдалося закешувати стан:', e);
  }
}

function _loadCachedStatus() {
  try {
    const raw = localStorage.getItem(OFFLINE_CACHE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

function _showOfflineBanner(cachedAt) {
  const banner = el('offlineBanner');
  el('offlineBannerAgo').textContent = fmtAgo(cachedAt);
  banner.style.display = 'block';
}

function _hideOfflineBanner() {
  el('offlineBanner').style.display = 'none';
}

async function refreshStatus() {
  try {
    const res = await fetch('/api/status');
    const data = await res.json();
    const latest = data.latest;
    if (!latest) return;
    _cacheLastStatus(latest);
    _hideOfflineBanner();
    _renderStatusData(latest);
  } catch (e) {
    console.error('status refresh failed', e);
    const cached = _loadCachedStatus();
    if (cached && cached.latest) {
      _renderStatusData(cached.latest);
      _showOfflineBanner(cached.cachedAt);
    }
  }
}

function _renderStatusData(latest) {
    const pill = el('statusPill');
    const ring = el('ring');

    if (latest.online) {
      pill.classList.add('online');
      pill.classList.remove('offline');
      el('statusText').textContent = 'ONLINE';
      ring.style.setProperty('--ring-pct', '100%');
    } else {
      pill.classList.add('offline');
      pill.classList.remove('online');
      el('statusText').textContent = 'OFFLINE';
      ring.style.setProperty('--ring-pct', '15%');
    }

    const stateLabel = UPDATE_STATE_LABELS_get(latest.update_state) || latest.update_state || latest.state || '—';
    el('mState').textContent = stateLabel;
    el('mDown').innerHTML = `${latest.downlink_mbps ?? '—'}<span class="unit">${t('unit_mbps')}</span>`;
    el('mUp').innerHTML = `${latest.uplink_mbps ?? '—'}<span class="unit">${t('unit_mbps')}</span>`;
    el('mPing').innerHTML = `${latest.ping_latency_ms ?? '—'}<span class="unit">${t('unit_ms')}</span>`;

    const dropPct = latest.ping_drop_ratio != null ? (latest.ping_drop_ratio * 100).toFixed(1) : null;
    el('mDrop').innerHTML = `${dropPct ?? '—'}<span class="unit">%</span>`;
    setValueClass(el('mDrop'), dropPct, 2, 10);

    const obsPct = latest.obstruction_fraction != null ? (latest.obstruction_fraction * 100).toFixed(1) : null;
    el('mObs').innerHTML = `${obsPct ?? '—'}<span class="unit">%</span>`;
    setValueClass(el('mObs'), obsPct, 2, 5);

    el('mUptime').textContent = fmtUptime(latest.uptime_s);

    const sw = latest.software_version || '—';
    const hw = latest.hardware_version || '—';
    el('mDishId').textContent = latest.dish_id || '—';
    el('mFirmwareDish').textContent = t('fw_hw_line', {sw, hw});

    renderUpdateStatus(latest);
    renderAlerts(latest);
}

function renderUpdateStatus(latest) {
  const badge = el('updateStateBadge');
  const state = latest.update_state || 'SOFTWARE_UPDATE_STATE_UNKNOWN';
  badge.textContent = UPDATE_STATE_LABELS_get(state) || state;

  badge.classList.remove('state-idle', 'state-active', 'state-reboot');
  if (state === 'IDLE') {
    badge.classList.add('state-idle');
  } else if (state === 'REBOOT_REQUIRED' || state === 'FAULTED') {
    badge.classList.add('state-reboot');
  } else if (['FETCHING', 'PRE_CHECK', 'WRITING', 'POST_CHECK'].includes(state)) {
    badge.classList.add('state-active');
  }

  const progress = latest.update_progress_pct ?? 0;
  el('updateProgressFill').style.width = `${Math.max(0, Math.min(100, progress))}%`;
  el('updateProgressPct').textContent = `${progress.toFixed ? progress.toFixed(1) : progress}%`;

  const rebootFlag = el('updateRebootFlag');
  rebootFlag.hidden = !latest.update_requires_reboot;

  const installFlag = el('updateInstallFlag');
  installFlag.hidden = !latest.update_install_pending;
}

function renderAlerts(latest) {
  const body = el('alertsBody');
  const alerts = latest.active_alerts;
  if (!alerts || !alerts.length) {
    body.innerHTML = '<span class="alerts-none">активних попереджень немає</span>';
    return;
  }
  body.innerHTML = alerts
    .map(a => `<span class="alert-chip">${escapeHtml(ALERT_LABELS_get(a) || a)}</span>`)
    .join('');
}

async function refreshSystemStatus() {
  try {
    const res = await fetch('/api/system-status');
    const data = await res.json();

    const latest = data.latest;
    if (!latest) return;

    el('sUptime').textContent = fmtUptime(latest.uptime_s);

    const temp = latest.temp_c;
    el('sTemp').innerHTML = `${temp ?? '—'}<span class="unit">°C</span>`;
    setValueClass(el('sTemp'), temp, 70, 80);

    const cpu = latest.cpu_percent;
    el('sCpu').innerHTML = `${cpu ?? '—'}<span class="unit">%</span>`;
    setValueClass(el('sCpu'), cpu, 80, 95);

    const memPct = latest.mem_total_mb ? (latest.mem_used_mb / latest.mem_total_mb * 100).toFixed(1) : null;
    el('sMem').innerHTML = `${memPct ?? '—'}<span class="unit">%</span>`;
    setValueClass(el('sMem'), memPct, 80, 95);

    const diskPct = latest.disk_total_gb ? (latest.disk_used_gb / latest.disk_total_gb * 100).toFixed(1) : null;
    el('sDisk').innerHTML = `${diskPct ?? '—'}<span class="unit">%</span>`;
    setValueClass(el('sDisk'), diskPct, 80, 95);
  } catch (e) {
    console.error('system status refresh failed', e);
  }
}

async function refreshRouterStatus() {
  try {
    const res = await fetch('/api/router-status');
    const data = await res.json();
    const latest = data.latest;
    const el2 = el('mFirmwareRouter');
    if (!latest) {
      el2.textContent = t('not_polled_yet');
      el('routerUpdateStateBadge').textContent = '—';
      el('routerAlertsBody').innerHTML = `<span class="alerts-none">${t('not_polled_yet')}</span>`;
      renderRouterClients(null);
      return;
    }
    if (!latest.online) {
      el2.textContent = t('unavailable_reason', {reason: latest.error || t('no_response')});
      el('routerUpdateStateBadge').textContent = '—';
      renderRouterClients(latest.clients);
      return;
    }
    const sw = latest.software_version || '—';
    const hw = latest.hardware_version || '—';
    el2.textContent = t('fw_hw_line', {sw, hw});

    renderRouterUpdateStatus(latest);
    renderRouterAlerts(latest);
    renderRouterClients(latest.clients);
  } catch (e) {
    console.error('router status refresh failed', e);
  }
}

function fmtDuration(seconds) {
  if (seconds === null || seconds === undefined) return '—';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h}${t('unit_hours_short')} ${m}${t('unit_minutes_short')}`;
  return `${m}${t('unit_minutes_short')}`;
}

function signalClass(dbm) {
  if (dbm === null || dbm === undefined) return '';
  if (dbm >= -60) return 'good';
  if (dbm >= -75) return 'weak';
  return 'bad';
}

function renderRouterClients(clients) {
  const table = el('routerClientsTable');
  const countEl = el('routerClientsCount');
  // "Controller" - сам роутер Starlink, іноді потрапляє в список
  // клієнтів API, хоча насправді не є підключеним WiFi-пристроєм.
  const filtered = (clients || []).filter(c => c.name !== 'Controller');
  const rows = filtered.map(c => `
    <div class="clients-row">
      <span class="client-name">${escapeHtml(c.name || c.mac || '—')}</span>
      <span>${escapeHtml(c.ip || '—')}</span>
      <span>${escapeHtml((c.iface || '').replace('WIFI_', '').replace('GHZ', ' ГГц') || '—')}</span>
      <span class="clients-signal ${signalClass(c.signal)}">${c.signal != null ? c.signal + ' дБм' : '—'}</span>
      <span>${fmtDuration(c.connected_s)}</span>
    </div>
  `).join('');

  const header = '<div class="clients-row clients-header"><span>Пристрій</span><span>IP</span><span>Діапазон</span><span>Сигнал</span><span>У мережі</span></div>';

  if (!clients) {
    countEl.textContent = '—';
    table.innerHTML = header + '<div class="clients-row"><span>ще не опитано</span></div>';
  } else if (filtered.length === 0) {
    countEl.textContent = '0 підключено';
    table.innerHTML = header + '<div class="clients-row"><span>немає підключених клієнтів</span></div>';
  } else {
    countEl.textContent = t('clients_connected', {n: filtered.length});
    table.innerHTML = header + rows;
  }
}

function renderRouterUpdateStatus(latest) {
  const badge = el('routerUpdateStateBadge');
  const state = latest.update_state || 'NOT_RUN';
  // Не показуємо текст про цю конкретну помилку користувачу - роутер
  // регулярно проходить через цей стан як частину нормального циклу
  // перевірки, показ як "помилка" щоразу лише вводить в оману.
  const displayState = HIDDEN_ROUTER_STATES.includes(state) ? 'NOT_RUN' : state;
  badge.textContent = ROUTER_UPDATE_STATE_LABELS_get(displayState) || displayState;

  badge.classList.remove('state-idle', 'state-active', 'state-reboot');
  if (displayState === 'NOT_RUN' || displayState === 'NO_UPDATE_REQUIRED') {
    badge.classList.add('state-idle');
  } else if (displayState === 'REBOOT_PENDING' || displayState.includes('FAILED') || displayState.includes('ILLEGAL')) {
    badge.classList.add('state-reboot');
  } else if (['GETTING_TARGET_VERSION', 'DOWNLOADING_UPDATE_IMAGE', 'FLASHING'].includes(displayState)) {
    badge.classList.add('state-active');
  }

  const progress = latest.update_progress_pct ?? 0;
  el('routerUpdateProgressFill').style.width = `${Math.max(0, Math.min(100, progress))}%`;
  el('routerUpdateProgressPct').textContent = `${progress.toFixed ? progress.toFixed(1) : progress}%`;

  const installFlag = el('routerUpdateInstallFlag');
  installFlag.hidden = !latest.update_install_pending;
}

function renderRouterAlerts(latest) {
  const body = el('routerAlertsBody');
  const alerts = latest.active_alerts;
  if (!alerts || !alerts.length) {
    body.innerHTML = '<span class="alerts-none">активних попереджень немає</span>';
    return;
  }
  body.innerHTML = alerts
    .map(a => `<span class="alert-chip">${escapeHtml(ROUTER_ALERT_LABELS_get(a) || a)}</span>`)
    .join('');
}

let eventsClearedLocally = false;

async function refreshEvents() {
  if (eventsClearedLocally) return;
  try {
    const res = await fetch('/api/events?limit=10');
    const events = await res.json();
    const log = el('eventLog');
    if (!events.length) {
      log.innerHTML = `<div class="log-row"><span class="time">—</span><span class="kind">—</span><span>${t('no_events_yet')}</span></div>`;
      return;
    }
    log.innerHTML = events.map(ev => `
      <div class="log-row ${ev.success ? 'ok' : 'fail'}">
        <span class="time">${fmtTime(ev.ts)}</span>
        <span class="kind">${escapeHtml(ev.kind.replace(/_/g, ' '))}${ev.count > 1 ? ` ×${ev.count}` : ''}</span>
        <span>${escapeHtml(ev.message || '')}</span>
      </div>
    `).join('');
  } catch (e) {
    console.error('events refresh failed', e);
  }
}

async function handleReboot() {
  const btn = el('rebootBtn');
  const hint = el('rebootHint');
  if (!confirm(t('confirm_reboot_starlink'))) return;

  btn.disabled = true;
  hint.textContent = t('sending_reboot_cmd');
  try {
    const res = await fetch('/api/reboot-dish', { method: 'POST' });
    const data = await res.json();
    hint.textContent = data.success ? t('reboot_cmd_sent_ok') : `${t('error_prefix')}: ${data.message}`;
    refreshEvents();
  } catch (e) {
    hint.textContent = t('network_error_sending');
  } finally {
    setTimeout(() => { btn.disabled = false; }, 5000);
  }
}

async function handlePiReboot() {
  const btn = el('piRebootBtn');
  const hint = el('piControlHint');
  if (!confirm(t('confirm_reboot_pi'))) return;

  btn.disabled = true;
  hint.textContent = t('sending_pi_reboot_cmd');
  try {
    const res = await fetch('/api/system-reboot', { method: 'POST' });
    const data = await res.json();
    hint.textContent = data.success ? t('pi_rebooting') : `${t('error_prefix')}: ${data.message}`;
  } catch (e) {
    hint.textContent = t('cmd_sent_disconnected');
  }
}

async function handlePiShutdown() {
  const btn = el('piShutdownBtn');
  const hint = el('piControlHint');
  if (!confirm(t('confirm_shutdown_pi_1'))) return;
  if (!confirm(t('confirm_shutdown_pi_2'))) return;

  btn.disabled = true;
  hint.textContent = t('sending_pi_shutdown_cmd');
  try {
    const res = await fetch('/api/system-shutdown', { method: 'POST' });
    const data = await res.json();
    hint.textContent = data.success ? t('pi_shutting_down') : `${t('error_prefix')}: ${data.message}`;
  } catch (e) {
    hint.textContent = t('cmd_sent_disconnected');
  }
}

function handleClearEvents() {
  eventsClearedLocally = true;
  el('eventLog').innerHTML = `<div class="log-row"><span class="time">—</span><span class="kind">—</span><span>${t('log_cleared_locally')}</span></div>`;
}

async function handleCheckUpdates() {
  const btn = el('checkUpdatesBtn');
  const hint = el('checkUpdatesHint');

  btn.disabled = true;
  btn.classList.add('spinning');
  hint.textContent = t('polling_dish_router');
  try {
    const res = await fetch('/api/check-updates', { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      const dishState = UPDATE_STATE_LABELS_get(data.dish.update_state) || data.dish.update_state || t('not_available_short');
      const routerRawState = HIDDEN_ROUTER_STATES.includes(data.router.update_state) ? 'NOT_RUN' : data.router.update_state;
      const routerState = ROUTER_UPDATE_STATE_LABELS_get(routerRawState) || routerRawState || t('not_available_short');
      hint.textContent = t('check_done', {dish: dishState, router: routerState});
    } else {
      hint.textContent = t('check_error');
    }
    tick(true);
  } catch (e) {
    hint.textContent = t('network_error_checking');
    console.error('check updates failed', e);
  } finally {
    btn.disabled = false;
    btn.classList.remove('spinning');
  }
}

async function loadConfigFlags() {
  try {
    const res = await fetch('/api/config');
    const cfg = await res.json();
    updateAutoRebootUI(cfg.auto_reboot_on_update_ready);
  } catch (e) {
    console.error('config load failed', e);
  }
}

function updateAutoRebootUI(enabled) {
  const toggle = el('autoRebootToggle');
  const badge = el('autoRebootStatusBadge');
  toggle.checked = enabled;
  badge.textContent = enabled ? t('enabled') : t('disabled_word');
  badge.classList.remove('state-idle', 'state-reboot');
  badge.classList.add(enabled ? 'state-idle' : 'state-reboot');
}

async function handleAutoRebootToggle(e) {
  const toggle = e.target;
  const enabled = toggle.checked;
  toggle.disabled = true;
  try {
    const res = await fetch('/api/auto-reboot', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled }),
    });
    const data = await res.json();
    updateAutoRebootUI(data.enabled);
    refreshEvents();
  } catch (e) {
    console.error('auto-reboot toggle failed', e);
    toggle.checked = !enabled;
  } finally {
    toggle.disabled = false;
  }
}

// Рідше опитуються дані, що рідко змінюються: стан роутера (монітор
// опитує його раз на 35 с), метрики Pi (раз на 60 с), журнал подій.
// Раніше всі 4 запити йшли кожні 1.5 с (~9600/год на вкладку), хоча 3
// з них майже завжди повертали те саме. force - оновити все одразу
// (відкриття сторінки, повернення на вкладку, після дій користувача).
const EVENTS_EVERY_TICKS = 4;   // ~6 с
const SLOW_EVERY_TICKS = 10;    // ~15 с
let tickCount = 0;

function tick(force) {
  refreshStatus();
  if (force === true || tickCount % EVENTS_EVERY_TICKS === 0) refreshEvents();
  if (force === true || tickCount % SLOW_EVERY_TICKS === 0) {
    refreshSystemStatus();
    refreshRouterStatus();
  }
  tickCount++;
}

document.addEventListener('DOMContentLoaded', () => {
  el('rebootBtn').addEventListener('click', handleReboot);
  el('piRebootBtn').addEventListener('click', handlePiReboot);
  el('piShutdownBtn').addEventListener('click', handlePiShutdown);
  el('clearEventsBtn').addEventListener('click', handleClearEvents);
  el('checkUpdatesBtn').addEventListener('click', handleCheckUpdates);
  el('autoRebootToggle').addEventListener('change', handleAutoRebootToggle);
  loadConfigFlags();
  tick();

  // Вкладка згорнута/неактивна - опитування раз на 30с замість
  // щосекунди (dish/Pi нікуди не дінеться за цей час, а зайві
  // запити з фонової вкладки лише навантажують слабкий WiFi-канал
  // і сам Pi Zero 2 W без жодної практичної користі, поки користувач
  // не дивиться на дашборд).
  const HIDDEN_REFRESH_MS = 30000;
  let refreshTimer = setInterval(tick, REFRESH_MS);

  document.addEventListener('visibilitychange', () => {
    clearInterval(refreshTimer);
    if (document.visibilityState === 'visible') {
      tick(true); // одразу освіжити ВСІ дані після повернення на вкладку
      refreshTimer = setInterval(tick, REFRESH_MS);
    } else {
      refreshTimer = setInterval(tick, HIDDEN_REFRESH_MS);
    }
  });
});
