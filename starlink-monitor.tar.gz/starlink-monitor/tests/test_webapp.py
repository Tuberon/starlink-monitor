"""
Тести для app/db.py (компаратор версій прошивки Starlink) та
app/webapp.py (валідація /api/target-versions - "лише новіші").
"""
import json
import os
import time
from unittest.mock import patch

import pytest

from app import config, db
from app.webapp import app as flask_app


# ---- Компаратор версій (db.version_key/db.is_older_version) ----

@pytest.mark.parametrize("older,newer", [
    ("2026.03.03.mr75126.1", "2026.03.15.mr80000.1"),  # різні дати
    ("2025.10.03.mr61821", "2026.03.03.mr75126.1"),  # різний рік
])
def test_is_older_version_true_cases(older, newer):
    assert db.is_older_version(older, newer) is True
    assert db.is_older_version(newer, older) is False


def test_is_older_version_identical_versions_not_older():
    v = "2026.03.03.mr75126.1"
    assert db.is_older_version(v, v) is False


def test_is_older_version_same_date_lower_build_number():
    """Той самий день, менший mr-номер - вважається старішою."""
    assert db.is_older_version("2026.03.03.mr75126.1", "2026.03.03.mr80000.1") is True
    assert db.is_older_version("2026.03.03.mr80000.1", "2026.03.03.mr75126.1") is False


def test_is_older_version_nonstandard_format_does_not_crash():
    """Формат без YYYY.MM.DD-префіксу - fallback на посегментне
    порівняння, не падає з винятком."""
    assert db.is_older_version("v1.0", "v2.0") is True
    assert db.is_older_version("", "2026.03.03") is True
    assert db.is_older_version("unknown", "unknown") is False


# ---- API /api/target-versions - валідація "лише новіші" ----

@pytest.fixture
def client(db_path):
    with flask_app.test_client() as c:
        yield c


def _insert_dish_version(version):
    from app.starlink_client import DishStatus
    db.insert_metric(DishStatus(timestamp=time.time(), online=True, uptime_s=100, software_version=version).to_dict())


def _insert_router_version(version):
    from app.starlink_client import RouterInfo
    db.set_router_status(RouterInfo(timestamp=time.time(), online=True, software_version=version).to_dict())


def test_target_versions_first_input_equal_to_current_accepted(client):
    _insert_dish_version("2026.03.03.mr75126.1")
    resp = client.post("/api/target-versions", json={"dish_target": "2026.03.03.mr75126.1"})
    assert resp.get_json()["success"] is True


def test_target_versions_older_than_current_rejected(client):
    _insert_dish_version("2026.03.03.mr75126.1")
    client.post("/api/target-versions", json={"dish_target": "2026.03.03.mr75126.1"})

    resp = client.post("/api/target-versions", json={"dish_target": "2025.01.01.mr1000.1"})
    data = resp.get_json()
    assert data["success"] is False
    assert "старіша" in data["message"]

    # target реально НЕ перезаписаний старішим значенням
    check = client.get("/api/target-versions").get_json()
    assert check["dish_target"] == "2026.03.03.mr75126.1"


def test_target_versions_newer_accepted(client):
    _insert_dish_version("2026.03.03.mr75126.1")
    client.post("/api/target-versions", json={"dish_target": "2026.03.03.mr75126.1"})

    resp = client.post("/api/target-versions", json={"dish_target": "2026.04.01.mr80000.1"})
    assert resp.get_json()["success"] is True


def test_target_versions_partial_success_mixed_dish_router(client):
    """dish (новіше, valid) + router (старіше за поточну встановлену,
    invalid) одночасно - валідне поле зберігається, невалідне
    відхиляється окремо (не 'усе або нічого')."""
    _insert_dish_version("2026.03.03.mr75126.1")
    _insert_router_version("2025.10.03")

    resp = client.post("/api/target-versions", json={
        "dish_target": "2026.05.01.mr90000.1",
        "router_target": "2024.01.01",
    })
    data = resp.get_json()
    assert data["success"] is True  # dish зберігся, тому success=True
    assert "роутер" in data["message"]

    check = client.get("/api/target-versions").get_json()
    assert check["dish_target"] == "2026.05.01.mr90000.1"
    assert check["router_target"] is None


def test_target_versions_multiple_candidates_all_newer_accepted(client):
    """Кілька версій через кому (різні апаратні ревізії), усі новіші
    за поточну - весь список приймається."""
    _insert_dish_version("2026.03.03.mr75126.1")
    resp = client.post("/api/target-versions", json={
        "dish_target": "2026.04.01.mr80000.1, 2026.04.01.mr80005.1",
    })
    data = resp.get_json()
    assert data["success"] is True
    check = client.get("/api/target-versions").get_json()
    assert check["dish_target"] == "2026.04.01.mr80000.1, 2026.04.01.mr80005.1"


def test_target_versions_multiple_candidates_one_older_rejects_whole_list(client):
    """Якщо ХОЧ ОДИН кандидат у списку старіший за baseline -
    відхиляється ВЕСЬ список для цього поля (не часткове прийняття
    окремих кандидатів)."""
    _insert_dish_version("2026.03.03.mr75126.1")
    client.post("/api/target-versions", json={"dish_target": "2026.03.03.mr75126.1"})

    resp = client.post("/api/target-versions", json={
        "dish_target": "2026.04.01.mr80000.1, 2020.01.01",
    })
    data = resp.get_json()
    assert data["success"] is False
    assert "2020.01.01" in data["message"]

    check = client.get("/api/target-versions").get_json()
    assert check["dish_target"] == "2026.03.03.mr75126.1"  # старий список не перезаписаний


def test_target_versions_empty_string_clears_field(client):
    """Порожній рядок, явно надісланий - команда ОЧИСТИТИ поле, не
    'нічого не робити' (реальна прогалина: раніше порожній рядок
    просто мовчки ігнорувався, старе значення лишалось назавжди без
    жодного способу його скасувати)."""
    client.post("/api/target-versions", json={"dish_target": "2026.03.03"})
    resp = client.post("/api/target-versions", json={"dish_target": ""})
    data = resp.get_json()
    assert data["success"] is True
    assert "очищено" in data["message"]

    check = client.get("/api/target-versions").get_json()
    assert not check["dish_target"]


def test_target_versions_response_always_has_explicit_message(client):
    """API завжди повертає message, що описує РЕАЛЬНИЙ результат -
    не лише коли є rejected (раніше success-без-rejected випадок
    повертав голий {"success": true} без жодного пояснення)."""
    resp1 = client.post("/api/target-versions", json={"dish_target": "2026.03.03"})
    assert "message" in resp1.get_json()

    resp2 = client.post("/api/target-versions", json={})
    assert resp2.get_json()["message"] == "Без змін"


def test_target_versions_backup_includes_targets_not_notified_state(client):
    """Target-версії (user-налаштування) включені в backup, internal
    dedup-стан (*_notified) - навмисно ні."""
    db.set_setting("dish_target_version", "2026.06.01")
    db.set_setting("dish_target_notified", "2026.06.01")

    backup = client.get("/api/settings-backup").get_json()
    assert backup["dish_target_version"] == "2026.06.01"
    assert "dish_target_notified" not in backup
    assert "both_targets_notified" not in backup


# ---- /api/check-updates - ручна кнопка має ту саму логіку сповіщень, що фоновий watchdog ----

def test_manual_check_updates_sends_target_version_notification(client, monkeypatch):
    """Найважливіший регресійний тест: раніше ручна перевірка ЛИШЕ
    записувала статус у БД, БЕЗ жодного сповіщення, навіть коли версія
    якраз збігалась із target у момент натискання кнопки."""
    from app.starlink_client import DishStatus, RouterInfo
    from app import webapp as webapp_module

    db.set_setting("dish_target_version", "2026.03.03.mr75126.1")

    dish_status = DishStatus(
        timestamp=time.time(), online=True, uptime_s=100,
        software_version="2026.03.03.mr75126.1", dish_id="dish1", hardware_version="rev3",
    )
    router_status = RouterInfo(timestamp=time.time(), online=True, software_version="2025.10.03")

    sent = []
    monkeypatch.setattr("app.telegram_notify.send_message", lambda t: sent.append(t))
    monkeypatch.setattr(webapp_module.client, "get_status", lambda: dish_status)
    monkeypatch.setattr(webapp_module.client, "get_router_info", lambda: router_status)

    resp = client.post("/api/check-updates")
    assert resp.status_code == 200

    assert len(sent) == 1
    assert "2026.03.03.mr75126.1" in sent[0]


def test_manual_check_updates_upserts_known_devices(client, monkeypatch):
    """Ручна перевірка тепер теж оновлює known_devices (раніше -
    жодного запису взагалі, /id у Telegram-боті показував би
    застарілі чи відсутні дані)."""
    from app.starlink_client import DishStatus, RouterInfo
    from app import webapp as webapp_module

    dish_status = DishStatus(
        timestamp=time.time(), online=True, uptime_s=100,
        software_version="v1", dish_id="dish-manual", hardware_version="rev3",
    )
    router_status = RouterInfo(timestamp=time.time(), online=True, software_version="r1")

    monkeypatch.setattr("app.telegram_notify.send_message", lambda t: None)
    monkeypatch.setattr(webapp_module.client, "get_status", lambda: dish_status)
    monkeypatch.setattr(webapp_module.client, "get_router_info", lambda: router_status)

    client.post("/api/check-updates")

    known = db.get_known_device("dish-manual")
    assert known is not None
    assert known["dish_software_version"] == "v1"
    assert known["router_software_version"] == "r1"


def test_backup_includes_known_devices(client):
    db.upsert_known_device_dish("dish-AAA", "rev3", "v1.0")
    backup = client.get("/api/settings-backup").get_json()
    assert len(backup["known_devices"]) == 1
    assert backup["known_devices"][0]["dish_id"] == "dish-AAA"


def test_restore_known_devices_via_api(client):
    payload = {
        "format_version": 1,
        "known_devices": [
            {"dish_id": "dish-XYZ", "first_seen_ts": 1000.0, "last_seen_ts": 2000.0,
             "dish_software_version": "v3.0"},
        ],
    }
    resp = client.post("/api/settings-restore", json=payload)
    data = resp.get_json()
    assert data["success"] is True
    assert "1 нових з 1" in data["message"]
    assert db.get_known_device("dish-XYZ") is not None


# ---- version_channel / channel-aware валідація - різні апаратні ревізії Starlink ----

def test_version_channel_extracts_letter_prefix():
    from app.db import version_channel
    assert version_channel("2026.07.06.cr81950.49600") == "cr"
    assert version_channel("2026.07.19.mr82648") == "mr"
    assert version_channel("2020.01.01") is None
    assert version_channel("") is None


def test_target_versions_different_build_channels_not_compared(client):
    """Точний сценарій, знайдений користувачем на практиці: 'mr' і 'cr'
    build-канали можуть відповідати РІЗНИМ апаратним ревізіям з
    незалежними датами випуску одночасно - порівнювати дату напряму
    між каналами дає хибне відхилення "старіша версія"."""
    _insert_dish_version("2026.07.19.mr82648")
    resp = client.post("/api/target-versions", json={"dish_target": "2026.07.06.cr81950.49600"})
    data = resp.get_json()
    assert data["success"] is True, f"різні build-канали (mr/cr) не мають блокувати одне одного: {data}"


def test_target_versions_same_channel_still_rejects_older(client):
    """Контрольний тест: У МЕЖАХ ТОГО САМОГО каналу (mr) захист від
    відкату все ще коректно працює - фіча не послабила звичайну
    валідацію, лише додала ізоляцію МІЖ різними каналами."""
    _insert_dish_version("2026.07.19.mr82648")
    resp = client.post("/api/target-versions", json={"dish_target": "2026.03.03.mr70000"})
    data = resp.get_json()
    assert data["success"] is False
    assert "mr70000" in data["message"]


def test_target_versions_candidate_without_channel_compares_globally(client):
    """Edge case, знайдений власним тестом одразу після першої
    реалізації channel-aware логіки: candidate БЕЗ явного каналу
    (проста дата, без mr/cr-суфікса) - це НЕ "свій окремий канал",
    порівнюється з УСІМА baseline звичайно (fallback), а не хибно
    приймається як "непорівнюваний з рештою"."""
    _insert_dish_version("2026.07.19.mr82648")
    resp = client.post("/api/target-versions", json={"dish_target": "2020.01.01"})
    data = resp.get_json()
    assert data["success"] is False, "версія без каналу (2020.01.01) мала порівнятись глобально й відхилитись"


def test_target_versions_matching_current_installed_always_accepted_after_rollback(client):
    """Точний сценарій із реального повідомлення користувача: target
    раніше введений як 07-24, ПОТІМ dish РЕАЛЬНО відкотився (SpaceX-
    side rollback, вже підтверджений раніше) на 07-19 - user хоче
    узгодити target із ФАКТИЧНОЮ реальністю. Candidate, що ТОЧНО
    збігається з поточною встановленою версією, завжди приймається,
    незалежно від старішого попереднього target."""
    _insert_dish_version("2026.07.24.mr83021")
    client.post("/api/target-versions", json={"dish_target": "2026.07.24.mr83021"})

    _insert_dish_version("2026.07.19.mr82648")  # реальний rollback
    resp = client.post("/api/target-versions", json={"dish_target": "2026.07.19.mr82648"})
    data = resp.get_json()
    assert data["success"] is True, f"узгодження з фактично встановленою версією мало прийнятись: {data}"

    check = client.get("/api/target-versions").get_json()
    assert check["dish_target"] == "2026.07.19.mr82648"


def test_target_versions_real_typo_still_rejected_after_rollback_fix(client):
    """Контрольний тест: фікс "завжди дозволяти поточну версію" НЕ
    послабив захист від СПРАВЖНІХ описок (candidate, що НЕ збігається
    ні з поточною версією, ні є новішим за попередній target)."""
    _insert_dish_version("2026.07.24.mr83021")
    client.post("/api/target-versions", json={"dish_target": "2026.07.24.mr83021"})

    resp = client.post("/api/target-versions", json={"dish_target": "2026.01.01.mr50000"})
    data = resp.get_json()
    assert data["success"] is False, "справжня описка (не поточна версія, не новіша) мала відхилитись"


# ---- /healthz - зовнішній моніторинг (UptimeRobot тощо) ----

def test_healthz_no_data_yet_returns_200(client):
    """Реальний сценарій: щойно встановлений Pi, watchdog ще жодного
    разу не записав метрику - НЕ має вважатись "degraded" (503),
    процес просто щойно стартував."""
    resp = client.get("/healthz")
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["checks"]["watchdog"] == "no data yet"


def test_healthz_fresh_metric_returns_200(client):
    from app.starlink_client import DishStatus
    db.insert_metric(DishStatus(timestamp=time.time(), online=True, uptime_s=100).to_dict())
    resp = client.get("/healthz")
    data = resp.get_json()
    assert resp.status_code == 200
    assert data["status"] == "ok"
    assert "ok" in data["checks"]["watchdog"]


def test_healthz_stale_metric_returns_503(client):
    """Головна мета /healthz: watchdog реально завис (deadlock, не
    crash) - метрика стара, свіжих немає, зовнішній моніторинг МАЄ
    отримати 503, не тихе 200."""
    from app import config
    from app.starlink_client import DishStatus
    stale_ts = time.time() - (config.POLL_INTERVAL_SEC * 3 + config.DISH_METRICS_BATCH_INTERVAL_SEC + 60)
    db.insert_metric(DishStatus(timestamp=stale_ts, online=True, uptime_s=100).to_dict())
    resp = client.get("/healthz")
    data = resp.get_json()
    assert resp.status_code == 503
    assert data["status"] == "degraded"
    assert "stale" in data["checks"]["watchdog"]


# ---- /api/reboot-dish - реальна фізична дія ----

def test_reboot_dish_success_logs_event_and_notifies(client):
    from app import webapp
    with patch.object(webapp.client, "reboot_dish", return_value=(True, "ok")), \
         patch("app.telegram_notify.send_message") as mock_notify:
        resp = client.post("/api/reboot-dish")
    data = resp.get_json()
    assert data["success"] is True
    events = db.get_recent_events(10)
    assert any(e["kind"] == "dish_reboot" for e in events)
    mock_notify.assert_called_once()
    assert "перезавантажено" in mock_notify.call_args[0][0]


def test_reboot_dish_failure_reports_error_message(client):
    from app import webapp
    with patch.object(webapp.client, "reboot_dish", return_value=(False, "timeout")), \
         patch("app.telegram_notify.send_message") as mock_notify:
        resp = client.post("/api/reboot-dish")
    data = resp.get_json()
    assert data["success"] is False
    assert "Не вдалося" in mock_notify.call_args[0][0]


# ---- /api/telegram-config - маскування token (безпекова логіка) ----

def test_telegram_config_get_no_token_set(client):
    resp = client.get("/api/telegram-config")
    data = resp.get_json()
    assert data["token_set"] is False
    assert data["token_masked"] == ""


def test_telegram_config_get_masks_long_token(client):
    """Реальна мета: повний token НІКОЛИ не має з'являтись у відповіді
    (secret, видимий у мережевому інспекторі браузера/консолі)."""
    from app import telegram_notify
    telegram_notify.set_telegram_config(token="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11", chat_ids=None, enabled=None)
    resp = client.get("/api/telegram-config")
    data = resp.get_json()
    assert data["token_set"] is True
    assert "123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11" not in str(data)
    assert data["token_masked"].startswith("123456")
    assert "..." in data["token_masked"]


def test_telegram_config_get_masks_short_token_fully(client):
    """Короткий token (<=10 символів) - взагалі не показує жодної
    його частини (навіть перші 6 символів вже забагато для дуже
    короткого secret), просто "***"."""
    from app import telegram_notify
    telegram_notify.set_telegram_config(token="short1", chat_ids=None, enabled=None)
    resp = client.get("/api/telegram-config")
    data = resp.get_json()
    assert data["token_masked"] == "***"
    assert "short1" not in str(data)


def test_telegram_config_post_parses_comma_separated_string(client):
    resp = client.post("/api/telegram-config", json={"chat_ids": "111, 222 ,333"})
    assert resp.get_json()["success"] is True
    from app import telegram_notify
    _, chat_ids, _ = telegram_notify.get_telegram_config()
    assert chat_ids == ["111", "222", "333"]


def test_telegram_config_post_accepts_list_directly(client):
    resp = client.post("/api/telegram-config", json={"chat_ids": ["444", "555"]})
    assert resp.get_json()["success"] is True
    from app import telegram_notify
    _, chat_ids, _ = telegram_notify.get_telegram_config()
    assert chat_ids == ["444", "555"]


# ---- /api/auto-reboot ----

def test_set_auto_reboot_toggle_on(client):
    resp = client.post("/api/auto-reboot", json={"enabled": True})
    data = resp.get_json()
    assert data["success"] is True
    assert data["enabled"] is True
    assert db.get_auto_reboot_enabled() is True


def test_set_auto_reboot_toggle_off(client):
    client.post("/api/auto-reboot", json={"enabled": True})
    resp = client.post("/api/auto-reboot", json={"enabled": False})
    assert resp.get_json()["enabled"] is False
    assert db.get_auto_reboot_enabled() is False


# ---- /api/settings-backup + /api/settings-restore - повний цикл ----

def test_backup_then_restore_round_trip(client):
    from app import telegram_notify
    telegram_notify.set_telegram_config(token="test-token-123456789", chat_ids=["777"], enabled=True)
    db.set_auto_reboot_enabled(True)

    backup_resp = client.get("/api/settings-backup")
    backup_data = backup_resp.get_json()
    assert backup_data["telegram_bot_token"] == "test-token-123456789"

    telegram_notify.set_telegram_config(token="", chat_ids=[], enabled=False)
    db.set_auto_reboot_enabled(False)

    restore_resp = client.post("/api/settings-restore", data=json.dumps(backup_data), content_type="application/json")
    assert restore_resp.get_json()["success"] is True

    token, chat_ids, enabled = telegram_notify.get_telegram_config()
    assert token == "test-token-123456789"
    assert chat_ids == ["777"]
    assert db.get_auto_reboot_enabled() is True


def test_restore_rejects_payload_without_format_version(client):
    resp = client.post("/api/settings-restore", data=json.dumps({"telegram_bot_token": "x"}), content_type="application/json")
    data = resp.get_json()
    assert data["success"] is False
    assert "формат" in data["message"].lower()


# ---- Решта restore-гілок та env-config endpoints ----

def test_restore_applies_env_params(client):
    from app import services
    backup = services.build_backup_dict()
    backup["env_params"] = {"STARLINK_POLL_INTERVAL": "15"}
    resp = client.post("/api/settings-restore", data=json.dumps(backup), content_type="application/json")
    data = resp.get_json()
    assert data["success"] is True
    assert "параметри моніторингу" in data["message"]


def test_restore_applies_target_versions(client):
    from app import services
    backup = services.build_backup_dict()
    backup["dish_target_version"] = "2026.01.01.mr1"
    resp = client.post("/api/settings-restore", data=json.dumps(backup), content_type="application/json")
    assert resp.get_json()["success"] is True
    assert db.get_setting("dish_target_version") == "2026.01.01.mr1"


def test_restore_applies_known_devices(client):
    from app import services
    backup = services.build_backup_dict()
    backup["known_devices"] = [{
        "dish_id": "restored-dish", "first_seen_ts": time.time(), "last_seen_ts": time.time(),
    }]
    resp = client.post("/api/settings-restore", data=json.dumps(backup), content_type="application/json")
    assert resp.get_json()["success"] is True
    assert db.get_known_device("restored-dish") is not None


def test_restore_handles_malformed_payload_without_crashing(client):
    """Реальний edge case: payload з format_version, але з іншими
    полями зіпсованого типу (напр. known_devices - рядок, не список).
    Головна гарантія - НЕ падає з 500 (виняток спіймано і повернутий
    як success=False), а не конкретне значення success для ЦЬОГО
    прикладу (known_devices="not-a-list" ітерується як символи, кожен
    ігнорується merge_known_devices() через відсутність dish_id -
    толерантно, без винятку)."""
    resp = client.post(
        "/api/settings-restore",
        data=json.dumps({"format_version": 3, "known_devices": "not-a-list"}),
        content_type="application/json",
    )
    assert resp.status_code == 200
    assert "success" in resp.get_json()


def test_restore_exception_path_returns_success_false(client):
    """Реальний виняток (не толерантний edge case) МАЄ повернути
    success=False, не поширюватись як 500."""
    resp = client.post(
        "/api/settings-restore",
        data=json.dumps({"format_version": 3, "env_params": "not-a-dict"}),
        content_type="application/json",
    )
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["success"] is False


# ---- /api/env-config ----

def test_env_config_get_returns_all_params_with_categories(client):
    resp = client.get("/api/env-config")
    data = resp.get_json()
    assert len(data["params"]) > 0
    assert "category_labels" in data


def test_env_config_post_saves_and_logs_event(client):
    resp = client.post("/api/env-config", json={"values": {"STARLINK_POLL_INTERVAL": "20"}})
    data = resp.get_json()
    assert data["success"] is True
    events = db.get_recent_events(10)
    assert any(e["kind"] == "env_config_updated" for e in events)


def test_env_config_post_validation_error_reports_failure(client):
    resp = client.post("/api/env-config", json={"values": {"STARLINK_POLL_INTERVAL": "not-a-number"}})
    data = resp.get_json()
    assert data["success"] is False


# ---- /healthz - except-гілки (db/watchdog помилки) ----

def test_healthz_db_exception_reports_degraded(client):
    with patch("app.db.get_conn", side_effect=RuntimeError("БД заблокована")):
        resp = client.get("/healthz")
    data = resp.get_json()
    assert resp.status_code == 503
    assert "error" in data["checks"]["db"]


def test_healthz_watchdog_check_exception_reports_degraded(client):
    with patch("app.db.get_latest_metric", side_effect=RuntimeError("несподівана помилка")):
        resp = client.get("/healthz")
    data = resp.get_json()
    assert resp.status_code == 503
    assert "error" in data["checks"]["watchdog"]


# ---- /api/telegram-test ----

def test_telegram_test_success_sends_test_message(client):
    with patch("app.telegram_notify.test_connection", return_value=(True, "OK")), \
         patch("app.telegram_notify.send_message", return_value=(True, "надіслано")):
        resp = client.post("/api/telegram-test")
    data = resp.get_json()
    assert data["success"] is True


def test_telegram_test_invalid_token_does_not_attempt_send(client):
    send_calls = []
    with patch("app.telegram_notify.test_connection", return_value=(False, "Unauthorized")), \
         patch("app.telegram_notify.send_message", side_effect=lambda *a: send_calls.append(1)):
        resp = client.post("/api/telegram-test")
    data = resp.get_json()
    assert data["success"] is False
    assert send_calls == []


def test_telegram_test_connection_ok_but_send_fails(client):
    with patch("app.telegram_notify.test_connection", return_value=(True, "OK")), \
         patch("app.telegram_notify.send_message", return_value=(False, "chat not found")):
        resp = client.post("/api/telegram-test")
    data = resp.get_json()
    assert data["success"] is False
    assert "chat not found" in data["message"]


# ---- Основні status-endpoints дашборду (реально викликаються щосекунди через tick()) ----

def test_api_status_returns_latest_metric(client):
    from app.starlink_client import DishStatus
    db.insert_metric(DishStatus(timestamp=time.time(), online=True, uptime_s=100).to_dict())
    resp = client.get("/api/status")
    data = resp.get_json()
    assert data["latest"]["online"] == 1


def test_api_status_no_data_returns_none_latest(client):
    resp = client.get("/api/status")
    data = resp.get_json()
    assert data["latest"] is None


def test_api_events_returns_recent_events(client):
    db.insert_event("test", "тестова подія", success=True)
    resp = client.get("/api/events")
    events = resp.get_json()
    assert len(events) == 1
    assert events[0]["message"] == "тестова подія"


def test_api_events_respects_limit_parameter(client):
    for i in range(5):
        db.insert_event("test", f"подія {i}", success=True)
    resp = client.get("/api/events?limit=2")
    events = resp.get_json()
    assert len(events) == 2


def test_api_events_caps_limit_at_500(client):
    resp = client.get("/api/events?limit=999999")
    assert resp.status_code == 200  # не мало кинути помилку через надто великий limit


def test_api_system_status_returns_latest(client):
    db.insert_system_metric({"timestamp": time.time(), "cpu_percent": 5.0})
    resp = client.get("/api/system-status")
    data = resp.get_json()
    assert data["latest"]["cpu_percent"] == 5.0


def test_api_router_status_returns_latest(client):
    from app.starlink_client import RouterInfo
    db.set_router_status(RouterInfo(timestamp=time.time(), online=True, software_version="r1").to_dict())
    resp = client.get("/api/router-status")
    data = resp.get_json()
    assert data["latest"]["software_version"] == "r1"


def test_api_router_status_no_data_returns_none(client):
    resp = client.get("/api/router-status")
    data = resp.get_json()
    assert data["latest"] is None


# ---- _static_v() - cache-busting ----

def test_static_v_missing_file_falls_back_to_zero():
    """Реальний edge case: файл видалений чи ще не існує - cache-
    busting параметр МАЄ бути 0 (не кидати виняток, що зламало б
    рендеринг усього шаблону)."""
    from app.webapp import _static_v
    result = _static_v("nonexistent-file-xyz.js")
    assert result == "/static/nonexistent-file-xyz.js?v=0"


def test_static_v_existing_file_uses_real_mtime():
    from app.webapp import _static_v
    result = _static_v("style.css")
    assert result.startswith("/static/style.css?v=")
    assert result != "/static/style.css?v=0"


# ---- /api/send-backup-telegram - ручна кнопка на /settings ----

def test_send_backup_telegram_success(client, tmp_path):
    config.AUTO_BACKUP_DIR = str(tmp_path / "backups")
    os.makedirs(config.AUTO_BACKUP_DIR)
    with open(os.path.join(config.AUTO_BACKUP_DIR, "backup-1000.json"), "w") as f:
        f.write("{}")

    with patch("app.telegram_notify.send_document", return_value=(True, "надіслано")):
        resp = client.post("/api/send-backup-telegram")
    data = resp.get_json()
    assert data["success"] is True
    assert "backup-1000.json" in data["message"]


def test_send_backup_telegram_no_directory_returns_clear_message(client, tmp_path):
    config.AUTO_BACKUP_DIR = str(tmp_path / "nonexistent")
    resp = client.post("/api/send-backup-telegram")
    data = resp.get_json()
    assert data["success"] is False
    assert "не створений" in data["message"]


def test_send_backup_telegram_empty_directory_returns_clear_message(client, tmp_path):
    config.AUTO_BACKUP_DIR = str(tmp_path / "empty")
    os.makedirs(config.AUTO_BACKUP_DIR)
    resp = client.post("/api/send-backup-telegram")
    data = resp.get_json()
    assert data["success"] is False
    assert "Немає жодного" in data["message"]


def test_send_backup_telegram_works_regardless_of_periodic_config(client, tmp_path):
    """Реальна мета кнопки: ручна відправка МАЄ працювати незалежно
    від STARLINK_TELEGRAM_BACKUP_ENABLED (той параметр стосується
    лише автоматичного, періодичного надсилання) - користувач явно
    натиснув кнопку, очікує негайну дію."""
    config.TELEGRAM_BACKUP_ENABLED = False
    config.AUTO_BACKUP_DIR = str(tmp_path / "backups")
    os.makedirs(config.AUTO_BACKUP_DIR)
    with open(os.path.join(config.AUTO_BACKUP_DIR, "backup-1.json"), "w") as f:
        f.write("{}")

    with patch("app.telegram_notify.send_document", return_value=(True, "надіслано")) as mock_send:
        resp = client.post("/api/send-backup-telegram")
    data = resp.get_json()
    assert data["success"] is True
    mock_send.assert_called_once()


def test_send_backup_telegram_logs_event(client, tmp_path):
    config.AUTO_BACKUP_DIR = str(tmp_path / "backups")
    os.makedirs(config.AUTO_BACKUP_DIR)
    with open(os.path.join(config.AUTO_BACKUP_DIR, "backup-1.json"), "w") as f:
        f.write("{}")

    with patch("app.telegram_notify.send_document", return_value=(True, "надіслано")):
        client.post("/api/send-backup-telegram")

    events = db.get_recent_events(10)
    assert any(e["kind"] == "telegram_backup_sent" for e in events)


# ---- /api/set-language - зміна мови інтерфейсу (веб + Telegram) ----

def test_set_language_valid_value_saves_and_returns_success(client):
    resp = client.post("/api/set-language", json={"lang": "en"})
    data = resp.get_json()
    assert data["success"] is True
    assert db.get_setting("ui_language") == "en"


def test_set_language_invalid_value_rejected(client):
    resp = client.post("/api/set-language", json={"lang": "fr"})
    assert resp.status_code == 400
    data = resp.get_json()
    assert data["success"] is False


def test_index_page_reflects_saved_language(client):
    client.post("/api/set-language", json={"lang": "en"})
    resp = client.get("/")
    html = resp.get_data(as_text=True)
    assert 'html lang="en"' in html
    assert "Autonomous monitor" in html


def test_index_page_default_language_is_ukrainian(client):
    resp = client.get("/")
    html = resp.get_data(as_text=True)
    assert 'html lang="uk"' in html
    assert "Автономний монітор" in html


# ---- window.I18N містить лише ключі, реально потрібні JS ----

def test_js_i18n_calls_are_static_literals():
    """Набір ключів для window.I18N визначається скануванням t('...')-
    літералів у static/*.js. Динамічний виклик (t(var), t(`...`))
    не потрапив би в набір - і в інтерфейсі тихо з'явився б сирий
    ключ. Цей тест забороняє такі виклики."""
    import glob
    import re
    dynamic = re.compile(r"(?<![\w.])t\(\s*[^'\"\s)]")
    offenders = []
    for path in glob.glob(os.path.join(os.path.dirname(__file__), "..", "static", "*.js")):
        with open(path, encoding="utf-8") as f:
            for n, line in enumerate(f, 1):
                if dynamic.search(line) and "function t(" not in line:
                    offenders.append(f"{os.path.basename(path)}:{n}: {line.strip()}")
    assert offenders == [], offenders


def test_every_js_i18n_key_is_embedded_in_pages(client):
    import json
    import re
    from app import i18n, webapp
    assert webapp._JS_I18N_KEYS, "сканування не знайшло жодного ключа"
    missing_in_dict = webapp._JS_I18N_KEYS - set(i18n.TRANSLATIONS)
    assert missing_in_dict == set(), f"JS використовує невідомі ключі: {missing_in_dict}"
    for page in ("/", "/settings", "/stats"):
        html = client.get(page).get_data(as_text=True)
        blob = json.loads(re.search(r"window\.I18N = (\{.*?\});</script>", html).group(1))
        assert set(blob) == set(webapp._JS_I18N_KEYS), page


# ---- стійкість до поламаних запитів (знайдено фазингом) ----

_BAD_BODIES = ["[1,2]", "\"str\"", "123", "true", "null", "not json"]


@pytest.mark.parametrize("rule", ["/api/auto-reboot", "/api/telegram-config", "/api/target-versions",
                                  "/api/settings-restore", "/api/env-config", "/api/set-language"])
@pytest.mark.parametrize("body", _BAD_BODIES)
def test_non_object_json_body_never_500(client, rule, body):
    """Валідний JSON, що не є об'єктом, раніше давав 500 з трейсбеком
    (payload.get на list/str/int)."""
    r = client.post(rule, data=body, content_type="application/json")
    assert r.status_code < 500


@pytest.mark.parametrize("rule,payload,field", [
    ("/api/telegram-config", {"token": 123}, "token"),
    ("/api/telegram-config", {"chat_ids": 5}, "chat_ids"),
    ("/api/env-config", {"values": [1, 2]}, "values"),
    ("/api/env-config", {"values": "x"}, "values"),
    ("/api/target-versions", {"dish_target": ["a"]}, "dish_target"),
    ("/api/target-versions", {"router_target": 5}, "router_target"),
])
def test_wrong_field_types_rejected_with_400(client, rule, payload, field):
    r = client.post(rule, json=payload)
    assert r.status_code == 400
    assert field in r.get_json()["message"]


def test_env_config_non_string_value_rejected_not_500(client):
    r = client.post("/api/env-config", json={"values": {"STARLINK_WEBUI_PORT": 123}})
    assert r.status_code == 200
    assert r.get_json()["success"] is False


def test_telegram_numeric_chat_ids_accepted(client):
    r = client.post("/api/telegram-config", json={"token": "t", "chat_ids": [123, 456]})
    assert r.get_json()["success"] is True
    assert db.get_setting("telegram_chat_ids") == "123,456"


@pytest.mark.parametrize("query,expected", [
    ("limit=-1", 1),          # раніше LIMIT -1 = "без обмеження" -> увесь журнал (700)
    ("limit=0", 1),
    ("limit=100000", 500),
    ("limit=abc", 30),        # раніше 500
    ("limit=1.5", 30),
])
def test_events_limit_clamped(client, query, expected):
    with db.get_conn() as c:
        c.executemany("INSERT INTO events (ts, kind, message, success, count) VALUES (?, 'k', ?, 1, 1)",
                      [(i, f"m{i}") for i in range(700)])
    r = client.get(f"/api/events?{query}")
    assert r.status_code == 200
    assert len(r.get_json()) == expected


def test_settings_restore_router_target_and_env_error_branches(client):
    """Гілки відновлення, що раніше перевірялись лише разовим зліпком."""
    r = client.post("/api/settings-restore", json={
        "format_version": 1, "router_target_version": "2026.09.09.mr85833",
        "env_params": {"STARLINK_WEBUI_PORT": "не число"},
    }).get_json()
    assert r["success"] is True
    assert "очікувана версія роутера" in r["message"]
    assert "параметри моніторингу - помилка:" in r["message"]
    assert db.get_setting("router_target_version") == "2026.09.09.mr85833"


@pytest.mark.parametrize("key,value", [
    ("STARLINK_POLL_INTERVAL", "-5"), ("STARLINK_HISTORY_DAYS", "0"),
    ("STARLINK_DISH_TIMEOUT", "nan"), ("STARLINK_WEBUI_PORT", "0"),
])
def test_env_config_endpoint_rejects_out_of_range_values(client, key, value):
    """Через справжній HTTP-шлях: дашборд раніше зберігав будь-яке число."""
    r = client.post("/api/env-config", json={"values": {key: value}})
    assert r.status_code == 200
    body = r.get_json()
    assert body["success"] is False
    assert body["message"]


# ---- сторінки не блокуються зовнішніми ресурсами й валідні за HTML5 ----

@pytest.mark.parametrize("path", ["/", "/settings", "/stats"])
def test_pages_have_no_render_blocking_external_stylesheet(client, path):
    """Звичайний <link rel=stylesheet> на зовнішній хост у head блокує перший
    рендер, доки не завантажиться або не відмовить: дашборд відкривають саме
    коли зв'язок поганий (телефон у WiFi Starlink без інтернету) - сторінка
    висіла б секунди порожньою. Зовнішні стилі - лише асинхронно."""
    from html.parser import HTMLParser

    class Links(HTMLParser):
        def __init__(self):
            super().__init__()
            self.in_noscript = False
            self.blocking = []
            self.async_external = 0

        def handle_starttag(self, tag, attrs):
            a = dict(attrs)
            if tag == "noscript":
                self.in_noscript = True
            if tag == "link" and "stylesheet" in (a.get("rel") or "") and not self.in_noscript:
                if (a.get("href") or "").startswith(("http://", "https://", "//")):
                    if a.get("media") == "print" and "onload" in a:
                        self.async_external += 1
                    else:
                        self.blocking.append(a.get("href"))

        def handle_endtag(self, tag):
            if tag == "noscript":
                self.in_noscript = False

    parser = Links()
    parser.feed(client.get(path).get_data(as_text=True))
    assert parser.blocking == []
    assert parser.async_external >= 1        # шрифти таки підключено (асинхронно)


@pytest.mark.parametrize("path", ["/", "/settings", "/stats"])
def test_pages_have_no_unescaped_ampersand_in_attributes(client, path):
    import re
    html = client.get(path).get_data(as_text=True)
    bad = re.findall(r'\w+="[^"]*&(?!amp;|lt;|gt;|quot;|#)[^"]*"', html)
    assert bad == []


def test_pages_are_valid_html5_in_both_languages(client):
    html5lib = pytest.importorskip("html5lib")
    for lang in ("uk", "en"):
        client.post("/api/set-language", json={"lang": lang})
        for path in ("/", "/settings", "/stats"):
            parser = html5lib.HTMLParser(strict=False)
            parser.parse(client.get(path).get_data(as_text=True))
            assert parser.errors == [], (lang, path, parser.errors[:3])


# ---- ендпоінти, які раніше не виконувались жодним тестом ----

def test_manifest_is_localized_and_all_icons_exist(client):
    """PWA-маніфест: мова інтерфейсу + іконки, на які він посилається,
    справді є в static/ (інакше "додати на головний екран" дасть порожню іконку)."""
    import os
    static_dir = os.path.join(os.path.dirname(__file__), "..", "static")
    uk = client.get("/manifest.json").get_json()
    assert uk["start_url"] == "/" and uk["display"] == "standalone"
    for icon in uk["icons"]:
        assert os.path.exists(os.path.join(static_dir, icon["src"].split("/static/", 1)[1])), icon
    client.post("/api/set-language", json={"lang": "en"})
    en = client.get("/manifest.json").get_json()
    assert en["description"] != uk["description"] and en["icons"] == uk["icons"]   # назва - бренд, однакова; опис перекладається


def test_api_config_exposes_only_non_sensitive_settings(client, monkeypatch):
    monkeypatch.setattr(config, "SHUTDOWN_BUTTON_GPIO_PIN", 0)
    data = client.get("/api/config").get_json()
    assert data["poll_interval_sec"] == config.POLL_INTERVAL_SEC
    assert data["shutdown_button_enabled"] is False
    assert not any(k in "".join(data) for k in ("token", "password", "secret", "chat"))
    monkeypatch.setattr(config, "SHUTDOWN_BUTTON_GPIO_PIN", 27)
    assert client.get("/api/config").get_json()["shutdown_button_enabled"] is True


def test_system_shutdown_runs_poweroff_through_the_shared_helper(client):
    with patch("app.pi_power.execute_pi_power_action", return_value=(True, "ok")) as action:
        resp = client.post("/api/system-shutdown")
    assert action.call_args.args[0] == ["sudo", "systemctl", "poweroff"]
    assert resp.get_json() == {"success": True, "message": "ok"}
    with patch("app.pi_power.execute_pi_power_action", return_value=(False, "denied")):
        assert client.post("/api/system-shutdown").get_json() == {"success": False, "message": "denied"}


def test_env_config_restart_restarts_monitor_then_webui_and_logs(client):
    with patch("app.pi_power.run_system_command", return_value=(True, "ok")) as run:
        resp = client.post("/api/env-config-restart")
    assert [c.args[0] for c in run.call_args_list] == [
        ["sudo", "systemctl", "restart", "starlink-monitor.service"],
        ["sudo", "systemctl", "restart", "starlink-webui.service"],
    ]
    assert resp.get_json()["success"] is True
    assert any(e["kind"] == "service_restart" for e in db.get_recent_events(5))
    with patch("app.pi_power.run_system_command", side_effect=[(True, "ok"), (False, "denied")]):
        assert client.post("/api/env-config-restart").get_json()["success"] is False


@pytest.mark.parametrize("path", ["/api/system-shutdown", "/api/system-reboot", "/api/reboot-dish",
                                  "/api/env-config-restart", "/api/auto-reboot"])
def test_destructive_endpoints_reject_get(client, path):
    """Префетч браузера чи краулер не мають змогу вимкнути Pi звичайним GET."""
    assert client.get(path).status_code == 405


def test_oversized_request_body_rejected_with_413(client):
    """Раніше 8.5 МБ JSON приймались і читались у пам'ять (Pi Zero - 415 МБ)."""
    import json
    big = json.dumps({"format_version": 1, "known_devices": [{"dish_id": f"d{i}"} for i in range(400_000)]})
    assert len(big) > 5 * 1024 * 1024
    assert client.post("/api/settings-restore", data=big, content_type="application/json").status_code == 413


def test_realistic_backup_is_far_below_the_body_limit(client):
    """Ліміт не має зачепити легітимний бекап станції (233 пристрої)."""
    import json
    device = {"dish_id": "ut51c88d90-02724404-198fc3bd", "component": "dish", "hardware_version": "rev4_prod2",
              "software_version": "2026.09.14.mr86848", "first_seen_ts": 1.0, "last_seen_ts": 2.0}
    body = json.dumps({"format_version": 1, "known_devices": [device] * 233})
    assert len(body) < 100 * 1024
    assert client.post("/api/settings-restore", data=body, content_type="application/json").status_code == 200


# ---- журнал запитів: опитування дашборду не засмічує журнал (~83 000 рядків на добу на вкладку) ----

@pytest.mark.parametrize("line,dropped", [
    ('127.0.0.1 - - [30/Sep/2026 06:24:30] "GET /api/status HTTP/1.1" 200 -', True),
    ('192.168.0.10 - - [30/Sep/2026 06:24:30] "GET /static/dashboard.js?v=abc HTTP/1.1" 304 -', True),
    ('192.168.0.10 - - [30/Sep/2026 06:24:30] "GET / HTTP/1.1" 200 -', True),
    ('192.168.0.10 - - [30/Sep/2026 06:24:30] "POST /api/system-reboot HTTP/1.1" 200 -', False),   # слід дії
    ('192.168.0.10 - - [30/Sep/2026 06:24:30] "GET /nope HTTP/1.1" 404 -', False),
    ('192.168.0.10 - - [30/Sep/2026 06:24:30] "GET /api/status HTTP/1.1" 500 -', False),
    ('* Running on http://0.0.0.0:8080', False),
])
def test_request_log_filter_drops_only_successful_gets(line, dropped):
    import logging
    from app.webapp import _QuietSuccessfulGets
    record = logging.LogRecord("werkzeug", logging.INFO, "", 0, line, (), None)
    assert _QuietSuccessfulGets().filter(record) is (not dropped)


@pytest.fixture
def live_server(db_path):
    """Справжній HTTP-сервер (Werkzeug): test_client() обходить лог запитів."""
    import threading
    from werkzeug.serving import make_server
    server = make_server("127.0.0.1", 0, flask_app, threaded=True)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_port}"
    server.shutdown()
    thread.join(2)


def test_live_server_logs_actions_and_errors_but_not_polling(live_server, caplog):
    import logging
    import requests
    with caplog.at_level(logging.INFO, logger="werkzeug"):
        for _ in range(5):
            requests.get(f"{live_server}/api/status", timeout=5)
        requests.post(f"{live_server}/api/auto-reboot", json={"enabled": True}, timeout=5)
        requests.get(f"{live_server}/definitely-not-here", timeout=5)
    text = caplog.text
    assert "GET /api/status" not in text                       # опитування - не в журнал
    assert "POST /api/auto-reboot" in text                     # дія лишає слід (з IP)
    assert "/definitely-not-here" in text and "404" in text    # помилки видно


# ---- довідник HTTP API в docs/architecture.md не розходиться з реальними маршрутами ----

def _documented_api_rows():
    import re
    from pathlib import Path
    text = Path(__file__).parent.joinpath("..", "docs", "architecture.md").read_text(encoding="utf-8")
    start = text.index("## HTTP API веб-інтерфейсу")
    section = text[start:text.index("\n## ", start + 5)]
    return {(m.group(1), m.group(2)) for m in re.finditer(r"^\| (GET|POST) \| `(/[^`?]*)(?:\?[^`]*)?` \|", section, re.M)}


def test_http_api_reference_matches_routes():
    """Кожен маршрут (метод + шлях) описаний у таблицях, і кожен описаний
    існує. Раніше 9 з 24 шляхів ніде в документації не називались."""
    actual = {(m, r.rule) for r in flask_app.url_map.iter_rules() if not r.rule.startswith("/static")
              for m in r.methods if m in ("GET", "POST")}
    documented = _documented_api_rows()
    assert sorted(actual - documented) == [], "маршрут без опису в docs/architecture.md"
    assert sorted(documented - actual) == [], "в документації описано неіснуючий маршрут"


def test_documented_post_only_actions_really_reject_get(client):
    """Твердження з довідника: зміни й дії - лише POST (GET -> 405)."""
    post_only = {path for method, path in _documented_api_rows() if method == "POST"} - {
        p for m, p in _documented_api_rows() if m == "GET"}
    assert len(post_only) >= 5          # лише перевірка, що розбір таблиць знайшов рядки
    for path in sorted(post_only):
        assert client.get(path).status_code == 405, path


# ---- відповіді API завжди валідний JSON, навіть якщо в БД лежить inf (рядки до виправлення) ----

def _strict_json(body):
    import json

    def reject(constant):
        raise AssertionError(f"недійсна константа JSON {constant}: браузерний JSON.parse впаде")
    return json.loads(body, parse_constant=reject)


@pytest.mark.parametrize("bad", [float("inf"), float("-inf")])
def test_api_returns_valid_json_even_with_infinity_already_in_db(client, db_path, bad):
    from app.starlink_client import DishStatus
    db.insert_metric(DishStatus(timestamp=2000.0, online=True, uptime_s=5, dish_id="d1").to_dict())
    db.insert_system_metric({"timestamp": 2000.0, "cpu_percent": 1.0, "temp_c": 40.0})
    with db.get_conn() as conn:                          # обходимо db._finite: імітуємо рядок, збережений ДО виправлення
        conn.execute("UPDATE metrics SET ping_latency_ms = ?, downlink_mbps = ?", (bad, bad))
        conn.execute("UPDATE system_metrics SET temp_c = ?", (bad,))
    status = _strict_json(client.get("/api/status").get_data(as_text=True))
    system = _strict_json(client.get("/api/system-status").get_data(as_text=True))
    assert status["latest"]["ping_latency_ms"] is None and status["latest"]["downlink_mbps"] is None
    assert system["latest"]["temp_c"] is None if "latest" in system else system["temp_c"] is None


def test_json_scrub_leaves_ordinary_values_alone():
    from app.webapp import _scrub_non_finite
    data = {"a": 1, "b": 0.0, "c": [1.5, float("nan"), {"d": float("inf"), "e": "текст", "f": None, "g": True}]}
    assert _scrub_non_finite(data) == {"a": 1, "b": 0.0, "c": [1.5, None, {"d": None, "e": "текст", "f": None, "g": True}]}


def test_dashboard_shows_current_state_after_clock_step_back(client, db_path):
    """Тарілка вже OFFLINE (новий запис), а дашборд показував online із запису
    "з майбутнього" ще дві години."""
    from app.starlink_client import DishStatus
    now = time.time()
    db.insert_metric(DishStatus(timestamp=now + 7200, online=True, dish_id="d1").to_dict())
    db.insert_metric(DishStatus(timestamp=now - 5, online=False, dish_id="d1", error="timeout").to_dict())
    assert client.get("/api/status").get_json()["latest"]["online"] == 0


# ---- CSRF: POST з чужого сайту відхиляється, нічого не виконується ----

_POST_ROUTES = sorted({r.rule for r in flask_app.url_map.iter_rules() if "POST" in (r.methods or ()) and not r.rule.startswith("/static")})
_CROSS_SITE_HEADERS = [
    {"Origin": "http://evil.example"},
    {"Origin": "null"},                                              # opaque origin (sandboxed iframe, редирект)
    {"Sec-Fetch-Site": "cross-site"},
    {"Sec-Fetch-Site": "same-site"},
    {"Origin": "http://evil.example", "Sec-Fetch-Site": "same-origin"},    # заголовки суперечать - перевага у Origin
]


@pytest.mark.parametrize("path", _POST_ROUTES)
@pytest.mark.parametrize("headers", _CROSS_SITE_HEADERS, ids=lambda h: "+".join(h))
def test_cross_site_post_is_rejected_and_nothing_is_executed(client, path, headers):
    """"Проста" міжсайтова форма (text/plain, без прелайту) виконувала /api/system-shutdown,
    /api/system-reboot, перезапуск сервісів - з будь-якого сайту, відкритого в LAN."""
    from unittest.mock import MagicMock, patch
    executed = []
    with patch("subprocess.run", side_effect=lambda *a, **k: executed.append(a)), \
         patch("subprocess.Popen", MagicMock(side_effect=lambda *a, **k: executed.append(a))), \
         patch("threading.Timer", MagicMock(side_effect=lambda *a, **k: executed.append(a))), \
         patch("app.pi_power.execute_pi_power_action", side_effect=lambda *a, **k: executed.append(a)):
        response = client.post(path, headers=headers, content_type="text/plain", data=b"")
    assert response.status_code == 403 and response.get_json()["success"] is False
    assert executed == []


@pytest.mark.parametrize("headers", [
    {},                                                              # curl / скрипти без заголовків браузера
    {"Origin": "http://localhost"},                                  # той самий origin (test client: Host = localhost)
    {"Sec-Fetch-Site": "same-origin"},
    {"Sec-Fetch-Site": "none"},
    {"Origin": "http://localhost", "Sec-Fetch-Site": "same-origin"},
], ids=lambda h: "+".join(h) or "без заголовків")
def test_same_origin_and_non_browser_posts_are_not_blocked(client, db_path, headers):
    """Не лише "не 403", а справжній успіх з ефектом: слабка версія проходила б і з 400 (неправильний ключ)."""
    db.set_setting("ui_language", "uk")
    response = client.post("/api/set-language", json={"lang": "en"}, headers=headers)
    assert response.status_code == 200 and response.get_json()["success"] is True
    assert db.get_setting("ui_language") == "en"


def test_get_requests_are_not_affected_by_the_cross_site_guard(client):
    assert client.get("/api/status", headers={"Origin": "http://evil.example", "Sec-Fetch-Site": "cross-site"}).status_code == 200
