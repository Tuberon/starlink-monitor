# Starlink Mini Monitor & Watchdog — Raspberry Pi Zero 2 W

Пристрій на базі RPi Zero 2 W, який:

1. Підключається до WiFi Starlink Mini як клієнт.
2. Опитує dish через локальний gRPC API (`192.168.100.1:9200`) кожні
   10 с — throughput, затримку, втрати пакетів, obstruction, uptime,
   стан оновлення ПЗ, активні попередження, версію прошивки.
3. Окремо опитує роутерний компонент Mini (`192.168.1.1:9000`) раз на
   хвилину — Starlink Mini складається з ДВОХ логічних пристроїв в
   одному корпусі (тарілка й роутер), кожен зі своєю версією прошивки,
   що оновлюється незалежно.
4. Автоматично перезавантажує **весь Starlink Mini** (dish і router —
   один фізичний пристрій, тож reboot dish перезавантажує обидва):
   - якщо dish не відповідає кілька опитувань поспіль (watchdog);
   - якщо оновлення ПЗ dish вже завантажене й готове до встановлення
     (`REBOOT_REQUIRED` або `alerts.install_pending`);
   - якщо оновлення ПЗ роутера вже завантажене й готове до встановлення
     (`REBOOT_PENDING` або `alerts.install_pending`, окрема схема від
     dish — у роутера власний цикл оновлення).
   Усі три тригери діють через спільний захист від reboot-loop.
5. Автоматично перевіряє та встановлює **системні оновлення** самого
   Pi (unattended-upgrades + власний апдейтер для python-залежностей
   і коду цього проєкту з git), з плановим reboot Pi у тихе нічне
   вікно лише якщо це реально потрібно.
6. Збирає системні метрики самого Pi: uptime, CPU, пам'ять, диск,
   температура SoC.
7. Зберігає всю історію в SQLite (з автоматичним очищенням застарілих
   записів).
8. Надає веб-інтерфейс (Flask + Chart.js): live-метрики Starlink і Pi,
   графіки історії, версії прошивок тарілки й роутера, стан оновлення
   обох компонентів з прогрес-баром, список активних попереджень,
   журнал подій з можливістю очищення, кнопки ручного reboot dish і
   ручної перевірки стану оновлень.

## Про ручну перевірку оновлень

Кнопка "Перевірити стан оновлень" на дашборді негайно опитує dish і
router (замість очікування наступного фонового циклу опитування) і
показує актуальний поточний стан.

**Важливе технічне обмеження**, підтверджене прямими gRPC-викликами:
локальний API dish/router **не має** команди "примусово перевір
оновлення в хмарі SpaceX". Кнопка "Перевірити оновлення" в офіційному
застосунку Starlink працює через хмарний бекенд SpaceX (потребує
активного інтернет-з'єднання застосунку), а не через локальний gRPC —
тому вона недоступна для відтворення з локальної мережі. Спроба
викликати відповідний gRPC-метод (`software_update`) повертає:
- на dish: `FailedPrecondition: Sideload update stream not open`
  (цей метод призначений для потокового sideload-завантаження файлу
  прошивки вручну, не для перевірки в хмарі);
- на router: `Unimplemented`.

Отже кнопка на дашборді робить максимум технічно можливого — форсує
негайне локальне опитування замість очікування циклу.

## Важливо розуміти про мережу

Starlink Mini роздає власний WiFi (SSID зазвичай `STARLINK` або
кастомний). RPi Zero 2 W має **один** WiFi-радіомодуль, тож для
доступу і до Starlink Mini, і до звичайного інтернету (для
оновлень) знадобиться або:

- **Варіант A (рекомендований):** USB-Ethernet адаптер для доступу в
  "звичайний" інтернет (apt update, git pull), а WiFi лишити виключно
  для підключення до Starlink Mini.
  ```
  USB-Ethernet ──► Домашня мережа/інтернет (apt update, git pull)
  WiFi (wlan0) ──► WiFi Starlink Mini (моніторинг + reboot dish)
  ```
- **Варіант B:** підключатись лише до WiFi Starlink Mini. Автооновлення
  системи (`app/updater.py`) тоді не матиме доступу в інтернет і буде
  просто логувати невдачу apt-get без наслідків для основного
  моніторингу dish — цей функціонал не залежить від доступності
  зовнішнього інтернету.

## Структура проєкту

```
starlink-monitor/
├── app/
│   ├── starlink_client.py     # gRPC клієнт: статус, стан оновлення,
│   │                           # попередження, reboot dish
│   ├── system_metrics.py      # метрики самого Pi (CPU/RAM/диск/темп.)
│   ├── db.py                  # SQLite шар (metrics, events, system_metrics)
│   ├── monitor.py             # фоновий цикл опитування + watchdog-логіка
│   ├── updater.py             # автооновлення системи/проєкту
│   ├── webapp.py              # Flask веб-інтерфейс + REST API
│   ├── config.py              # конфігурація (пороги, інтервали)
│   └── vendor/                # сюди завантажується starlink_grpc.py
├── templates/
│   └── index.html             # дашборд
├── static/
│   └── dashboard.js
├── systemd/
│   ├── starlink-monitor.service      # фоновий watchdog + збір метрик
│   ├── starlink-webui.service        # веб-інтерфейс
│   ├── starlink-updater.service + .timer   # щоденне автооновлення
│   └── starlink-grpc-fetch.service   # одноразово тягне starlink_grpc.py
│                                      # при старті, з очікуванням WiFi
├── scripts/
│   ├── install.sh              # повне встановлення на чистий Pi
│   └── fetch_starlink_grpc.sh  # (пере)завантажити starlink_grpc.py вручну
└── requirements.txt
```

## Встановлення

```bash
tar -xzf starlink-monitor.tar.gz
cd starlink-monitor
sudo bash scripts/install.sh
```

Скрипт `install.sh`:
- ставить системні пакети, `grpcurl` (через apt або готовий бінарник
  з GitHub releases під архітектуру пристрою) та Python venv
- копіює проєкт у `/opt/starlink-monitor`
- налаштовує звужені sudo-права для сервісного користувача (лише
  конкретні apt/systemctl-команди, не blanket-доступ)
- встановлює та вмикає всі systemd-сервіси
- вмикає `unattended-upgrades` для авто-апдейтів ОС

Після встановлення:
1. Підключіть `wlan0` до WiFi Starlink Mini (якщо ще не підключений):
   `sudo nmcli device wifi connect "<SSID>" password "<пароль>" ifname wlan0`
2. `starlink_grpc.py` завантажиться автоматично, щойно dish стане
   доступним — сервіс `starlink-grpc-fetch.service` вже чекає у фоні.
   Прогрес: `journalctl -u starlink-grpc-fetch.service -f`
3. Дашборд: `http://<ip-пристрою>:8080`

## Конфігурація

Усі налаштування — змінні середовища в `/etc/starlink-monitor/env`
(створюється при встановленні). Повний список — у `app/config.py`.
Найважливіші:

| Змінна | За замовчуванням | Опис |
|---|---|---|
| `STARLINK_DISH_ADDR` | `192.168.100.1:9200` | адреса тарілки |
| `STARLINK_ROUTER_ADDR` | `192.168.1.1:9000` | адреса роутерного компонента Mini |
| `STARLINK_POLL_INTERVAL` | `10` | інтервал опитування dish, сек |
| `STARLINK_MAX_FAILURES` | `6` | скільки невдалих опитувань перед watchdog-reboot |
| `STARLINK_MIN_REBOOT_INTERVAL` | `1800` | мін. інтервал між авто-ребутами dish, сек |
| `STARLINK_AUTO_REBOOT_ON_UPDATE` | `1` | авто-reboot dish коли оновлення готове до встановлення |
| `STARLINK_AUTO_UPDATE` | `1` | авто-оновлення системи Pi |
| `STARLINK_WEBUI_PORT` | `8080` | порт веб-інтерфейсу |

Після зміни файлу — перезапустити сервіси:
```bash
sudo systemctl restart starlink-monitor.service starlink-webui.service
```

## Ліцензія

© 2026 JunioR. Розповсюджується під ліцензією MIT — див. файл
[`LICENSE`](./LICENSE).

Проєкт використовує `starlink_grpc.py` зі стороннього репозиторію
[sparky8512/starlink-grpc-tools](https://github.com/sparky8512/starlink-grpc-tools),
який завантажується окремо (`scripts/fetch_starlink_grpc.sh`) і не входить
до складу цього репозиторію — його ліцензійні умови визначає власний автор.
