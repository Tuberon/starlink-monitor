# 🛰️ Starlink Mini Monitor & Watchdog — Raspberry Pi Zero 2 W

Автономний монітор і watchdog для Starlink Mini на Raspberry Pi Zero 2 W.

**Зміст**: [Що робить](#-що-робить) · [Схема підключення](#-схема-підключення-опційне-обладнання) ·
[GPIO-кнопка](#-фізична-кнопка-виключення-gpio) ·
[TFT-дисплей](#️-фізичний-tft-дисплей-st7789-spi) ·
[Telegram](#-telegram-сповіщення-та-команди) · [Backup](#-backuprestore-налаштувань) ·
[healthz/PWA/speedtest](#-додатково-healthz-pwa-speedtest) · [Надійність](#️-надійність) ·
[Перевірка оновлень](#-про-ручну-перевірку-оновлень) · [Мережа](#-важливо-розуміти-про-мережу) ·
[Типізація](#-типізація-mypy) · [Тести](#-тести) ·
[Структура](#️-структура-проєкту) · [Встановлення](#-встановлення-та-оновлення) ·
[Конфігурація](#️-конфігурація) · [Ліцензія](#-ліцензія)

## 📋 Що робить

1. Підключається до WiFi Starlink Mini як клієнт.
2. Опитує dish (`192.168.100.1:9200`, кожні 10с) і router
   (`192.168.1.1:9000`, раз/хв) — Mini складається з ДВОХ логічних
   пристроїв в одному корпусі, кожен зі своєю прошивкою.
3. Auto-reboot усього Mini при watchdog-таймауті dish або готовому
   оновленні ПЗ (dish/router), зі спільним захистом від reboot-loop.
4. Збирає метрики Pi та історію Starlink в SQLite з автоочищенням.
5. Веб-дашборд (Flask): live-метрики, графіки трендів (власний
   canvas, без сторонніх бібліотек — офлайн-надійність), прошивки,
   WiFi-клієнти, останні 5 подій журналу, ручний reboot/перевірка
   оновлень, реальний speedtest поруч із заявленою швидкістю dish.
   Сторінка `/stats` — повний журнал подій і повна історія speedtest.
6. Telegram: сповіщення + команди `/status /checkupdates /reboot /id /help`.
7. Reboot/shutdown Pi з веб-інтерфейсу або фізичної GPIO-кнопки,
   ручна перевірка оновлень системних пакетів (apt), backup/restore
   всіх налаштувань одним файлом, `/healthz` для зовнішнього
   моніторингу, встановлюваний як PWA.

## 🔌 Схема підключення (опційне обладнання)

```
                    ┌──────────────────┐
                    │ TFT-дисплей 1.9" │
                    │ ST7789, SPI      │
                    └─────────┬────────┘
                              │ SPI: CS=GPIO8, DC=GPIO25,
                              │ RST=GPIO24, BL=GPIO18
                  ┌───────────┴───────────┐
                  │ Raspberry Pi Zero 2 W │
                  └─┬───────────────────┬─┘
           GPIO27 + │                   │ USB OTG-порт
           GND      │                   │ (єдиний, data)
           ┌────────┴────────┐  ┌───────┴───────┐
           │ Кнопка          │  │ USB-Ethernet  │
           │ вимк./підсвітка │  │ дротовий eth0 │
           └─────────────────┘  └───────────────┘
```

TFT-дисплей і кнопка — опційні (`STARLINK_DISPLAY_ENABLED=0` за
замовчуванням). USB-Ethernet теж опційний — WAN-failover fallback,
якщо є (докладніше — [Мережа](#-важливо-розуміти-про-мережу)).

## 🔘 Фізична кнопка виключення (GPIO)

Кнопка (нормально розімкнута) між обраним GPIO-піном (BCM) і GND,
внутрішній pull-up налаштовується сервісом. Увімкнено за замовчуванням
на `GPIO27` (`STARLINK_SHUTDOWN_BUTTON_PIN=27`); `0` вимикає, зміна
піна (за потреби) — у `/etc/starlink-monitor/env`:
```
STARLINK_SHUTDOWN_BUTTON_PIN=27
STARLINK_SHUTDOWN_BUTTON_HOLD_SEC=3
```
потім `sudo systemctl restart starlink-shutdown-button.service`.
Утримання довше заданого часу (типово 3с) → `systemctl poweroff`, з
подією в журналі й Telegram.

Якщо ввімкнено фізичний TFT-дисплей (`STARLINK_DISPLAY_ENABLED=1`) —
**та сама кнопка** отримує другу дію: **коротке** натискання
перемикає підсвітку дисплея, **довге** (як і раніше) вимикає Pi.
Обробляється тоді всередині `starlink-display.service`, а
`starlink-shutdown-button.service` сам себе вимикає (щоб не
конкурувати за той самий GPIO-пін).

## 🖥️ Фізичний TFT-дисплей (ST7789, SPI)

Показує live-статус dish (online/offline, uptime, стан оновлення ПЗ,
версії прошивок dish і роутера). Вимкнено за замовчуванням
(`STARLINK_DISPLAY_ENABLED=0`). Бібліотека — **Adafruit CircuitPython
ST7789** (`adafruit-circuitpython-rgb-display` + `adafruit-blinka`).

> ⚠️ SPI зазвичай вимкнений за замовчуванням: `sudo raspi-config
> nonint do_spi 0 && sudo reboot` (`install.sh` попереджає
> наприкінці, якщо ще не увімкнено).

Паспортна роздільна здатність — 170×320 (SKU MSP1901, portrait).
Піни залежать від підключення — скоригуй через `/settings` або
`/etc/starlink-monitor/env`:
```
STARLINK_DISPLAY_ENABLED=1
STARLINK_DISPLAY_DC_PIN=25
STARLINK_DISPLAY_RST_PIN=24
STARLINK_DISPLAY_BL_PIN=18
STARLINK_DISPLAY_WIDTH=170
STARLINK_DISPLAY_HEIGHT=320
STARLINK_DISPLAY_ROTATION=0
STARLINK_DISPLAY_OFFSET_LEFT=35
```
потім `sudo systemctl restart starlink-display.service`. `BLK`
напряму до 3.3V (не через GPIO) — постав `STARLINK_DISPLAY_BL_PIN=0`.

`ROTATION` підтримує `0/90/180/270`. `OFFSET_LEFT=35` — емпіричне
значення для цієї моделі (без зміщення частина екрана показує
кольоровий шум, не апаратний дефект — підбирай кроком ~10-15px за
потреби). **Не міняй місцями WIDTH/HEIGHT** — дає шум/спотворення.

Керування підсвіткою — та сама кнопка виключення (коротке=перемкнути
підсвітку, довге=вимкнути Pi). Автовимкнення через
`STARLINK_DISPLAY_BACKLIGHT_AUTO_OFF_SEC` (типово 60с, `0`=вимкнено).
При зміні статусу оновлення підсвітка вмикається на
`STARLINK_DISPLAY_UPDATE_FLASH_SEC` (типово 5с) і вимикається —
фізичне сповіщення без потреби дивитись на телефон.

## 💬 Telegram-сповіщення та команди

Налаштовуються на сторінці `/settings` (перехід за іконкою ⚙ на
дашборді):
1. Створіть бота через [@BotFather](https://t.me/BotFather), отримайте bot token.
2. Дізнайтесь свій chat_id через [@userinfobot](https://t.me/userinfobot).
3. Вставте token і chat_id (через кому — кілька отримувачів), "Зберегти",
   потім "Надіслати тестове".
4. Увімкніть перемикач "Увімкнути сповіщення".

> ⚠️ Bot token зберігається в локальній SQLite (таблиця `settings`), у
> веб-інтерфейсі завжди замаскований.

**Команди** (лише для chat_id зі списку):
- `/status` — швидкий, легкий погляд: online-статус, версія ПЗ,
  активні попередження (без запису в БД чи перевірки target-версій)
- `/checkupdates` — повна ручна перевірка: примусово опитати dish/
  router негайно (не чекаючи наступного фонового циклу), записати
  в БД, перевірити target-версії й зафіксувати зміни прошивки — та
  сама логіка, що кнопка "Перевірити оновлення" на дашборді
- `/reboot` — підтвердження через inline-кнопки, діє 2 хвилини
- `/id` — список підключених тарілок; `/id <ID або частина>` — версії
  ПЗ dish/router конкретної тарілки і час останнього оновлення
- `/help` — список команд

Long polling (без webhook) у потоці `starlink-monitor.service`.

Кожне повідомлення завершується випадковою фразою з
`app/signature_phrases.txt` (одна на рядок, редагується на `/settings`);
вимикається перемикачем "Додавати фразу підпису" там же.

**Особливості поведінки сповіщень:**
- `STARLINK_NOTIFY_PI_STARTUP=0` вимикає сповіщення при запуску сервісу
  після реального перезавантаження Pi (не спрацьовує на звичайний
  `systemctl restart` під час оновлення коду)
- `STARLINK_SCHEDULED_REBOOT_ENABLED=1` — плановий reboot Starlink
  Mini (dish+router разом, той самий фізичний пристрій) по таймеру,
  незалежно від реальних збоїв опитування; інтервал —
  `STARLINK_SCHEDULED_REBOOT_INTERVAL_HOURS` (типово 24г). Вимкнено
  за замовчуванням (opt-in)
- Тиша при недоступності dish довше `STARLINK_NOTIFICATIONS_MUTE_AFTER`
  (15 хв) — auto-reboot звіти призупиняються (журнал і далі пишеться),
  відновлення повідомляється з тривалістю простою
- `STARLINK_NOTIFY_DISH_RECOVERY=0` вимикає "✅ Dish знову online..."
- Групування частих reboot (флап, не одна тривала відмова) —
  `STARLINK_REBOOT_SPAM_THRESHOLD`/`_WINDOW_SEC`: одне попередження,
  далі мовчки рахує до затишшя, потім підсумок
- `STARLINK_MAX_LOGGED_FAILURES` (15) — журнал watchdog-спроб reboot
  зупиняється після стількох послідовних невдач (спроби тривають,
  лише запис припиняється)
- Завжди приглушені: помилка перевірки оновлення роутера, "оновлення
  очікує встановлення", dish-роумінг
- Зміна прошивки — "🔄 оновлена" (вперед) чи "⏪ відкочена (можливо,
  SpaceX-side)" (назад — SpaceX інколи відкочує проблемні білди
  глобально); `STARLINK_NOTIFY_FIRMWARE_ROLLBACK=0` вимикає лише
  "⏪"-варіант
- **Очікувані версії прошивок** (`/settings`) — версія чи кілька через
  кому (різні апаратні ревізії), "✅"/"🎉" при збігу, лише новіші
  приймаються (крім узгодження з фактично встановленою версією)

## 💾 Backup/restore налаштувань

На `/settings`: "Завантажити backup" — JSON з bot token, chat_id,
auto-reboot, фразами підпису, очікуваними версіями прошивок, історією
відомих Starlink-пристроїв і перевизначеними параметрами моніторингу
(лише ті, що відрізняються від значень за замовчуванням); "Відновити
з backup" — застосовує файл (параметри моніторингу — після
перезапуску сервісів; історія пристроїв — не перезаписує вже наявні
локально записи, лише додає нові).

> ⚠️ Bot token у файлі — у відкритому вигляді, зберігай backup як secret.

## ➕ Додатково: healthz, PWA, speedtest

- **`GET /healthz`** — для зовнішнього моніторингу (UptimeRobot тощо):
  БД доступна + watchdog реально опитує dish (свіжість метрик < 3
  циклів опитування). `200 ok` / `503 degraded`, нічого не пише в
  журнал — безпечно опитувати часто.
- **Встановлюваний дашборд (PWA)** — "Додати на головний екран" у
  Chrome/Edge. Service worker кешує лише статику (CSS/JS/іконки) —
  API-дані завжди наживо, service worker сам їх не кешує. Окремо:
  якщо Pi недосяжний з телефону (вийшов з WiFi-зони дії Pi) —
  дашборд показує останній відомий стан із браузерного `localStorage`
  та явним банером "останній відомий стан (X хв тому)", щоб не
  плутати із живими даними.
- **Темна/світла тема** — перемикач на `/settings`, зберігається між
  сесіями.
- **Реальний speedtest** — `downlink_mbps` з dish показує заявлену
  пропускну здатність каналу, не реальну користувацьку швидкість.
  Панель "Заявлена vs реальна швидкість" додає незалежний вимір через
  `speedtest-cli`. Вимкнено за замовчуванням (реальний трафік +
  навантаження WiFi-радіо); увімкни на `/settings`
  (`STARLINK_SPEEDTEST_ENABLED=1`, інтервал `STARLINK_SPEEDTEST_INTERVAL`,
  типово двічі/год). Кнопка "Запустити зараз" — для ручного тесту.

## 🛡️ Надійність

- **Watchdog для watchdog-а** — `starlink-monitor-healthcheck.timer`
  (раз/хв) опитує `/healthz`; якщо `starlink-monitor.service` завис
  (не crash, `Restart=always` цього не бачить) — примусовий restart.
- **VACUUM/ANALYZE SQLite** — раз на добу, автоматично.
- **Ротація журналу systemd** — `install.sh` обмежує `SystemMaxUse=200M`,
  щоб журнал не з'їв SD-картку за тривалий час роботи.

## 🔄 Про ручну перевірку оновлень

Кнопка "Перевірити стан оновлень" форсує негайне локальне опитування
dish/router. Локальний gRPC API не має команди "перевір оновлення в
хмарі SpaceX" (це робить хмарний бекенд офіційного застосунку) —
`software_update` повертає `FailedPrecondition`/`Unimplemented`, тож
кнопка робить максимум технічно можливого.

## 🌐 Важливо розуміти про мережу

Starlink Mini роздає власний WiFi. RPi Zero 2 W має один WiFi-модуль,
тож для одночасного доступу до Starlink і звичайного інтернету
потрібен або USB-Ethernet (рекомендовано — WiFi лишається виключно
для Starlink), або підключення лише до Starlink WiFi (моніторинг і
reboot dish не залежать від зовнішнього інтернету).

При використанні USB-Ethernet `install.sh` пропонує (лише при
першому встановленні) опційно налаштувати статичні IP для обох
інтерфейсів — за замовчуванням DHCP на обох може спричиняти конфлікти
маршрутів (dish/router стають недоступні, якщо домашня мережа
перетягує пріоритет default-маршруту).

**Системний WAN-failover**: сервіс `starlink-wan-failover.timer`
(кожні ~20с) перевіряє, чи `wlan0` реально має вихід в інтернет (не
лише локальний зв'язок з dish/router), і через `nmcli` динамічно
знижує пріоритет дефолтного маршруту `wlan0`, коли супутниковий канал
Starlink недоступний — `eth0` автоматично стає дефолтним для **всієї
системи** (apt, curl, будь-яка програма), не лише для нашого коду.
Маршрут до router (своя підмережа wlan0) не зачіпається автоматично;
маршрут до dish — окремий явний запис, доданий `install.sh`
(`nmcli +ipv4.routes`), незалежний від стану WAN-failover. Встановлюється
й вмикається автоматично разом з рештою сервісів.

## 🔍 Типізація (mypy)

Увесь код проєкту (крім `app/vendor/` — сторонній код) типізований і
проходить `mypy` без помилок. Перевірка перед комітом/оновленням:
```bash
pip install -r requirements-dev.txt
mypy app/
```
Не `--strict` і без CI — для одноосібного hobby-проєкту такого
масштабу пропорційніше запускати локально як ще одну живу перевірку
поруч із `py_compile`, ніж інвестувати в повноцінну CI-інфраструктуру
(деталі рішення — `docs/decisions-log.md`).

## ✅ Тести

`tests/` покриває найкрихкішу, stateful-логіку: групування reboot-
спаму (часове вікно), дедублікація сповіщень про target-версії
прошивки, компаратор версій, downsampling метрик. Кожен тест —
ізольована тимчасова БД (`tmp_path`), без побічних ефектів на реальні
дані. Перевірка:
```bash
pip install -r requirements-dev.txt
pytest
```

## 🗂️ Структура проєкту

```
starlink-monitor/
├── app/            # Python: моніторинг, Flask, Telegram, GPIO, дисплей
├── templates/      # HTML (index, settings, stats)
├── static/         # JS/CSS/іконки
├── systemd/        # unit-файли сервісів
├── scripts/        # install/update/uninstall + системні перевірки
├── docs/           # architecture.md, index.md (повний опис кожного файлу), decisions-log.md
└── requirements.txt
```

Детальний опис кожного файлу — [`docs/index.md`](docs/index.md).

## 📦 Встановлення та оновлення

**📥 Перше встановлення:**
```bash
tar -xzf starlink-monitor.tar.gz && cd starlink-monitor
sudo bash scripts/install.sh
```
Ставить системні пакети, `grpcurl`, Python venv, sudo-права,
systemd-сервіси; наприкінці — опційний запит статичних IP (лише при
першому встановленні, див. секцію про мережу вище).

**🔁 Оновлення** (архів у домашньому каталозі, напр. через `scp`):
```bash
sudo bash /opt/starlink-monitor/scripts/update.sh
```
Розпаковує й викликає `install.sh` в update-режимі: системні пакети
не чіпаються, синхронізуються лише змінені файли,
`signature_phrases.txt` не перезаписується, мережевий запит не
повторюється. SHA-256 запобігає повторному встановленню того самого
архіву; шлях можна вказати аргументом.

**✅ Після встановлення:**
1. `sudo nmcli device wifi connect "<SSID>" password "<пароль>" ifname wlan0`
2. Дашборд: `http://<ip-пристрою>:8080`

**🗑️ Повне видалення:**
```bash
sudo bash /opt/starlink-monitor/scripts/uninstall.sh
```
Зупиняє сервіси, видаляє код і sudoers-правило. Історію метрик і
Telegram-налаштування видаляє лише після окремого підтвердження — за
замовчуванням лишаються для повторного встановлення.

## ⚙️ Конфігурація

Редагується на сторінці `/settings` (панель "Параметри моніторингу")
або вручну в `/etc/starlink-monitor/env`. Повний список — у
`app/config.py`. Найважливіші:

| Змінна | За замовчуванням | Опис |
|---|---|---|
| `STARLINK_DISH_ADDR` | `192.168.100.1:9200` | адреса тарілки |
| `STARLINK_DISH_TIMEOUT` | `5` | timeout запиту до dish, сек |
| `STARLINK_ROUTER_ADDR` | `192.168.1.1:9000` | адреса роутерного компонента Mini |
| `STARLINK_POLL_INTERVAL` | `10` | інтервал опитування dish, сек |
| `STARLINK_ROUTER_POLL_INTERVAL_SEC` | `35` | інтервал опитування router, сек |
| `STARLINK_MAX_FAILURES` | `6` | скільки невдалих опитувань перед watchdog-reboot |
| `STARLINK_MIN_REBOOT_INTERVAL` | `180` | мін. інтервал між авто-ребутами dish, сек |
| `STARLINK_NOTIFICATIONS_MUTE_AFTER` | `900` | приглушити Telegram-звіти при безперервній недоступності dish, сек |
| `STARLINK_NOTIFY_DISH_RECOVERY` | `1` | сповіщати "Dish знову online" (0=вимк.) |
| `STARLINK_NOTIFY_FIRMWARE_ROLLBACK` | `1` | сповіщати про відкат прошивки, "⏪ відкочена" (0=вимк.) |
| `STARLINK_NOTIFY_PI_STARTUP` | `1` | сповіщати про запуск Pi після перезавантаження (0=вимк.) |
| `STARLINK_SCHEDULED_REBOOT_ENABLED` | `0` | плановий reboot Starlink Mini по таймеру (1=увімк.) |
| `STARLINK_SCHEDULED_REBOOT_INTERVAL_HOURS` | `24` | інтервал планового reboot, годин |
| `STARLINK_SHUTDOWN_BUTTON_POLL_INTERVAL_SEC` | `0.1` | опитування GPIO кнопки виключення, сек |
| `STARLINK_DISPLAY_BUTTON_POLL_INTERVAL_SEC` | `0.1` | опитування GPIO кнопки дисплея, сек |
| `STARLINK_TELEGRAM_SEND_TIMEOUT_SEC` | `10` | Telegram-бот: timeout надсилання, сек |
| `STARLINK_TELEGRAM_POLL_TIMEOUT_SEC` | `30` | Telegram-бот: timeout long-polling, сек |
| `STARLINK_TELEGRAM_CONFIRM_TTL_SEC` | `120` | Telegram-бот: TTL підтвердження команд, сек |
| `STARLINK_TELEGRAM_NOTIFY_TIMEOUT_SEC` | `10` | Telegram-сповіщення: timeout запиту, сек |
| `STARLINK_TELEGRAM_ID_LIST_MAX_ITEMS` | `40` | /id: макс. тарілок у списку без аргументу |
| `STARLINK_REBOOT_SPAM_THRESHOLD` | `3` | група reboot-сповіщень: поріг кількості за вікно |
| `STARLINK_REBOOT_SPAM_WINDOW_SEC` | `1800` | група reboot-сповіщень: вікно часу, сек |
| `STARLINK_MAX_LOGGED_FAILURES` | `15` | макс. послідовних невдач опитування, що пишуться в журнал/БД |
| `STARLINK_OBSTRUCTION_WARN` | `0.05` | поріг попередження про перешкоди (0-1) |
| `STARLINK_AUTO_REBOOT_ON_UPDATE` | `1` | авто-reboot dish коли оновлення готове до встановлення |
| `STARLINK_HISTORY_DAYS` | `30` | скільки днів зберігати історію метрик/подій |
| `STARLINK_DOWNSAMPLE_AFTER_DAYS` | `3` | агрегувати метрики старші за, днів (менша БД) |
| `STARLINK_DOWNSAMPLE_BUCKET_SEC` | `300` | розмір bucket для агрегації, сек |
| `STARLINK_WEBUI_PORT` | `8080` | порт веб-інтерфейсу |
| `STARLINK_SHUTDOWN_BUTTON_PIN` | `27` | GPIO-пін фізичної кнопки виключення (BCM), 0=вимкнено |
| `STARLINK_SHUTDOWN_BUTTON_HOLD_SEC` | `3` | скільки секунд утримувати кнопку перед виключенням |
| `STARLINK_DISPLAY_ENABLED` | `0` | фізичний TFT-дисплей статусу (0/1) |
| `STARLINK_DISPLAY_SPI_CS_PIN` | `8` | дисплей: GPIO-пін CS (bit-banged) |
| `STARLINK_DISPLAY_DC_PIN` | `25` | дисплей: GPIO-пін DC |
| `STARLINK_DISPLAY_RST_PIN` | `24` | дисплей: GPIO-пін RES |
| `STARLINK_DISPLAY_BL_PIN` | `18` | дисплей: GPIO-пін підсвітки (0=не керувати) |
| `STARLINK_DISPLAY_WIDTH` | `170` | дисплей: ширина, px |
| `STARLINK_DISPLAY_HEIGHT` | `320` | дисплей: висота, px |
| `STARLINK_DISPLAY_ROTATION` | `0` | дисплей: поворот, ° (0/90/180/270, для будь-якого aspect ratio) |
| `STARLINK_DISPLAY_OFFSET_LEFT` | `35` | дисплей: зміщення X відносно GRAM, px |
| `STARLINK_DISPLAY_OFFSET_TOP` | `0` | дисплей: зміщення Y відносно GRAM, px |
| `STARLINK_DISPLAY_REFRESH_SEC` | `5` | дисплей: інтервал оновлення, сек |
| `STARLINK_DISPLAY_SPI_SPEED_HZ` | `40000000` | дисплей: швидкість SPI, Гц |
| `STARLINK_DISPLAY_BACKLIGHT_AUTO_OFF_SEC` | `60` | дисплей: автовимкнення підсвітки, сек (0=вимк.) |
| `STARLINK_DISPLAY_UPDATE_FLASH_SEC` | `5` | дисплей: підсвітка при зміні статусу оновлення, сек (0=вимк.) |
| `STARLINK_SPEEDTEST_ENABLED` | `0` | періодичний реальний speedtest (0/1) |
| `STARLINK_SPEEDTEST_INTERVAL` | `1800` | інтервал між speedtest-прогонами, сек |

Параметри читаються один раз при старті процесів — після збереження
на `/settings` натисни "Зберегти й перезапустити сервіси" (кнопка
поруч), або вручну:
```bash
sudo systemctl restart starlink-monitor.service starlink-webui.service
```

## 📄 Ліцензія

© 2026 JunioR. Розповсюджується під ліцензією MIT — див. файл
[`LICENSE`](./LICENSE).

Проєкт включає (vendored, `app/vendor/starlink_grpc.py`) файл зі
стороннього репозиторію
[sparky8512/starlink-grpc-tools](https://github.com/sparky8512/starlink-grpc-tools)
для відтворюваності збірки (не завантажується динамічно при
встановленні) — **його ліцензійні умови визначає власний автор**,
окремо від MIT цього репозиторію. Оновлення до найновішої
upstream-версії — опційно, `scripts/fetch_starlink_grpc.sh`.
